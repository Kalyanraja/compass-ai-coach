/* ============================================================================
   COMPASS UI — Interaction layer (vanilla JS, no dependencies)
   ----------------------------------------------------------------------------
   Wires up: tabs, accordion, modal, dropdown menus, command palette,
   toast notifications, copy-to-clipboard buttons, switch change events.

   Usage: include AFTER compass-ui.css, before </body>:
     <script src="compass-ui.js"></script>

   Everything is initialized automatically via data attributes; no global
   namespace pollution (single IIFE).
   ============================================================================ */

(function () {
  "use strict";

  /* ------------------------------------------------------------------
     Helpers
  ------------------------------------------------------------------ */
  const $  = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

  /* ==================================================================
     1. TABS
     ------------------------------------------------------------------
     Markup:
       <div class="cui-tabs" data-tabs>
         <div class="cui-tabs__list" role="tablist">
           <button class="cui-tabs__tab" role="tab" data-tab="t1" aria-selected="true">…</button>
         </div>
         <div class="cui-tabs__panel" role="tabpanel" data-tab-panel="t1">…</div>
       </div>
     Keyboard: Left/Right arrows move between tabs (WAI-ARIA tabs pattern).
  ================================================================== */
  $$("[data-tabs]").forEach((tabs) => {
    const tabList = $(".cui-tabs__list", tabs);
    const tabsArr = $$('[role="tab"]', tabList);

    const activate = (tab, focusIt) => {
      tabsArr.forEach((t) => {
        const selected = t === tab;
        t.setAttribute("aria-selected", String(selected));
        t.tabIndex = selected ? 0 : -1;
        const panel = $(`[data-tab-panel="${t.dataset.tab}"]`, tabs);
        if (panel) panel.hidden = !selected;
      });
      if (focusIt) tab.focus();
    };

    tabsArr.forEach((tab, i) => {
      tab.tabIndex = tab.getAttribute("aria-selected") === "true" ? 0 : -1;
      tab.addEventListener("click", () => activate(tab, false));
      tab.addEventListener("keydown", (e) => {
        let next = null;
        if (e.key === "ArrowRight") next = tabsArr[(i + 1) % tabsArr.length];
        if (e.key === "ArrowLeft")  next = tabsArr[(i - 1 + tabsArr.length) % tabsArr.length];
        if (e.key === "Home")       next = tabsArr[0];
        if (e.key === "End")        next = tabsArr[tabsArr.length - 1];
        if (next) { e.preventDefault(); activate(next, true); }
      });
    });
  });

  /* ==================================================================
     2. ACCORDION
     ------------------------------------------------------------------
     Markup:
       <div class="cui-accordion" data-accordion>
         <div class="cui-accordion__item">
           <button class="cui-accordion__trigger" aria-expanded="false" data-acc-trigger>
             Title <svg class="cui-accordion__chevron">…</svg>
           </button>
           <div class="cui-accordion__panel" data-acc-panel><div class="cui-accordion__content">…</div></div>
         </div>
       </div>
  ================================================================== */
  $$("[data-accordion]").forEach((acc) => {
    const single = acc.hasAttribute("data-accordion-single");
    const items = $$(":scope > .cui-accordion__item", acc);

    const setOpen = (item, open) => {
      const trigger = $("[data-acc-trigger]", item);
      const panel = $("[data-acc-panel]", item);
      if (!trigger || !panel) return;
      item.classList.toggle("is-open", open);
      trigger.setAttribute("aria-expanded", String(open));
      panel.style.maxHeight = open ? panel.scrollHeight + "px" : "0px";
    };

    items.forEach((item) => {
      const trigger = $("[data-acc-trigger]", item);
      if (!trigger) return;
      // initial state from aria-expanded / is-open class
      setOpen(item, trigger.getAttribute("aria-expanded") === "true" || item.classList.contains("is-open"));
      trigger.addEventListener("click", () => {
        const willOpen = trigger.getAttribute("aria-expanded") !== "true";
        if (single) items.forEach((it) => { if (it !== item) setOpen(it, false); });
        setOpen(item, willOpen);
      });
    });

    // keep open panels sized correctly on resize
    window.addEventListener("resize", () => {
      items.forEach((item) => {
        const panel = $("[data-acc-panel]", item);
        if (panel && item.classList.contains("is-open")) panel.style.maxHeight = panel.scrollHeight + "px";
      });
    });
  });

  /* ==================================================================
     3. MODAL  (accessible: focus trap, Esc to close, aria-hidden sync)
     ------------------------------------------------------------------
     Markup:
       <button data-modal-open="#my-modal">Open</button>
       <div class="cui-modal-overlay" id="my-modal" role="dialog" aria-modal="true"
            aria-labelledby="my-modal-title" hidden>
         <div class="cui-modal">
           <div class="cui-modal__header">
             <h3 class="cui-modal__title" id="my-modal-title">Title</h3>
             <button class="cui-icon-btn cui-modal__close" data-modal-close aria-label="Close">…</button>
           </div>
           <div class="cui-modal__body">…</div>
           <div class="cui-modal__footer">…</div>
         </div>
       </div>
  ================================================================== */
  let lastFocusedBeforeModal = null;

  const openModal = (modal) => {
    lastFocusedBeforeModal = document.activeElement;
    modal.hidden = false;
    requestAnimationFrame(() => modal.classList.add("is-open"));
    document.body.style.overflow = "hidden";
    const focusTarget = $(FOCUSABLE, modal) || modal;
    setTimeout(() => focusTarget.focus(), 60);
    document.addEventListener("keydown", modalKeyHandler);
  };

  const closeModal = (modal) => {
    modal.classList.remove("is-open");
    document.removeEventListener("keydown", modalKeyHandler);
    setTimeout(() => {
      modal.hidden = true;
      document.body.style.overflow = "";
      if (lastFocusedBeforeModal && document.contains(lastFocusedBeforeModal)) {
        lastFocusedBeforeModal.focus();
      }
    }, 200);
  };

  const modalKeyHandler = (e) => {
    const open = $(".cui-modal-overlay.is-open");
    if (!open) return;
    if (e.key === "Escape") { e.preventDefault(); closeModal(open); return; }
    if (e.key === "Tab") {
      // simple focus trap
      const focusables = $$(FOCUSABLE, open).filter((el) => el.offsetParent !== null);
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  };

  $$("[data-modal-open]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const modal = $(btn.getAttribute("data-modal-open"));
      if (modal) openModal(modal);
    });
  });
  $$(".cui-modal-overlay").forEach((overlay) => {
    overlay.addEventListener("click", (e) => {
      // close when clicking the dimmed backdrop itself
      if (e.target === overlay || e.target.closest("[data-modal-close]")) closeModal(overlay);
    });
  });

  /* ==================================================================
     4. DROPDOWN MENU
     ------------------------------------------------------------------
     Markup:
       <div class="cui-dropdown" data-dropdown>
         <button class="cui-btn" data-dropdown-trigger aria-haspopup="menu" aria-expanded="false">Menu</button>
         <div class="cui-menu" role="menu" data-dropdown-menu>
           <button class="cui-menu__item" role="menuitem">Item</button>
           <div class="cui-menu__sep"></div>
         </div>
       </div>
  ================================================================== */
  $$("[data-dropdown]").forEach((wrap) => {
    const trigger = $("[data-dropdown-trigger]", wrap);
    const menu = $("[data-dropdown-menu]", wrap);
    if (!trigger || !menu) return;

    const setOpen = (open) => {
      menu.classList.toggle("is-open", open);
      trigger.setAttribute("aria-expanded", String(open));
    };

    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      setOpen(!menu.classList.contains("is-open"));
    });

    document.addEventListener("click", (e) => {
      if (!wrap.contains(e.target)) setOpen(false);
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && menu.classList.contains("is-open")) { setOpen(false); trigger.focus(); }
    });

    // arrow-key navigation within the menu (roving focus)
    const items = () => $$('[role="menuitem"]', menu);
    menu.addEventListener("keydown", (e) => {
      const its = items();
      const idx = its.indexOf(document.activeElement);
      if (e.key === "ArrowDown") { e.preventDefault(); (its[idx + 1] || its[0]).focus(); }
      if (e.key === "ArrowUp")   { e.preventDefault(); (its[idx - 1] || its[its.length - 1]).focus(); }
    });
    items().forEach((it) => it.addEventListener("click", () => setOpen(false)));
  });

  /* ==================================================================
     5. TOASTS
     ------------------------------------------------------------------
     JS API:
       CompassUI.toast("Message", { title: "Optional", variant: "success", duration: 4000 });
     Markup is generated into a viewport appended to <body>.
  ================================================================== */
  let toastViewport = null;
  const getViewport = () => {
    if (!toastViewport) {
      toastViewport = document.createElement("div");
      toastViewport.className = "cui-toast-viewport";
      toastViewport.setAttribute("aria-live", "polite");
      toastViewport.setAttribute("aria-atomic", "false");
      document.body.appendChild(toastViewport);
    }
    return toastViewport;
  };

  const toast = (message, opts = {}) => {
    const { title = "", variant = "default", duration = 4000 } = opts;
    const el = document.createElement("div");
    el.className = `cui-toast${variant !== "default" ? ` cui-toast--${variant}` : ""}`;
    el.setAttribute("role", "status");
    el.innerHTML = `<span class="cui-toast__dot"></span>
      <span class="cui-toast__msg">${title ? `<strong></strong> ` : ""}<span class="cui-toast__text"></span></span>
      <button class="cui-icon-btn cui-icon-btn--sm" aria-label="Dismiss">✕</button>`;
    const strong = $("strong", el);
    if (title && strong) strong.textContent = title;
    $(".cui-toast__text", el).textContent = message;
    getViewport().appendChild(el);

    const dismiss = () => {
      el.classList.add("is-leaving");
      el.addEventListener("animationend", () => el.remove(), { once: true });
    };
    $("button", el).addEventListener("click", dismiss);
    if (duration > 0) setTimeout(dismiss, duration);
    return el;
  };

  /* ==================================================================
     6. COPY-TO-CLIPBOARD
     ------------------------------------------------------------------
     Any element with [data-copy] copies its target's text:
       <button data-copy="#snippet-1">Copy</button>
     Button label swaps to "Copied" briefly. Non-secure contexts fall
     back to a hidden textarea + execCommand.
  ================================================================== */
  const copyText = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
  };

  $$("[data-copy]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const target = $(btn.getAttribute("data-copy"));
      if (!target) return;
      await copyText(target.textContent.trim());
      const original = btn.textContent;
      btn.textContent = "Copied";
      btn.classList.add("is-copied");
      setTimeout(() => { btn.textContent = original; btn.classList.remove("is-copied"); }, 1600);
    });
  });

  /* ==================================================================
     7. COMMAND PALETTE  (⌘K / Ctrl+K)
     ------------------------------------------------------------------
     Markup:
       <div class="cui-cmdk-overlay" id="cmdk" hidden>
         <div class="cui-cmdk" role="dialog" aria-modal="true" aria-label="Command palette">
           <div class="cui-cmdk__input-row">…<input class="cui-cmdk__input" data-cmdk-input placeholder="Type a command…"></div>
           <div class="cui-cmdk__list" data-cmdk-list>
             <div class="cui-cmdk__group-label">Actions</div>
             <button class="cui-cmdk__item" data-cmdk-item data-keywords="new goal start">
               <span>New goal</span><kbd>⌘N</kbd>
             </button>
           </div>
           <div class="cui-cmdk__footer">…</div>
         </div>
       </div>

     Trigger with data-cmdk-open="#cmdk", or the global ⌘K/Ctrl+K hotkey
     when <body data-cmdk-global="#cmdk"> is set.
  ================================================================== */
  let activeCmdk = null;
  let cmdkItems = [];
  let cmdkActiveIdx = -1;

  const cmdkSetActive = (idx) => {
    cmdkItems.forEach((it, i) => it.classList.toggle("is-active", i === idx));
    cmdkActiveIdx = idx;
    if (cmdkItems[idx]) cmdkItems[idx].scrollIntoView({ block: "nearest" });
  };

  const cmdkFilter = (query) => {
    const q = query.trim().toLowerCase();
    let visible = [];
    cmdkItems.forEach((it) => {
      const hay = (it.textContent + " " + (it.dataset.keywords || "")).toLowerCase();
      const match = !q || hay.includes(q);
      it.style.display = match ? "" : "none";
      if (match) visible.push(it);
    });
    // hide empty group labels
    $$("[data-cmdk-list] .cui-cmdk__group-label", activeCmdk).forEach((label) => {
      let el = label.nextElementSibling;
      let anyVisible = false;
      while (el && !el.classList.contains("cui-cmdk__group-label")) {
        if (el.hasAttribute("data-cmdk-item") && el.style.display !== "none") anyVisible = true;
        el = el.nextElementSibling;
      }
      label.style.display = anyVisible ? "" : "none";
    });
    const empty = $("[data-cmdk-empty]", activeCmdk);
    if (empty) empty.style.display = visible.length ? "none" : "";
    cmdkSetActive(visible.length ? 0 : -1);
    return visible;
  };

  const openCmdk = (overlay) => {
    activeCmdk = overlay;
    overlay.hidden = false;
    requestAnimationFrame(() => overlay.classList.add("is-open"));
    document.body.style.overflow = "hidden";
    const input = $("[data-cmdk-input]", overlay);
    cmdkItems = $$("[data-cmdk-item]", overlay);
    cmdkItems.forEach((it) => it.setAttribute("role", "option"));
    if (input) { input.value = ""; setTimeout(() => input.focus(), 50); }
    cmdkFilter("");
    document.addEventListener("keydown", cmdkKeyHandler);
  };

  const closeCmdk = () => {
    if (!activeCmdk) return;
    activeCmdk.classList.remove("is-open");
    document.removeEventListener("keydown", cmdkKeyHandler);
    document.body.style.overflow = "";
    const overlay = activeCmdk;
    setTimeout(() => { overlay.hidden = true; }, 180);
    activeCmdk = null;
  };

  const cmdkKeyHandler = (e) => {
    if (e.key === "Escape") { e.preventDefault(); closeCmdk(); return; }
    const visible = cmdkItems.filter((it) => it.style.display !== "none");
    if (!visible.length) return;
    if (e.key === "ArrowDown") { e.preventDefault(); cmdkSetActive((cmdkActiveIdx + 1) % visible.length); }
    if (e.key === "ArrowUp")   { e.preventDefault(); cmdkSetActive((cmdkActiveIdx - 1 + visible.length) % visible.length); }
    if (e.key === "Enter" && cmdkActiveIdx >= 0) {
      e.preventDefault();
      const current = visible[cmdkActiveIdx];
      closeCmdk();
      current.click();
    }
  };

  $$(".cui-cmdk-overlay").forEach((overlay) => {
    overlay.addEventListener("click", (e) => { if (e.target === overlay) closeCmdk(); });
    const input = $("[data-cmdk-input]", overlay);
    if (input) input.addEventListener("input", () => cmdkFilter(input.value));
    $$("[data-cmdk-item]", overlay).forEach((it) =>
      it.addEventListener("mousemove", () => {
        const visible = cmdkItems.filter((x) => x.style.display !== "none");
        cmdkSetActive(visible.indexOf(it));
      })
    );
  });

  $$("[data-cmdk-open]").forEach((btn) =>
    btn.addEventListener("click", () => {
      const overlay = $(btn.getAttribute("data-cmdk-open"));
      if (overlay) openCmdk(overlay);
    })
  );

  // global hotkey (⌘K / Ctrl+K)
  document.addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
      const sel = document.body.getAttribute("data-cmdk-global");
      if (!sel) return;
      e.preventDefault();
      const overlay = $(sel);
      if (!overlay) return;
      if (overlay.classList.contains("is-open")) closeCmdk();
      else openCmdk(overlay);
    }
  });

  /* ==================================================================
     8. PUBLIC API
  ================================================================== */
  window.CompassUI = { toast, openModal, closeModal, openCmdk, closeCmdk, copyText };
})();
