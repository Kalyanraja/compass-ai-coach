/* ==========================================================================
   Scrolltide — tiny vanilla JS scroll engine (original code, ~100 lines)
   Features:
     1. IntersectionObserver reveal (.st-reveal + variant classes)
     2. Parallax via rAF on scroll (.st-parallax, depth via --st-depth)
     3. Scroll progress bar (.st-progress > span)
     4. Smooth anchor scrolling (adds html.st-smooth)
     5. SVG draw-on-scroll (.st-draw paths get dash-animated)
   Respects prefers-reduced-motion throughout.
   ========================================================================== */
(function () {
  "use strict";

  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---- 1. Reveal on scroll ------------------------------------------------ */
  function initReveals() {
    var items = document.querySelectorAll(".st-reveal");
    if (reduced || !("IntersectionObserver" in window)) {
      items.forEach(function (el) { el.classList.add("st-in"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("st-in");
          io.unobserve(entry.target); /* reveal once */
        }
      });
    }, { threshold: 0.15, rootMargin: "0px 0px -8% 0px" });
    items.forEach(function (el) { io.observe(el); });
  }

  /* ---- 2. Parallax via rAF ------------------------------------------------- */
  var parallaxEls = [];
  var ticking = false;

  function collectParallax() {
    parallaxEls = Array.prototype.slice.call(
      document.querySelectorAll(".st-parallax")
    ).map(function (el) {
      return {
        el: el,
        depth: parseFloat(el.getAttribute("data-depth") || "0.25"),
        offset: 0
      };
    });
  }

  function updateParallax() {
    var vh = window.innerHeight;
    parallaxEls.forEach(function (p) {
      var rect = p.el.parentElement.getBoundingClientRect();
      /* progress of the parent block through the viewport: -1 .. 1 */
      var progress = (rect.top + rect.height / 2 - vh / 2) / (vh / 2);
      p.offset = -progress * p.depth * 100;
      p.el.style.setProperty("--st-parallax", p.offset.toFixed(2));
    });
    ticking = false;
  }

  function onScroll() {
    if (!ticking && parallaxEls.length) {
      ticking = true;
      requestAnimationFrame(updateParallax);
    }
  }

  function initParallax() {
    if (reduced) return;
    collectParallax();
    updateParallax();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
  }

  /* ---- 3. Scroll progress bar ------------------------------------------------ */
  function initProgress() {
    var bar = document.querySelector(".st-progress span");
    if (!bar) return;
    function update() {
      var doc = document.documentElement;
      var max = doc.scrollHeight - window.innerHeight;
      var pct = max > 0 ? (window.scrollY / max) * 100 : 0;
      bar.style.width = pct.toFixed(2) + "%";
    }
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update, { passive: true });
    update();
  }

  /* ---- 4. Smooth anchor scrolling -------------------------------------------- */
  function initSmoothAnchors() {
    if (reduced) return;
    document.documentElement.classList.add("st-smooth");
    document.addEventListener("click", function (e) {
      var a = e.target.closest('a[href^="#"]');
      if (!a) return;
      var id = a.getAttribute("href");
      if (id.length < 2) return;
      var target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: "smooth", block: "start" });
        history.replaceState(null, "", id);
      }
    });
  }

  /* ---- 5. SVG draw-on-scroll -------------------------------------------------- */
  function initDraw() {
    var paths = document.querySelectorAll(".st-draw");
    if (!paths.length) return;
    if (reduced) return; /* CSS transition already disabled; leave as-is */
    paths.forEach(function (path) {
      var len = path.getTotalLength();
      path.style.strokeDasharray = len;
      path.style.strokeDashoffset = len;
    });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.strokeDashoffset = "0";
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.35 });
    paths.forEach(function (p) { io.observe(p); });
  }

  /* ---- Boot -------------------------------------------------------------------- */
  function boot() {
    initReveals();
    initParallax();
    initProgress();
    initSmoothAnchors();
    initDraw();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
