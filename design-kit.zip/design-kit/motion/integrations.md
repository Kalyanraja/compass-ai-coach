# Compass Motion — Integration Guide

**What this folder is.** Compass is a local, **offline** web app (`web/` is vanilla JS, no CDN, no build step). This `design-kit/motion/` folder stands in for the motion-SaaS tools you'd normally reach for — because their runtimes and assets either can't be redistributed or can't run offline. Everything here is original, clean-room work that opens by double-clicking the file.

---

## The four tools, and what each is actually for

| Tool | What it produces | Free tier (typical) | Offline? | Redistributable? |
|---|---|---|---|---|
| **Framer** | Hosted animated websites (whole pages, CMS, publishing) | Free plan with framer.website subdomain + Framer badge | ❌ hosted only | ❌ you link/iframe, never re-host |
| **Rive** | Interactive vector animations with state machines (`.riv`), canvas runtime | Free tier, runtime hotlinked from their CDN | ⚠️ only on paid/self-host plans | ❌ runtime needs a redistribution-permitting plan |
| **Spline** | Interactive 3D scenes (WebGL), `<spline-viewer>` web component | Free tier with viewer watermark-ish limits | ❌ runtime from their CDN | ❌ runtime is not redistributable |
| **Lottie** | Small JSON vector animations, played by `lottie-player` | Player is MIT; animation files vary by source | ✅ if you vendor the player + bundle JSON | ✅ player (MIT) + your own/CC0 JSON |

> Free-tier details change often — verify on each vendor's pricing page before committing. The architecture advice below doesn't depend on the exact numbers.

## When to use the embed vs. the offline equivalent

| You want… | SaaS route | **Use this instead (offline, license-clean)** |
|---|---|---|
| Animated hero section, landing page | Framer site | `hero-motion.html` — floating gradient orbs, rotating compass-rose SVG, staggered headline reveal, sheen-sweep CTA |
| Cursor-following / stateful vector interaction | Rive state machine | `interactive-vector.html` — SVG needle with a real spring integrator (stiffness/damping/mass) on `requestAnimationFrame` |
| A draggable 3D object on the page | Spline scene | `web3d.html` — CSS 3D transforms cube carousel with drag inertia and snap |
| A rich micro-animation (checkmark, spinner) | Lottie file | Fine to embed **if** you bundle an MIT player + an animation you authored or that's openly licensed — see `embed-templates.html` |
| Documentation of all four embeds | — | `embed-templates.html` — copy-paste templates with per-tool licensing notes |

**Rule of thumb:** if the effect can be CSS/SVG/JS, it should be — one less runtime, one less license, zero network. Reserve external embeds for prototypes and marketing pages where network is guaranteed.

## How to drop these files into the Compass web UI

The Compass app shell is plain HTML in `web/`. There is no bundler, so integration is three copy operations:

```text
compass-ai-coach/
└── web/
    ├── index.html
    ├── css/
    │   └── compass-ui.css        ← copy from design-kit/ui-kit/
    └── vendor/
        └── design-kit/           ← copy both folders as-is
            ├── ui-kit/
            └── motion/
```

### 1. Use the design system everywhere

```html
<link rel="stylesheet" href="css/compass-ui.css">
<script src="vendor/design-kit/ui-kit/compass-ui.js" defer></script>
```

Every component class (`cui-btn`, `cui-card`, `cui-tabs`, …) is documented with copy-ready markup in `design-kit/ui-kit/index.html`. Open that file in a browser — it's the living style guide.

### 2. Adopt the hero on the landing/start screen

Copy the `<style>` block and markup from `motion/hero-motion.html` into `web/index.html` (or keep it as a separate `hero.html` and link). It is self-contained: no JS, no fonts, no images. It honors `prefers-reduced-motion` automatically.

### 3. Mount the interactive dial as a widget

The dial in `motion/interactive-vector.html` is one `<div class="stage">` + one `<script>`. To embed it inside an existing page instead of standalone:

1. Copy the `<style>` block into your page's CSS (it only scopes `:root` tokens and `.stage`/`.readout` classes).
2. Copy the `<div class="stage">…</div>` markup where you want it.
3. Copy the `<script>` after your other scripts.

The script is an IIFE with no globals — safe to include alongside app code. Hook the needle to real state by writing to the `target` variable from your app (expose a tiny API if needed).

### 4. Use the 3D carousel for onboarding or feature tours

Same pattern as the dial: copy styles, the `.scene` markup, and the script from `motion/web3d.html`. Edit the `CARDS` array at the top of the script to feature real Compass capabilities. Faces are plain HTML, so you can put buttons inside them.

### 5. Token alignment

Both motion files and the UI kit share the same palette tokens (`--teal-300 #4dd8d8`, ink navy scale, etc.). If Compass's `web/` CSS already defines similar custom properties, delete the `:root` duplicates from the motion stylesheets and map to your own tokens — the components only use the variables, so retargeting is a find-and-replace on the token block.

### 6. Performance & accessibility checklist

- [ ] All animation respects `prefers-reduced-motion` (already built in — don't remove it).
- [ ] The dial and carousel are decorative where appropriate — keep `aria-hidden` on the SVG visuals and provide text alternatives, as these files already do.
- [ ] No file in this kit makes network requests; run the app with DevTools → Network → Offline to confirm after integration.

---

*Original clean-room work for the Compass hackathon repo. Vendor names (Framer, Rive, Spline, Lottie) are trademarks of their respective owners; this kit references them only for compatibility documentation.*
