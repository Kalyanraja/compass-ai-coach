# Compass Design Kit

A curated, **fully offline** collection of original UI assets for the Compass AI coach web app — no CDN, no build step, no external fonts or images. Open any `index.html` by double-clicking it. Everything here is clean-room original code (MIT, same as the repo), created to stand in for popular design/motion tools that cannot be redistributed.

## What's inside

| Folder | Replaces / inspired by | Contents |
|---|---|---|
| `scroll-animations/` | Scrolltide | `scrolltide.css` + `scrolltide.js` reveal/parallax/progress engine + full storytelling demo page |
| `navbar-gallery/` | Navbar gallery sites | 10 production-quality navbar patterns (`navbar-01` … `navbar-10`) + gallery with copy-snippet buttons |
| `loading-animations/` | Loading.io-style libraries | 13 loaders incl. the flagship **AI-coach thinking panel** (loader-13), `loaders.css` library |
| `icons-3d/` | 3D icon asset libraries | 12 dashboard icons as CSS-3D tiles + matching inline-SVG sprite (`icons.svg`), usage demo |
| `ui-kit/` | Untitled UI | `compass-ui.css` design-system tokens + ~25 components, `compass-ui.js` interactions, living style guide |
| `motion/` | Framer, Rive, Spline, Lottie | Offline equivalents (animated hero, interactive SVG compass, CSS-3D carousel) + embed templates + `integrations.md` |
| `PROMPT.md` | — | Master prompt for generating UI in this kit's style |

## Design language (shared across every folder)

- **Theme:** dark "navigator" — deep navy/ink surfaces, compass-rose accents, teal→cyan highlights, violet secondary
- **Fonts:** system font stack only (works offline, zero layout shift)
- **Motion:** spring-eased, `prefers-reduced-motion` respected everywhere
- **Accessibility:** semantic landmarks, focus-visible rings, 4.5:1+ contrast, keyboard-operable interactive components

## Quick start in Compass

The app UI lives in `web/` (vanilla JS). To adopt a piece:

1. Copy `ui-kit/compass-ui.css` (+ `compass-ui.js`) into `web/` and link from `index.html`.
2. Swap the loading spinner for `loading-animations/loader-01.html` (compass sweep) or the full thinking panel (`loader-13`).
3. Add scroll reveals by linking `scroll-animations/scrolltide.css` + `scrolltide.js` and adding `data-reveal` attributes.
4. Replace nav with a pattern from `navbar-gallery/` (07 command palette and 10 app topbar fit the coach UI best).
5. Use `icons.svg` via `<use>` for sidebar/feature icons.

See `motion/integrations.md` for the full drop-in guide and the embed-vs-offline decision table.
