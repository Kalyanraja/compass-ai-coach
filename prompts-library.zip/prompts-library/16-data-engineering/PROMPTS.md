# 16 — Data Engineering

Covers pipeline design, warehouse modeling, data quality, orchestration, CDC, and migrations. Placeholder convention: anything in `{{double_curly_braces}}` is user-supplied input — replace it before sending; do not remove the braces for optional fields, leave the value empty instead.

### PROMPT-16-01 — ETL vs ELT Pipeline Design
**Use when:** designing a new data pipeline from a source to a target store.
**Output:** recommended architecture with trade-off analysis, stage diagram, failure modes, open questions.
**Prompt:**
```text
You are a senior data engineer with 10+ years building production pipelines.
CONTEXT: Source system: {{source_system}}. Target: {{target_system}}. Business need: {{business_need}}. Volume estimate: {{volume_estimates}}. Latency requirement: {{latency_requirement}}.
TASK: Design a pipeline and recommend ETL vs ELT with a written trade-off analysis.
CONSTRAINTS:
- Do not propose a tool without naming its concrete role; list one alternative you rejected and why.
- Treat my volume and latency numbers as estimates, not facts; flag what must be measured.
- If information is missing, say "insufficient information" and list exactly what is needed instead of guessing.
- Do not invent connector capabilities; mark any assumed capability "verify against docs".
OUTPUT FORMAT:
1. Recommendation plus trade-off table (3-6 rows).
2. Pipeline diagram (ASCII or numbered stages).
3. Failure mode and recovery plan per stage.
4. Numbered open questions.
5. Pre-production verification plan with named checks.
```

### PROMPT-16-02 — Dimensional Model Review
**Use when:** reviewing a star/snowflake schema before it goes into production.
**Output:** scored review with concrete redesign instructions.
**Prompt:**
```text
You are a dimensional-modeling expert (Kimball methodology).
CONTEXT: Warehouse: {{warehouse}}. Existing schema (tables, keys, grain): {{schema_description}}. Dominant query patterns: {{query_patterns}}.
TASK: Review the dimensional model and produce a scored assessment.
CONSTRAINTS:
- Judge every table against its declared grain; flag any table where the grain is ambiguous or violated.
- Do not redesign for hypothetical future needs; only changes justified by stated query patterns.
- Distinguish facts (from the schema given) from inferences (yours); label each finding F or I.
- Say "insufficient information" where the schema description lacks detail instead of assuming.
OUTPUT FORMAT:
1. Scorecard per design principle (grain, keys, surrogate keys, SCD handling, denormalization): pass / warn / fail with one-line evidence.
2. Ordered list of required changes, most severe first, each with the exact DDL or naming change.
3. What to leave alone and why.
4. Open questions (numbered).
```

### PROMPT-16-03 — Data-Quality Check Suite
**Use when:** defining validation checks for a dataset or pipeline output.
**Output:** executable-style check suite organized by layer, with thresholds and alert semantics.
**Prompt:**
```text
You are a data-quality engineer designing a Great Expectations-style check suite.
CONTEXT: Dataset: {{dataset_description}}. Known past incidents: {{past_incidents}}. Stakeholders who consume it: {{consumers}}.
TASK: Define a check suite covering schema, completeness, uniqueness, validity, and distribution.
CONSTRAINTS:
- Every check must have: name, column/scope, rule, threshold, severity (warn/block), and owner-facing alert message.
- Do not add checks with no plausible failure story; write the failure story in a comment per check.
- Label every threshold as FACT (derived from data provided) or ESTIMATE (your proposal to be tuned).
- Say "insufficient information" for columns you know nothing about; do not invent column semantics.
OUTPUT FORMAT:
1. Table: check name | scope | rule | threshold (FACT/ESTIMATE) | severity.
2. Blocking vs warning policy (one short paragraph).
3. Quarantine strategy for failing records.
4. Rollout plan: shadow mode first, then enforce; state how many runs of green are required.
```

### PROMPT-16-04 — Streaming vs Batch Decision
**Use when:** unsure whether a workload needs a streaming architecture or scheduled batch.
**Output:** decision memo with quantified trade-offs and a recommended default.
**Prompt:**
```text
You are a data architect deciding between streaming and batch processing.
CONTEXT: Workload: {{workload_description}}. Freshness need: {{freshness_requirement}}. Volume and velocity: {{volume_velocity}}. Team skills: {{team_skills}}. Budget ceiling: {{budget}}.
TASK: Produce a decision memo recommending batch, streaming, or a hybrid (e.g., micro-batch), with quantified reasoning.
CONSTRAINTS:
- Default to the simplest option that meets the stated freshness need; the burden of proof is on streaming.
- Quantify operational cost (infra, on-call, debugging complexity) as rough ranges and label them ESTIMATES.
- Do not propose specific stream-processing frameworks until the decision is made; then name at most two candidates.
- Say "insufficient information" if freshness need is undefined, and state what question resolves it.
OUTPUT FORMAT:
1. Decision in one sentence.
2. Comparison table: latency, cost, complexity, failure recovery, exactly-once handling.
3. Trigger conditions under which the decision should be revisited.
4. If streaming is chosen: minimal viable topology plus what you deliberately excluded.
```

### PROMPT-16-05 — dbt Model Review
**Use when:** reviewing dbt models (SQL + YAML) for correctness and maintainability.
**Output:** line-referenced review with severity ratings and suggested refactors.
**Prompt:**
```text
You are a dbt reviewer focused on correctness, performance, and maintainability.
CONTEXT: dbt version and warehouse: {{dbt_version_and_warehouse}}. Models to review: {{model_sql_and_yaml}}. Project conventions: {{conventions}}.
TASK: Review the models as if in a pull request.
CONSTRAINTS:
- Cite the specific model and CTE or line you are commenting on; no generic advice.
- Check in this order: refs/sources usage, materialization choice, incremental logic correctness, test coverage, naming.
- Do not invent dbt features or flags; if a feature name is uncertain, mark it "verify against dbt docs".
- Distinguish blocking issues from style nits; style nits go in a separate section.
- Say "insufficient information" where the surrounding models or sources are unknown and it affects the verdict.
OUTPUT FORMAT:
1. Blocking issues: model, location, problem, exact suggested fix.
2. Non-blocking suggestions.
3. Missing tests list (which model, which test, why).
4. One-paragraph summary verdict: approve / approve-with-fixes / block.
```

### PROMPT-16-06 — Orchestration DAG Design
**Use when:** designing an Airflow/Dagster DAG for a new workflow.
**Output:** task graph with dependencies, idempotency notes, retry and alerting policy.
**Prompt:**
```text
You are an orchestration engineer designing a production DAG.
CONTEXT: Orchestrator: {{airflow_or_dagster_and_version}}. Workflow: {{workflow_description}}. Upstream dependencies: {{upstream_dependencies}}. SLA: {{sla}}.
TASK: Design the DAG: task decomposition, dependencies, scheduling, retries, alerting.
CONSTRAINTS:
- Each task must be idempotent and independently retryable; state the idempotency mechanism per task.
- Do not create tasks finer than one observable unit of work or coarser than one failure domain.
- Define SLAs and alerts per task, not just at DAG level; include who gets paged vs who gets emailed.
- Mark every sensor/external dependency with its timeout and missing-data behavior.
- Do not invent operator parameters; mark uncertain ones "verify against orchestrator docs".
OUTPUT FORMAT:
1. ASCII DAG diagram with task names.
2. Per-task table: name, purpose, idempotency mechanism, retries/backoff, SLA, alert target.
3. Schedule definition and catch-up policy.
4. Failure-scenario walkthrough: what happens when each of 3 named tasks fails.
```

### PROMPT-16-07 — Schema Evolution Strategy
**Use when:** planning how schemas change over time without breaking consumers.
**Output:** versioning policy plus expand/contract migration plan for a given change.
**Prompt:**
```text
You are a data architect owning schema governance.
CONTEXT: System: {{system_and_formats}}. Proposed change: {{schema_change}}. Known consumers: {{consumers}}. Release cadence: {{release_cadence}}.
TASK: Define a schema-evolution policy and a concrete expand/contract plan for the proposed change.
CONSTRAINTS:
- Classify the change as compatible, partially compatible, or breaking, with the reasoning shown.
- Breaking changes require an expand/contract sequence; write each phase with its rollback.
- Do not assume consumers read in lockstep; state how many versions backward must remain readable.
- Label every compatibility assumption as FACT or ASSUMPTION with how to verify it.
- Say "insufficient information" if consumer read patterns are unknown and it changes the plan.
OUTPUT FORMAT:
1. Change classification with evidence.
2. Phase-by-phase plan (expand, migrate, contract), each phase independently deployable.
3. Rollback procedure per phase.
4. Compatibility contract going forward (naming, types, defaults, nullability rules).
5. Verification checklist to run after each phase.
```

### PROMPT-16-08 — Idempotent Backfill Plan
**Use when:** planning a historical data backfill that may be re-run safely.
**Output:** backfill plan with partitioning, dry-run steps, and abort criteria.
**Prompt:**
```text
You are a data engineer planning a production backfill.
CONTEXT: What is being backfilled: {{backfill_scope}}. Target table(s): {{target_tables}}. Time range: {{time_range}}. Constraints: {{constraints_e.g._downtime}}.
TASK: Write a backfill plan that is safe to run, pause, re-run, and abort.
CONSTRAINTS:
- The plan must be idempotent: re-running any completed segment must produce identical state; state the mechanism (e.g., insert-overwrite per partition).
- Segment the backfill (by time partition or key range); give segment sizing logic, not just one size.
- Include a dry-run procedure on one segment and explicit go/no-go criteria before the full run.
- Define abort criteria and the exact cleanup/rollback per stage.
- Label throughput estimates as ESTIMATES and list what measurement would calibrate them.
OUTPUT FORMAT:
1. Segmentation strategy and sizing.
2. Step-by-step runbook with dry-run gate.
3. Monitoring: which metrics, what thresholds trigger abort.
4. Rollback procedure.
5. Post-backfill verification queries and expected results.
```

### PROMPT-16-09 — Data Lineage Documentation
**Use when:** documenting how data flows from sources to consumers.
**Output:** lineage map (table/column level) with gaps flagged.
**Prompt:**
```text
You are a data-governance engineer producing lineage documentation.
CONTEXT: System landscape: {{systems_and_connections}}. Priority datasets: {{priority_datasets}}. Known gaps: {{known_gaps}}.
TASK: Produce a lineage document for the priority datasets, from source through transformations to consumers.
CONSTRAINTS:
- Document table-level lineage first, then column-level only for columns flagged as sensitive or heavily transformed.
- Every edge must be labeled with mechanism (ETL job, dbt model, stream, manual export) — mark any mechanism you inferred as INFERRED.
- Do not draw edges you cannot support; list them under "suspected but unverified" instead.
- Say "insufficient information" where the landscape description is silent and state what to check.
OUTPUT FORMAT:
1. ASCII or table-form lineage graph per dataset.
2. Transformation catalog: each transformation, its logic summary, its owner.
3. Sensitive-data path list.
4. Gap register: what is unknown, who to ask, why it matters.
```

### PROMPT-16-10 — CDC Pipeline Design
**Use when:** designing change-data-capture from a database to downstream systems.
**Output:** CDC architecture with ordering, delivery semantics, and schema-change handling.
**Prompt:**
```text
You are a data engineer designing a CDC pipeline.
CONTEXT: Source database: {{source_db_and_version}}. Capture mechanism available: {{binlog_wal_or_other}}. Downstream sinks: {{sinks}}. Ordering requirements: {{ordering_requirements}}.
TASK: Design the CDC pipeline end to end.
CONSTRAINTS:
- State the delivery semantics per sink (at-least-once vs effectively-once) and the dedup mechanism where needed.
- Handle source schema changes explicitly: how the pipeline behaves and what operator action is required.
- Do not invent connector configuration keys; write the intent and mark exact keys "verify against connector docs".
- Address snapshot (initial load) vs incremental capture as two phases with separate failure handling.
- Label performance estimates as ESTIMATES.
OUTPUT FORMAT:
1. Architecture diagram (capture, buffer, transform, sink).
2. Semantics table: sink | delivery guarantee | dedup/upsert key | ordering.
3. Schema-change runbook.
4. Snapshot phase plan with resume capability.
5. Known limitations and monitoring signals.
```

### PROMPT-16-11 — Big-Query Cost Optimization
**Use when:** warehouse query or storage costs are too high and need a reduction plan.
**Output:** ranked cost-reduction recommendations with expected savings ranges.
**Prompt:**
```text
You are a warehouse cost-optimization specialist.
CONTEXT: Warehouse platform: {{platform}}. Current monthly cost: {{monthly_cost}}. Top expensive queries/jobs: {{expensive_queries}}. Data volume and growth: {{volumes}}. Team constraints: {{constraints}}.
TASK: Produce a cost-reduction plan, ranked by impact-to-effort.
CONSTRAINTS:
- Every recommendation must cite the evidence it is based on; recommendations without evidence go in a "needs telemetry" section.
- Give savings as ranges and label them ESTIMATES with the assumption behind each range.
- Do not recommend architecture rewrites when a configuration or query change achieves most of the gain; show the cheap option first.
- Flag any recommendation that risks query-result changes so it can be regression-tested.
OUTPUT FORMAT:
1. Ranked recommendation table: change | evidence | est. savings | effort | risk.
2. Quick wins (under one day) listed separately.
3. "Needs telemetry" list: what to measure before deciding.
4. 30-day verification plan: which cost metrics to watch and the target.
```

### PROMPT-16-12 — Data Privacy Classification
**Use when:** classifying dataset columns for privacy/compliance handling.
**Output:** column-level classification with handling rules per class.
**Prompt:**
```text
You are a data-privacy engineer classifying a dataset for handling rules.
CONTEXT: Dataset and schema: {{dataset_and_columns}}. Jurisdiction/regime: {{regulatory_regime}}. Intended uses: {{intended_uses}}.
TASK: Classify each column: public, internal, confidential, or restricted (PII/PHI/financial), and assign handling rules.
CONSTRAINTS:
- Classification is based on the column semantics I provide plus the regime; do not downgrade a column because it "seems harmless".
- Where classification depends on context I did not give (e.g., whether IDs are linkable), mark it CONDITIONAL and state the deciding question.
- Every restricted column gets: masking rule, access rule, retention rule, and whether it may leave the production environment.
- Say "insufficient information" for columns with no description rather than defaulting to internal.
OUTPUT FORMAT:
1. Table: column | classification | rationale (one line) | masking | access | retention.
2. Cross-column re-identification risks (combinations that become PII).
3. Handling policy summary per class.
4. Open questions that could change classifications (numbered).
```

### PROMPT-16-13 — Incremental Model Pattern
**Use when:** converting a full-refresh model to incremental (or designing a new one).
**Output:** incremental model template plus correctness checklist and edge-case handling.
**Prompt:**
```text
You are an analytics engineer designing an incremental model.
CONTEXT: Warehouse: {{warehouse}}. Model purpose and grain: {{model_description}}. Source freshness pattern: {{source_pattern}}. Lookback requirement: {{late_arriving_data}}.
TASK: Write the incremental model pattern (logic + config), the merge/insert strategy, and handle late-arriving data.
CONSTRAINTS:
- State the incremental key and watermark strategy explicitly; justify the lookback window against the stated late-arrival behavior.
- Handle the cold start (first run) as a separate case.
- Handle deletes and updates in the source; do not assume append-only unless told.
- Do not invent warehouse-specific merge syntax from memory; write pseudo-SQL where unsure and mark it "verify against warehouse docs".
- Include a backfill-safe mode: how the model behaves when run for a historical range.
OUTPUT FORMAT:
1. Model configuration block (materialization, unique key, incremental strategy).
2. Model SQL with clearly marked incremental vs full-refresh branches.
3. Edge-case table: late data, deletes, schema change, rerun — behavior per case.
4. Correctness checklist: how to prove incrementality matches a full refresh.
```

### PROMPT-16-14 — Source/Sink Connector Review
**Use when:** reviewing a proposed connector configuration before production use.
**Output:** risk-focused review with a hardened configuration and load-test plan.
**Prompt:**
```text
You are a data engineer reviewing a connector configuration (Kafka Connect, Airbyte, Fivetran-custom, or similar).
CONTEXT: Connector type and config: {{connector_and_config}}. Source and destination: {{source_sink}}. Volume: {{volume}}. Failure tolerance: {{failure_tolerance}}.
TASK: Review the configuration for production readiness.
CONSTRAINTS:
- Check: authentication, connection limits, batching, retry/error handling, offset/checkpoint management, schema handling, resource limits.
- Mark every config key you are unsure exists in this connector as "verify against connector docs" — do not invent keys.
- Identify failure modes the config does not cover (network partition, source schema change, destination outage, poison records).
- Give a hardened config diff and explain each changed line in one sentence.
OUTPUT FORMAT:
1. Risk table: risk | severity | evidence from config | mitigation.
2. Hardened configuration diff with per-line rationale.
3. Load/soak test plan: what to measure, pass criteria.
4. Rollout plan: staging duration, rollback trigger.
```

### PROMPT-16-15 — Dead-Letter and Replay Design
**Use when:** designing how a pipeline handles poison records and replay.
**Output:** DLQ design with replay runbook and tooling decisions.
**Prompt:**
```text
You are a data engineer designing failure isolation and replay for a pipeline.
CONTEXT: Pipeline: {{pipeline_description}}. Message/record format: {{record_format}}. Volume and error history: {{volume_and_errors}}. Sinks and their idempotency: {{sink_idempotency}}.
TASK: Design the dead-letter mechanism and the replay procedure.
CONSTRAINTS:
- Define what goes to DLQ vs retry vs fail-the-batch, with explicit criteria.
- DLQ records must retain full original payload, arrival metadata, error reason, and attempt count; specify the envelope.
- Replay must be safe to run multiple times and must not duplicate sink writes; specify the dedup/upsert strategy per sink.
- Define DLQ alerting, triage ownership, and retention; an unmonitored DLQ is a design failure — say why in the design.
OUTPUT FORMAT:
1. Failure-decision flow (criteria, in short table or numbered flow).
2. DLQ envelope schema and storage choice.
3. Replay runbook: step by step, including partial replay by error type or time window.
4. Monitoring: metrics, alert thresholds, and the "DLQ is growing" escalation path.
```

### PROMPT-16-16 — Partition Strategy Review
**Use when:** choosing or reviewing table partitioning in a warehouse or lakehouse.
**Output:** partition-key recommendation with sizing math and query-impact analysis.
**Prompt:**
```text
You are a storage-layout specialist reviewing a partition strategy.
CONTEXT: Table: {{table_description}}. Query patterns: {{query_patterns}}. Volume and growth: {{volume_growth}}. Platform: {{platform}}.
TASK: Recommend a partition key and granularity, or review an existing one.
CONSTRAINTS:
- Show sizing math: partition count, average and worst-case partition size; label all numbers as ESTIMATES with their assumptions.
- Evaluate the strategy against the stated query patterns: which queries prune, which scan everything.
- Call out skew: high-cardinality keys, hot partitions, and small-file problems.
- Do not invent platform partition limits; mark them "verify against platform docs".
- If the existing strategy is fine, say so and give the evidence; do not change for style.
OUTPUT FORMAT:
1. Recommendation (key + granularity) with two rejected alternatives and why.
2. Sizing table with assumptions labeled.
3. Query-impact table: pattern | prunes? | evidence.
4. Migration path from the current layout if a change is needed, with rollback.
```

### PROMPT-16-17 — Data Contract Definition
**Use when:** defining a contract between a data producer and its consumers.
**Output:** data contract document with schema, SLAs, and enforcement points.
**Prompt:**
```text
You are a data-platform engineer drafting a data contract.
CONTEXT: Producer team/system: {{producer}}. Dataset: {{dataset_description}}. Consumers and their criticality: {{consumers}}. Current pain: {{current_pain}}.
TASK: Draft the data contract covering schema, semantics, SLAs, and change policy.
CONSTRAINTS:
- Every field has: type, semantic definition (not just a name), nullability, allowed values or range, and example.
- SLAs must include freshness, volume expectations (min/max records), and a definition of "bad day" per metric.
- Define the change process: notice period, versioning, and what constitutes a breaking change.
- Define enforcement: where checks run (producer side vs pipeline) and who gets paged on breach.
- Label anything you could not derive from the context as "to be confirmed with producer".
OUTPUT FORMAT:
1. Contract header: owner, version, effective date, review cadence.
2. Field table with semantics and constraints.
3. SLA section with measurable definitions.
4. Change-management policy.
5. Breach handling: detection, notification, escalation.
```

### PROMPT-16-18 — Pipeline Observability Design
**Use when:** adding monitoring/alerting to existing or new pipelines.
**Output:** observability spec: metrics, checks, alerts, and runbooks.
**Prompt:**
```text
You are an observability engineer for data pipelines.
CONTEXT: Pipelines: {{pipeline_list}}. Existing tooling: {{monitoring_stack}}. On-call setup: {{oncall_setup}}. Known blind spots: {{known_blind_spots}}.
TASK: Design an observability layer covering freshness, volume, schema, and distribution drift.
CONSTRAINTS:
- Every alert must answer: what broke, for which dataset, since when, and where to look first; draft the alert text accordingly.
- Distinguish data-quality checks (on content) from operational checks (on runs); separate alert routing for each.
- Define anomaly detection only where a static threshold genuinely fails; otherwise prefer static thresholds and say why.
- Include an end-to-end freshness metric from source event time to sink availability, not just job run time.
OUTPUT FORMAT:
1. Metrics/checks catalog: name | type (ops/data) | threshold | severity | alert target.
2. Alert message templates (2-3 examples).
3. Dashboard layout: one page per pipeline plus one summary page; list the panels.
4. Triage runbook skeleton per alert type.
```

### PROMPT-16-19 — Entity Resolution Design
**Use when:** designing deduplication/matching of entities across sources.
**Output:** matching strategy with precision/recall trade-offs and evaluation plan.
**Prompt:**
```text
You are a data engineer specializing in entity resolution.
CONTEXT: Entities and sources: {{entities_and_sources}}. Available identifying attributes: {{attributes}}. Volume and duplicate rate estimate: {{volume_and_dup_rate}}. Tolerance for false merges: {{merge_tolerance}}.
TASK: Design the entity-resolution pipeline: blocking, candidate generation, scoring, merge/split decisions.
CONSTRAINTS:
- Explicitly manage the precision/recall trade-off; state which side the merge_tolerance pushes toward and design scoring thresholds accordingly.
- Every match rule must be explainable in one sentence; no black-box thresholds without rationale.
- Define how merged clusters can be un-merged later; merges must be reversible.
- Propose evaluation: how to build a labeled sample and which metrics to compute; label target numbers as ESTIMATES.
- Say "insufficient information" where attribute quality is unknown and it changes the design.
OUTPUT FORMAT:
1. Pipeline stages with rationale per stage.
2. Blocking strategy and why it fits the volume.
3. Scoring model (rules or weighted) with threshold rationale.
4. Reversibility design.
5. Evaluation plan and expected metric ranges (ESTIMATES).
```

### PROMPT-16-20 — Legacy DB to Warehouse Migration
**Use when:** planning migration of a legacy database workload into a warehouse.
**Output:** phased migration plan with parity checks and cutover criteria.
**Prompt:**
```text
You are a migration lead moving workloads from a legacy database to a warehouse.
CONTEXT: Legacy system: {{legacy_db}}. Workloads to migrate: {{workloads}} (reports, ETL, apps). Target warehouse: {{target_warehouse}}. Hard deadline: {{deadline}}.
TASK: Produce a phased migration plan ending in decommissioning the legacy workloads.
CONSTRAINTS:
- Phase 0 is always discovery: inventory every object (tables, views, jobs, reports) and classify by migration difficulty; do not skip to building.
- Each phase must have explicit entry/exit criteria and a parity-check method comparing legacy vs new outputs.
- Identify what should NOT be migrated (e.g., OLTP write paths) and state the alternative.
- Cutover requires a rollback window; define it and the trigger criteria for invoking rollback.
- Label all effort and duration numbers as ESTIMATES with assumptions.
OUTPUT FORMAT:
1. Discovery inventory template and classification rules.
2. Phased plan with entry/exit criteria per phase.
3. Parity-check specification: queries, tolerance for numeric differences, sign-off owner.
4. Cutover and rollback runbook.
5. Risk register with mitigations.
