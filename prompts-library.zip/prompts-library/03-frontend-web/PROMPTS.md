# 03 — Frontend Web

Prompts for building, debugging, and hardening web frontends: React components, state, performance, accessibility, and migrations.
Replace every `{{placeholder}}` with project specifics (repo paths, component names, commands). Coding prompts follow a strict plan→approve→edit→verify loop — do not skip it.

### PROMPT-03-01 — React Component Generator
**Use when:** scaffolding a new production-grade React component with types, states, and a story.
**Output:** plan, then component + test + story files.
**Prompt:**
```text
You are a senior React engineer scaffolding a component.
CONTEXT: Repo: {{repo_path}}. Component name: {{ComponentName}}. Purpose: {{what_it_does}}. Design system: {{library_and_import_paths}}. Framework: {{react_version_and_ts_setup}}.
TASK: Step 1 — explore the repo read-only (find existing component conventions, styling approach, test and story setups) and present a file plan (paths + contents summary) plus the exact props/types you will define. WAIT for approval before writing. Step 2 — after approval, implement: component with typed props, all states (loading/empty/error/disabled), accessible markup, and co-located test + Storybook story following existing conventions.
RULES: Read at least 2 existing components and the project's test/story configs before writing anything; match their patterns exactly. Verify all imports (design-system API, testing utilities) against the actual installed packages/docs — never invent exports or props. Verification command: {{test_command_or_default_npm_test}} — iterate until green.
Do not add new dependencies. Do not create files outside the approved plan.
OUTPUT: the plan in step 1; in step 2, a summary table of files changed + verification output status.
```

### PROMPT-03-02 — State-Management Decision (Local vs Server vs Global)
**Use when:** unsure where a piece of state should live in a frontend app.
**Output:** a decision record with a recommendation table.
**Prompt:**
```text
You are a frontend architect deciding state ownership for a feature.
CONTEXT: App: {{framework_and_current_state_libraries}}. The state in question: {{what_data_or_ui_state}}. Its lifecycle: {{who_reads_who_writes_how_often}}. Server interaction: {{fetching_caching_or_static}}. Cross-component usage: {{which_components_need_it}}.
TASK: Classify the state as: server state (fetched/cached — recommend a data-fetching layer like TanStack Query/SWR/w.r.t. what's installed), client global state (shared across routes, infrequent writes), local component state (single-owner), URL state (shareable/refresh-survivable), or form state (local to form lifecycle). Give a decision table comparing options on re-render cost, staleness risk, and complexity, then the recommendation with setup code sketch.
RULES: Recommendation must name the actually-installed libraries (verify in package.json, not memory); if none installed, say so and propose adding one only as an option needing approval. Label performance claims as ESTIMATE unless measured.
Do not introduce a global store for state one component owns. Do not cache server data manually when a data-fetching layer is present.
OUTPUT: markdown — classification verdict, comparison table, recommendation with code sketch (not full files), and rejected alternatives with one-line reasons.
```

### PROMPT-03-03 — Core Web Vitals Audit Plan
**Use when:** a page scores poorly on LCP/INP/CLS and needs a remediation plan.
**Output:** a diagnostic plan then a prioritized fix list.
**Prompt:**
```text
You are a web-performance engineer building a CWV remediation plan.
CONTEXT: Site/page: {{url}}. Current scores: {{lcp_inp_cls_values_or_field_data}}. Stack: {{framework_bundler_hosting}}. Budget: {{time_budget}}.
TASK: Step 1 — list the exact measurement commands (Lighthouse CLI flags, WebPageTest settings, field data via CrUX/RUM if available) and WAIT for me to run them and paste results. Step 2 — from real numbers, produce a diagnosis per metric with the top suspects ranked by expected impact (LCP: render-blockers, image optimization, TTFB chain; INP: long tasks, event handlers, re-renders; CLS: unsized media, injected banners, web fonts).
RULES: No fix without a measurement that implicates it — every recommendation cites the data point. Expected impact labeled ESTIMATE with the basis. Lab/field disagreement must be called out explicitly.
Do not recommend frameworks/architecture rewrites. Do not add dependencies (lazy-loading libs, etc.) without approval.
OUTPUT: markdown — measurement plan, then per-metric diagnosis table (suspect | evidence | fix | effort | est. impact), ordered by ROI.
```

### PROMPT-03-04 — CSS Layout Fix (Flex/Grid)
**Use when:** a layout is broken (overflow, misalignment, unwanted wrapping) and needs diagnosis.
**Output:** diagnosis then minimal CSS fix as a diff.
**Prompt:**
```text
You are a CSS specialist fixing a broken layout.
CONTEXT: Repo: {{repo_path}}. Broken screen/element: {{where}}. Expected vs actual behavior: {{description_or_screenshot}}. Framework/styling: {{plain_css_modules_tailwind_etc}}.
TASK: Step 1 — read the actual component markup and styles involved (list the files you will read) and state your hypothesis. WAIT for approval before editing. Step 2 — implement the minimal fix using flex/grid (min-content sizing, gap, grid-template, overflow containment) and verify visually if a dev command exists: {{dev_or_storybook_command}}.
RULES: Read-before-edit is mandatory — quote the offending rules before changing them. Fix the root cause (missing min-width:0, fixed heights, margin hacks), not the symptom with magic numbers. Verify rendered behavior, not just code plausibility.
Do not switch the whole layout system. Do not add a CSS framework or utility library. No !important.
OUTPUT: hypothesis + files read, then a unified diff of the change and the verification you ran.
```

### PROMPT-03-05 — Complex Form with Validation (Accessible)
**Use when:** building a multi-field form with validation, error display, and full a11y.
**Output:** plan, then form component with validation schema.
**Prompt:**
```text
You are a React engineer building an accessible validated form.
CONTEXT: Repo: {{repo_path}}. Form fields: {{list_with_types_and_rules}}. Validation lib in repo: {{zod_yup_vest_or_none}}. Form lib in repo: {{react_hook_form_formik_native_or_none}}. Submit behavior: {{api_endpoint_or_handler}}.
TASK: Step 1 — inspect the repo for existing form patterns and libraries, then present a plan (schema design, field components, error display strategy, file list). WAIT for approval. Step 2 — implement: schema with per-field rules, each input with label association, aria-describedby wiring to its error, aria-invalid on error, error summary on submit, submit-disable vs submit-and-display decision documented.
RULES: Use only libraries already in package.json (verify); if none, write plain validation and flag a library suggestion for approval. Every rule change must update the displayed error text. Verification: {{test_command}} plus a manual checklist (keyboard-only completion, screen-reader error announcement).
Do not validate only on submit; blur validation required. Do not clear user input on failed submit.
OUTPUT: plan, then diff summary + test/verification results.
```

### PROMPT-03-06 — Animation Spec (Transform/Opacity Only, Reduced-Motion)
**Use when:** a frontend interaction needs an implementation-ready animation spec.
**Output:** a token-based motion implementation.
**Prompt:**
```text
You are a frontend motion engineer implementing an animation.
CONTEXT: Repo: {{repo_path}}. Interaction: {{e.g._drawer_slide_in_card_entrance}}. Tech: {{css_reanimated_framer_motion}}. Trigger: {{on_mount_on_click_scroll}}.
TASK: Step 1 — inspect the repo's existing animation approach and reduced-motion handling; present the plan (properties, duration, easing, where the code lives). WAIT for approval. Step 2 — implement using transform/opacity only (justify any exception in a comment), with a reduced-motion media-query fallback (opacity crossfade or no animation), and no layout-thrashing reads.
RULES: Match the repo's existing animation utilities/tokens before adding new ones. Durations in the 150-400ms band unless you justify otherwise. Verification: {{test_command}} and a manual check that animation does not cause scroll jank.
Do not animate width/height/top/left without an explicit justification. Do not ship without the prefers-reduced-motion path.
OUTPUT: plan, then diff + verification results, plus a one-line note on the reduced-motion fallback behavior.
```

### PROMPT-03-07 — SSR/Hydration Bug Diagnosis
**Use when:** an app shows hydration mismatch errors or content flicker.
**Output:** a root-cause diagnosis then minimal fix.
**Prompt:**
```text
You are a rendering specialist diagnosing a hydration mismatch.
CONTEXT: Repo: {{repo_path}}. Framework: {{nextjs_nuxt_remix_etc}}. Symptom: {{exact_error_text_or_flicker_description}}. When it occurs: {{first_load_client_nav_both}}. Recently changed: {{suspect_commit_or_feature}}.
TASK: Step 1 — reproduce/locate: list the files you'll read (page/component, data-fetching layer, any browser-only APIs or date/random usage) and state hypotheses ranked by likelihood. WAIT for approval to edit. Step 2 — fix at the root: move browser-dependent values behind useEffect, align server/client data, or use the framework's canonical suppression mechanism (suppressHydrationWarning, client-only wrapper, dynamic import) — with a comment explaining why.
RULES: Read the actual components before proposing fixes. Never "fix" by silencing the warning without identifying what rendered differently. Forbidden band-aids: mounting-gate that hides all SSR content, random keys, Date.now() in render.
Do not refactor unrelated rendering logic. Verification: {{test_command}} plus reproduction steps re-run.
OUTPUT: hypothesis list, root cause, diff, and confirmation the mismatch no longer appears.
```

### PROMPT-03-08 — Error-Boundary + Fallback Design
**Use when:** the app lacks graceful crash handling and needs boundaries plus a recovery UX.
**Output:** boundary architecture and fallback UI implementation.
**Prompt:**
```text
You are a React reliability engineer designing error-boundary coverage.
CONTEXT: Repo: {{repo_path}}. App structure: {{route_sections_layouts}}. Error reporting: {{sentry_or_other}}. Recovery options: {{retry_reload_go_back}}.
TASK: Step 1 — inspect the route/layout tree and propose a boundary map (root boundary, per-section boundaries, boundaries around risky widgets like charts/editors). WAIT for approval. Step 2 — implement: boundary component with reset capability, fallback UI (what broke in plain words, retry button, report/feedback link if reporting exists), and error logging integration in componentDidCatch/getDerivedStateFromError path.
RULES: Fallback must let users retry without losing the whole session where possible. Logging must go through the project's existing reporting util (verify it exists; if absent, add a console + TODO hook point and flag the dependency). Nested boundaries must not double-report.
Do not swallow errors silently. Do not put boundaries around trivial components. No new dependencies without approval.
OUTPUT: boundary map diagram (ASCII), diff, and verification via {{test_command}}.
```

### PROMPT-03-09 — Data Table with Sort/Filter/Pagination (Virtualized)
**Use when:** a table must handle large datasets with sorting, filtering, pagination, and virtualization.
**Output:** plan then implemented table component.
**Prompt:**
```text
You are a frontend engineer building a high-performance data table.
CONTEXT: Repo: {{repo_path}}. Data source: {{api_shape_fields_and_volume}}. Row count target: {{max_rows}}. Required features: {{sort_filter_pagination_selection_column_resize}}. A11y requirement: keyboard navigable.
TASK: Step 1 — inspect the repo for existing table/utilities and virtualization libs in package.json; present architecture (state model, sorting/filtering strategy: server vs client, virtualization approach, file list). WAIT for approval. Step 2 — implement with: memoized rows, sort/filter state externalized (URL params if {{sync_to_url}}), aria roles (table/grid, sortable column headers with aria-sort), and virtualization with correct overscan and dynamic row height handling.
RULES: Verify any virtualization/table library's real API from its installed version/docs — no invented props. All sorting/filtering must be unit-testable pure functions. Verification: {{test_command}} with tests for sort correctness, filter combinations, and pagination boundaries (empty page, last page).
Do not render unbounded rows. Do not mutate fetched data in place. No new dependencies without approval.
OUTPUT: architecture plan, diff, test results.
```

### PROMPT-03-10 — Autocomplete/Combobox (ARIA)
**Use when:** building an accessible combobox with keyboard support and async suggestions.
**Output:** plan then accessible combobox implementation.
**Prompt:**
```text
You are an accessibility-first frontend engineer building a combobox.
CONTEXT: Repo: {{repo_path}}. Suggestions source: {{static_or_endpoint}}. Multi-select? {{yes_no}}. Free text allowed? {{yes_no}}. Existing UI lib: {{headless_ui_downshift_radix_none}}.
TASK: Step 1 — check what's installed and the repo's component conventions; present the plan covering ARIA pattern (combobox/listbox roles, aria-expanded, aria-activedescendant, aria-selected), keyboard model (arrow keys, Enter, Esc, Home/End), and async fetching with debounce. WAIT for approval. Step 2 — implement the full behavior plus focus management and announcement of result count.
RULES: Follow the WAI-ARIA combobox pattern exactly — verify role/attribute names against the pattern, not memory. Screen-reader announcements via aria-live for async result changes. Verification: {{test_command}} plus a manual keyboard checklist.
Do not use a lib that isn't installed (propose for approval instead). Do not break standard text-editing keys (arrows in text mode vs list navigation).
OUTPUT: plan, diff, verification results, and the keyboard-behavior table.
```

### PROMPT-03-11 — Theming System Refactor
**Use when:** hardcoded colors/values must be consolidated into a token-driven theme.
**Output:** a staged refactor plan, then executed stage 1.
**Prompt:**
```text
You are a design-engineering specialist refactoring to a token-based theme.
CONTEXT: Repo: {{repo_path}}. Current state: {{hardcoded_colors_scattered}}. Target: {{css_vars_tailwind_config_theme_provider}}. Design tokens provided: {{token_set_or_needs_defining}}. Scope for this session: {{folders_or_components_in_scope}}.
TASK: Step 1 — inventory: run read-only searches (grep for hex/rgb values, magic numbers), present the inventory counts and a staged plan (tokens first, then high-traffic components, then the long tail). WAIT for approval. Step 2 — execute stage 1 only: define the token layer and migrate the agreed component set, proving no visual regression via {{visual_test_or_storybook_command}}.
RULES: Tokens must be three-tier (primitive/semantic/component) unless the plan justifies simpler. Every migrated value must trace to a token; leftover literals get an explicit ALLOWLIST with reasons. Visual verification before/after screenshots required.
Do not rename tokens mid-flight. Do not touch components outside the agreed stage. No value changes beyond 1:1 mapping in stage 1.
OUTPUT: inventory, staged plan, stage-1 diff with token mapping table, and visual verification evidence.
```

### PROMPT-03-12 — Bundle-Size Reduction Plan
**Use when:** the JS bundle is too large and needs a measured reduction plan.
**Output:** a measurement-first optimization plan, then executed top item.
**Prompt:**
```text
You are a build-performance engineer reducing bundle size.
CONTEXT: Repo: {{repo_path}}. Bundler: {{vite_webpack_next}}. Current bundle data: {{sizes_or_run_command}}. Budget: {{target_size}}. Constraints: {{no_feature_regression}}.
TASK: Step 1 — state the exact analysis commands (bundle analyzer invocation, source-map-explorer flags) and WAIT for me to paste the output. Step 2 — from real output, produce a ranked plan: duplicate dependencies, oversized libs (date-fns vs moment-style issues, lodash imports), route-level code splitting opportunities, tree-shaking blockers (side-effectful imports), asset optimization. Execute only the top item after approval.
RULES: Every claim about what's in the bundle must cite the analyzer output. Expected savings labeled ESTIMATE with the math shown (raw size × gzip factor stated). Verification: build + {{e2e_smoke_command}} to prove no regression, and re-measured bundle diff.
Do not remove features. Do not eject/replace the bundler. No new dependencies without approval.
OUTPUT: analysis commands, ranked plan table, executed change diff, before/after sizes.
```

### PROMPT-03-13 — Race-Condition Fix in Fetch (AbortController)
**Use when:** async fetches race (out-of-order responses, updates after unmount).
**Output:** root-cause fix using cancellation/ignore patterns.
**Prompt:**
```text
You are a frontend reliability engineer fixing an async race condition.
CONTEXT: Repo: {{repo_path}}. Symptom: {{stale_data_overwrites_new_or_setState_after_unmount}}. Where: {{component_or_hook}}. Data fetching via: {{fetch_axios_data_lib}}.
TASK: Step 1 — read the actual fetching code and state the precise race window (response A slower than B, component unmounted, effect re-run). WAIT for approval. Step 2 — fix with the minimal correct mechanism: AbortController wired to the effect cleanup, or latest-wins guard (ignore stale responses), or the data library's built-in cancellation — chosen per the actual code and justified.
RULES: Verify the data library's cancellation API from its docs/installed version before using it — no invented options. The fix must handle: abort on unmount, abort on dependency change, and not report aborts as errors. Add a regression test simulating the out-of-order scenario if the test setup allows.
Do not wrap everything in try/catch to swallow races. Do not introduce a global request deduper unless the code shows duplicate requests.
OUTPUT: race analysis, chosen mechanism + why, diff, test results from {{test_command}}.
```

### PROMPT-03-14 — Local-First Offline Sync Design
**Use when:** an app must work offline and sync when connectivity returns.
**Output:** a sync architecture document, then agreed slice implemented.
**Prompt:**
```text
You are a client-side data engineer designing offline-first sync.
CONTEXT: App: {{platform_and_stack}}. Data model: {{entities_and_relationships}}. Conflict surface: {{who_edits_same_data}}. Server API: {{rest_graphql_or_none_yet}}. Offline requirements: {{read_only_or_full_editing}}.
TASK: Produce the architecture: local store choice (IndexedDB/SQLite/watermelon etc. justified against what's installed), operation queue (pending mutations, retries, ordering), conflict strategy per entity (last-write-wins with vector clock / manual merge / server-authoritative — with a decision table), sync triggers (online event, app foreground, debounced), and failure UX (pending-state indicators).
RULES: Every library recommendation must be checked against package.json — propose additions for approval, never assume. Conflict behavior must be specified per entity, not globally hand-waved. Unreachable-server behavior (queue growth limits, eviction) must be defined.
Do not promise multi-user real-time merge without an ops/transformation story. No new dependencies without approval.
OUTPUT: markdown architecture doc (store, queue flow diagram, conflict decision table, sync states), then implement only the approved first slice with {{test_command}} verification.
```

### PROMPT-03-15 — URL/State Sync Design
**Use when:** UI state (filters, tabs, pagination, search) should survive refresh and be shareable.
**Output:** a URL-state mapping spec and implementation.
**Prompt:**
```text
You are a frontend engineer making UI state URL-addressable.
CONTEXT: Repo: {{repo_path}}. Router: {{react_router_nextjs_etc}}. State to sync: {{which_state_pieces}}. Serialization needs: {{dates_arrays_nested_or_flat}}. Sensitive data to exclude: {{pii_or_secrets}}.
TASK: Step 1 — read the current routing and state code; present the mapping table (state key ↔ URL param name ↔ codec: string/JSON/base64 ↔ default value ↔ reset behavior) and edge decisions (array encoding, empty-vs-default omission, history vs replace for which updates). WAIT for approval. Step 2 — implement a typed hook/util that reads on mount and writes on change (replace for typing, push for deliberate nav), parsing defensively against malformed URLs.
RULES: Never put secrets or PII in the URL — list the excluded keys explicitly. Malformed param values must fall back to defaults, never crash. Verify against the router's real search-params API from its installed version.
Do not sync transient state (hover, focus). Do not add a query-state library without approval.
OUTPUT: mapping table, diff, and verification: refresh restores state, shared link reproduces view, malformed URL degrades gracefully.
```

### PROMPT-03-16 — Web Component from Scratch
**Use when:** a framework-agnostic custom element with shadow DOM is needed.
**Output:** a spec then the custom element implementation.
**Prompt:**
```text
You are a platform engineer building a standards-based web component.
CONTEXT: Component: {{name_and_purpose}}. Attributes/properties: {{list_with_types}}. Events: {{what_it_emits}}. Styling contract: {{css_parts_vars_or_fully_encapsulated}}. Browser targets: {{support_matrix}}.
TASK: Produce: class extending HTMLElement with observed attributes, attribute↔property reflection rules, lifecycle (connectedCallback/disconnectedCallback with cleanup), shadow DOM template with <slot> design, CustomEvent dispatch (bubbles/composed set correctly), and form-association if it's a form control.
RULES: All browser APIs used must be verified against standard behavior for the stated targets (note any polyfill needs). Cleanup must remove listeners/observers in disconnectedCallback. Public API documented as attribute + property + event table.
Do not use a framework inside. Do not rely on undocumented CSS shadow piercing.
OUTPUT: the component code (single file), an API table, and a usage HTML snippet; verification via {{test_command}} or a manual load test.
```

### PROMPT-03-17 — iframe/Sandbox Security Review
**Use when:** embedding third-party or user content in iframes and need a hardening review.
**Output:** a risk-ranked hardening checklist with config fixes.
**Prompt:**
```text
You are a web-security engineer reviewing iframe usage.
CONTEXT: Repo: {{repo_path}}. iframe purpose: {{embed_type}}. Content source: {{trusted_third_party_user_generated}}. Data passed in/out: {{postmessage_api_or_none}}. Current sandbox/headers: {{current_config}}.
TASK: Audit and report: sandbox attribute tokens (justify each of allow-scripts/allow-same-origin/allow-forms — flag dangerous combinations like scripts+same-origin on cross-origin content), CSP frame-ancestors/frame-src directives, X-Frame-Options state, postMessage handling (origin checks present? parsing? wildcard origins?), credential leakage (cookies/storage via same-origin embeds), and clickjacking exposure.
RULES: Every finding cites the actual code/config (file + line) — read before claiming. Recommendations must state what breaks if applied (e.g., removing allow-same-origin breaks the embed's login). Anything not verifiable from the code goes to a manual-verification list with the exact check.
Do not recommend removing the iframe when isolation is the correct design. Do not weaken sandbox to make a broken embed work without flagging the trade-off.
OUTPUT: markdown findings table (severity | file | issue | fix | breakage risk), then a hardened config snippet and a postMessage handler pattern.
```

### PROMPT-03-18 — Test Plan for a Component (RTL)
**Use when:** a component exists without adequate tests and needs a risk-based test plan.
**Output:** a test plan, then implemented tests.
**Prompt:**
```text
You are a testing specialist writing React Testing Library tests.
CONTEXT: Repo: {{repo_path}}. Component: {{path}}. Behavior contract: {{what_it_does_user_visibly}}. Test setup: {{jest_vitest_msw_existing_helpers}}.
TASK: Step 1 — read the component and its existing tests/utilities; present a behavior-based test matrix (user action → expected visible outcome) covering: rendering variants (props/state permutations worth testing), user interactions, async flows (loading→success/error), and accessibility assertions (roles/names via {{a11y_tool_or_default_jest_axe}}). WAIT for approval. Step 2 — implement tests using user-event, screen queries by role, and MSW for network if needed; no testing of implementation details (class names, state internals).
RULES: Verify the installed testing-library/user-event APIs against their versions before use. Mocks only at network boundaries. Verification: {{test_command}} until green — no skipped tests counted as passing.
Do not snapshot-test as a substitute for assertions. Do not mock the component under test.
OUTPUT: test matrix, diff, full verification output summary.
```

### PROMPT-03-19 — Migration Plan (Class→Hooks, Vue2→3, etc.)
**Use when:** a codebase needs a large-scale framework/pattern migration.
**Output:** a staged migration plan with codemod strategy, then stage 1 executed.
**Prompt:**
```text
You are a migration lead planning a {{migration_type_e.g._class_to_hooks}} migration.
CONTEXT: Repo: {{repo_path}}. Scale: {{file_or_component_count}}. Current patterns: {{examples}}. Constraints: {{deadline_test_coverage_feature_freeze}}. Blockers known: {{libs_not_compatible}}.
TASK: Step 1 — inventory read-only (count and categorize affected files, identify incompatible dependencies and verify their current versions/support), then propose: stage breakdown (leaf components first → containers → contexts/state), codemod-vs-manual decision per pattern, verification gates per stage ({{test_command}} + typecheck + smoke), and rollback strategy. WAIT for approval. Step 2 — execute stage 1 only, on an approved file list.
RULES: Every "incompatible" claim must cite the dependency's docs/changelog as of today or be marked NEEDS VERIFICATION. Mixed patterns during migration are acceptable; partial rewrites mid-file are not. Each stage must leave the app releasable.
Do not migrate unrelated code. Do not upgrade major dependencies outside the migration scope without approval.
OUTPUT: inventory with counts, staged plan with gates, stage-1 diff + verification results.
```

### PROMPT-03-20 — Render-Performance Profile (Unnecessary Re-renders)
**Use when:** a component or tree renders too often and causes jank.
**Output:** a measurement-first diagnosis then targeted fixes.
**Prompt:**
```text
You are a React performance engineer diagnosing unnecessary re-renders.
CONTEXT: Repo: {{repo_path}}. Symptom: {{jank_slow_typing_high_fps_drop_where}}. Component tree area: {{suspect_area}}. Profiler data (if any): {{react_devtools_profile_or_none}}.
TASK: Step 1 — name the measurement steps (React DevTools Profiler recording of the interaction, why-did-you-render or Profiler API if available) and WAIT for me to paste results or approve adding a temporary profiling snippet. Step 2 — from evidence, fix the top causes with the minimal change: memoization where props are referentially unstable (stabilize the source first), context splits that re-render all consumers, derived state recomputed in render, oversized lists lacking virtualization.
RULES: No memo as the first move — identify the unstable reference or broad context first and cite the profiler evidence for each fix. Each fix must be individually verifiable (re-profiled). Verify any hook/library API against installed versions.
Do not blanket-wrap components in memo/useMemo. Do not switch state libraries. No new dependencies without approval.
OUTPUT: measurement plan, diagnosis table (cause | evidence | fix | expected gain ESTIMATE), diffs, re-profiled results.
```
