# 02 — UX/UI Design

Prompts for evaluating, generating, and specifying interface design: heuristics, design systems, states, accessibility, motion, and handoff quality.
Replace every `{{placeholder}}` with your own project detail; where a prompt asks for an artifact (screenshot, tokens file, screen list), paste it or give a file path.

### PROMPT-02-01 — Heuristic Evaluation (Nielsen)
**Use when:** you have a screen, flow, or URL to evaluate against Nielsen's heuristics.
**Output:** severity-ranked heuristic findings.
**Prompt:**
```text
You are a senior UX evaluator running a Nielsen heuristic evaluation.
CONTEXT: Interface: {{description_or_screenshot_or_url}}. User goal: {{primary_task}}. Platform: {{web_ios_android}}. User sophistication: {{audience}}.
TASK: Evaluate against all 10 Nielsen heuristics: visibility of status, system↔world match, user control, consistency, error prevention, recognition over recall, flexibility, aesthetic minimalism, error recovery, help. For each heuristic, report the 1-3 most concrete violations you can point to.
RULES: Every finding must reference a specific visible element or step ("the Save button on the billing form"), not generic advice. Rate severity 0-4 (0=no issue, 4=blocks task) with a one-line justification. If the evidence doesn't show a violation, say "no violation observed" — do not pad.
Do not propose redesigns in this pass; findings only, each with a one-line fix direction.
OUTPUT: markdown table: Heuristic | Finding (element + evidence) | Severity | Fix direction, sorted by severity descending, then top-3 priorities paragraph.
```

### PROMPT-02-02 — Design-System Audit
**Use when:** a codebase has accumulated inconsistent UI and needs a design-system gap analysis.
**Output:** an audit table of components with divergence report.
**Prompt:**
```text
You are a design-system lead auditing UI consistency across a codebase.
CONTEXT: Repo: {{repo_path}}. Framework: {{react_vue_etc}}. Styling approach: {{css_modules_tailwind_styled}}. Existing design system (if any): {{library_or_none}}.
TASK: First, list the read-only exploration commands you will run (e.g., glob for component dirs, count button/color variants) and WAIT for approval. After approval: inventory all reusable components, then audit for divergence — components solving the same problem in multiple ways (buttons, modals, form inputs, spacing scales, color values).
RULES: Read files before claiming anything about them; quote file paths and line-level evidence for every divergence. Verify class names and token values against the actual files, never from memory. If a component exists in the design-system library, compare against its real API (docs/code), not your assumption.
Do not refactor or create shared components in this pass — audit output only.
OUTPUT: markdown — component inventory table (name, file, variants), divergence table (pattern | divergent implementations | files | recommended canonical), ending with top-5 consolidation priorities.
```

### PROMPT-02-03 — Design Tokens Generator
**Use when:** starting or normalizing a token system (color, spacing, type, radius).
**Output:** a token hierarchy in JSON plus usage rules.
**Prompt:**
```text
You are a design-system engineer generating a design-token architecture.
CONTEXT: Product: {{product_name}}. Existing brand inputs: {{colors_typography_or_none}}. Platforms: {{web_ios_android}}. Theming needs: {{light_dark_or_more}}. Token format target: {{css_vars_json_style_dictionary}}.
TASK: Produce a three-tier token system: primitive (raw values), semantic (background-primary, surface-raised, text-muted), component-level (button-primary-bg). Include color scales (each base hue as 50-950 steps with computed contrast-safe pairs), spacing scale, type scale, radius, elevation.
RULES: Every color step must state its intended contrast usage (e.g., "700 for text on 50") and WCAG level it targets — label computed ratios as COMPUTED (formula) or ESTIMATE. Dark-mode tokens must be derived as inversions with reasoning, not arbitrary new values.
Do not pick brand colors not present in CONTEXT — if none given, use neutral placeholders and say so. Do not flatten the tiers.
OUTPUT: JSON code block with `$` comment-free valid JSON (primitive/semantic/component nested), then a markdown usage-rules section (naming, tier-access rules, "never reference primitives in components").
```

### PROMPT-02-04 — Onboarding Flow Design
**Use when:** designing a first-run experience for a new product or feature.
**Output:** a step-by-step onboarding spec with metrics.
**Prompt:**
```text
You are a product designer designing an activation-focused onboarding flow.
CONTEXT: Product: {{product_name}}. Aha-moment: {{aha_moment_definition}}. Required permissions/data: {{what_we_need_from_user}}. User entry context: {{where_users_come_from}}. Competitor reference (optional): {{what_to_beat_or_avoid}}.
TASK: Design the flow: entry trigger, each step (screen purpose, single action, copy, skip-ability), progressive-disclosure plan (what waits until later), permission-request timing with pre-prompt rationale, and the activation metric per step with drop-off decision rules.
RULES: Max 5 steps before first value — justify every step as "removes a real failure mode" or cut it. Every permission ask needs a value-exchange line shown to the user before the system prompt. Steps labeled REQUIRED vs OPTIONAL with reasoning.
Do not design carousel intros with no user action. Do not ask for account creation before value is shown unless CONTEXT proves otherwise.
OUTPUT: markdown — flow table (step | purpose | action | copy | required | activation metric), then a drop-off contingency plan (what we show/change if step N loses >X%).
```

### PROMPT-02-05 — Empty/Error/Success States Trio
**Use when:** a screen or flow exists only in its happy state and needs the other three.
**Output:** a state matrix with copy and actions per state.
**Prompt:**
```text
You are a product designer specifying the full state matrix for a feature.
CONTEXT: Feature/screen: {{screen_description}}. User's goal on this screen: {{user_goal}}. What can be empty: {{lists_data_searches}}. Failure modes known: {{known_error_cases_or_unknown}}. Platform: {{platform}}.
TASK: For each element that has states, define FOUR states: empty (first-use vs cleared — different copy), loading (skeleton specifics, no fake progress), error (user-actionable vs system, with retry path), success (confirmation and next step). Each state: headline copy, body copy, primary/secondary action, and whether it blocks or defers.
RULES: Empty states must offer one forward action, never a dead end. Error copy states what happened and what the user can do — no "something went wrong" alone. If a failure mode is unknown, list it as "needs engineering input" rather than inventing behavior.
Do not reuse the same illustration/CTA across different empty states without reason. Do not use toast-only for destructive-action failure.
OUTPUT: markdown table per element: Element | State | Headline | Body | Actions | Blocking?, then a copy-voice note (2 lines).
```

### PROMPT-02-06 — Dark-Mode Color Scale
**Use when:** an existing light palette needs a principled dark counterpart.
**Output:** a mapped light→dark token table with contrast verification.
**Prompt:**
```text
You are a color-systems designer building a dark theme from a light one.
CONTEXT: Light palette: {{token_names_and_values}}. Platforms: {{web_ios_android}}. Brand constraints: {{must_keep_colors}}. Target WCAG level: {{AA_or_AAA}}.
TASK: For every light token, produce the dark counterpart using these rules: invert elevation semantics (surfaces get lighter as they rise), desaturate elevated surfaces ~10-20%, never use pure black (#000), scale text contrast to meet the stated WCAG level, keep brand accents within accessibility-safe usage pairs.
RULES: Present each mapping with its intended usage pair (text token on surface token) and state the WCAG level it must meet; label contrast ratios COMPUTED (with the formula inputs) or ESTIMATE — never present an unverified ratio as passing. Flag any brand color that cannot reach AA and give the closest compliant alternative.
Do not invent new brand hues. Do not apply the same inversion rule uniformly where elevation semantics differ (modals vs page bg).
OUTPUT: markdown table: Light token | Value | Dark token | Value | Usage pair | Target WCAG | Ratio (labeled), then a rules section on elevation inversion and accent usage.
```

### PROMPT-02-07 — Microcopy Rewrite
**Use when:** existing UI copy is vague, robotic, or blame-y and needs rewriting.
**Output:** before/after copy table with rationale.
**Prompt:**
```text
You are a UX writer rewriting microcopy for clarity and tone.
CONTEXT: Product voice: {{voice_attributes}}. Audience: {{audience}}. Existing copy with location: {{paste_strings_with_where_they_appear}}. Locale: {{language}}.
TASK: Rewrite each string in three passes: (1) accurate — state what happened and what to do, (2) human — plain words, no jargon or internal codes, no blame ("you entered" → "this field needs"), (3) concise — under {{max_chars_or_default_60}} chars where the UI allows; if a constraint is unknown, mark it NEEDS LENGTH CHECK.
RULES: Every error message must contain: what happened, why (if knowable), the fix or next action. Preserve all legally required text verbatim and mark it DO NOT EDIT. If meaning of the original is ambiguous, list it under "needs product decision" instead of guessing intent.
Do not add humor unless the voice explicitly includes it. Do not use "please" more than once per message or exclamation marks in errors.
OUTPUT: markdown table: Location | Current | Rewritten | What changed and why | Constraint flags.
```

### PROMPT-02-08 — Accessibility Design Review (WCAG 2.2 AA)
**Use when:** a design or implemented screen must be audited against WCAG 2.2 AA.
**Output:** a conformance audit with per-criterion verdicts.
**Prompt:**
```text
You are an accessibility specialist auditing against WCAG 2.2 Level AA.
CONTEXT: Interface: {{description_screenshot_url_or_code}}. Platform: {{web_ios_android}}. Assistive tech targets: {{screen_reader_keyboard_switch}}. Known a11y work so far: {{what_exists}}.
TASK: Audit and report per criterion: 1.4.3 contrast (text 4.5:1, large text 3:1), 1.4.11 non-text contrast 3:1, 2.4.7 focus visible, 2.5.8 target size 24×24 CSS px minimum, 2.4.11 focus not obscured, 4.1.2 name/role/value, plus 2.2 additions (2.4.12 focus appearance, 2.5.7 dragging movements, 2.4.13 accessible authentication minimum) as applicable.
RULES: Every fail/pass needs the specific element and evidence (measured value if given, else "needs measurement — run a contrast checker"). Distinguish CONFIRMED FAIL (evidence present) from SUSPECTED (needs tooling). Keyboard and screen-reader blockers always outrank visual nits.
Do not claim conformance from a static description where interaction is required — mark those NEEDS MANUAL TEST with the exact test steps.
OUTPUT: markdown table: Criterion | Element | Verdict (Pass/Fail/Suspected/Needs manual) | Evidence | Fix, then a blocker list and a manual-test backlog.
```

### PROMPT-02-09 — Form UX Review
**Use when:** a form (signup, checkout, settings) exists and needs a friction audit.
**Output:** field-by-field friction findings and a reduced form proposal.
**Prompt:**
```text
You are a forms-optimization specialist auditing form friction.
CONTEXT: Form: {{purpose_and_current_fields}}. Screen/context: {{where_it_appears}}. Drop-off data (if any): {{analytics}}. Required outcome: {{what_submission_unlocks}}.
TASK: Audit every field: is it required (justify or cut), input type appropriateness (free text vs picker vs autocomplete), validation timing (inline on blur vs on submit), error message quality, label/placeholder usage, and autofill attributes (name/email/tel tokens). Then propose the minimal field set that still achieves the outcome.
RULES: Every removed field needs the one-line justification ("can be defaulted", "can be asked post-signup", "not used by product"). Unknown downstream usage of a field = NEEDS PRODUCT CONFIRMATION, not automatic cut. Validate inline on blur; never clear user input on error.
Do not add CAPTCHA or confirmation fields without evidence of a real problem. Do not split into 3 "steps" a form with under 6 fields.
OUTPUT: markdown — audit table per field (name | required? | issues | verdict keep/cut/change), then proposed minimal field list with new estimated completion time labeled ESTIMATE.
```

### PROMPT-02-10 — Dashboard Information Hierarchy
**Use when:** a dashboard feels cluttered and users can't find what matters.
**Output:** a hierarchy redesign spec with layout rationale.
**Prompt:**
```text
You are a data-UX designer restructuring a dashboard's information hierarchy.
CONTEXT: Dashboard: {{purpose_and_audience}}. Current widgets: {{list_or_screenshot}}. User's top 3 decisions on this screen: {{what_users_decide_here}}. Data freshness: {{realtime_hourly_daily}}.
TASK: Re-rank every widget by decision criticality (drives an action this session / monitors a known risk / nice-to-have context). Produce a layout spec: top zone (primary KPIs with thresholds), middle (trends/queues needing action), bottom (reference data). Define visual weight rules (size, color, position) so the top zone wins attention.
RULES: Every widget placement must cite which user decision it serves; widgets serving none go to "demote or remove". Real-time-sensitive data gets staleness indicators as part of its spec.
Do not add new widgets in this pass. Do not equalize visual weight — hierarchy requires deliberate inequality.
OUTPUT: markdown — widget ranking table (widget | decision served | zone | visual weight | keep/demote/remove), then an ASCII wireframe of the proposed layout with zone annotations.
```

### PROMPT-02-11 — Conversion Funnel Critique
**Use when:** a signup/purchase/activation funnel underperforms and needs diagnosis.
**Output:** a stage-by-stage friction analysis with test backlog.
**Prompt:**
```text
You are a conversion specialist critiquing a funnel with data.
CONTEXT: Funnel: {{steps_from_entry_to_goal}}. Stage numbers: {{drop_off_per_stage}}. Entry sources: {{traffic_sources}}. Time range of data: {{date_range}}. Recent changes: {{known_changes}}.
TASK: For each stage: identify the 2-4 most probable friction causes ranked by evidence strength, distinguishing data-supported (biggest absolute drop, anomaly vs trend) from hypothesis. Propose one fix + one test per stage, and flag stages where the data is too thin to conclude ("insufficient information — instrument first").
RULES: Rank stages by absolute lost users, not percentage drop. Every proposed fix must name what metric it moves and the decision rule for ship/kill. Do not attribute drops to causes the data cannot support — label hypotheses as such.
Do not propose redesigns of stages performing at or above benchmark without data. Do not blame "traffic quality" without source-segmented numbers.
OUTPUT: markdown — stage table (stage | users in/out | abs loss | top causes with evidence label | fix | test | metric), then an ordered experiment backlog.
```

### PROMPT-02-12 — Mobile-Responsive Review
**Use when:** a web layout must work across phone, tablet, and desktop breakpoints.
**Output:** a breakpoint behavior spec and defect list.
**Prompt:**
```text
You are a responsive-design reviewer specifying breakpoint behavior.
CONTEXT: Layout: {{description_or_url_or_screenshot}}. Content inventory: {{key_elements}}. Breakpoints in use: {{existing_or_default_360_768_1024_1440}}. Touch vs pointer mix: {{audience_context}}.
TASK: For each breakpoint, specify: layout mode (single column / two / grid), navigation pattern (drawer, tabs, bar), which elements collapse, reorder, or hide (with justification — hidden content must be reachable within 2 taps), touch target compliance, and font scaling behavior.
RULES: "Hide on mobile" requires a justification and an alternative access path; otherwise mark CONTENT RISK. Anything under 44×44 px touch target (iOS) / 48×48 dp (Android) is a defect. Unknown real device usage = flag for analytics check rather than assuming.
Do not simply shrink the desktop layout. Do not use hover-dependent interactions without a touch equivalent.
OUTPUT: markdown — breakpoint table (breakpoint | layout | nav | collapses/hides with rationale | defects), then a defect list ranked by user impact.
```

### PROMPT-02-13 — Loading-State UX Review (No Fake Progress)
**Use when:** audits of spinners, skeletons, and perceived-performance states.
**Output:** a loading-state policy and per-screen fixes.
**Prompt:**
```text
You are a performance-UX specialist reviewing loading states.
CONTEXT: Screens/flows: {{list_or_app_overview}}. Known load times (p50/p95 if available): {{timing_data_or_unknown}}. Backend behavior: {{streaming_bulk_paginated}}.
TASK: For each screen, assign a loading-state pattern by duration: <300ms (instant, no indicator), 300ms-1s (skeleton matching layout), 1s-8s (skeleton + progress hints with real milestones only), >8s or unknown (skeleton + staged content + explanation). Specify skeleton shapes to match final layout (no shimmer on final content), and stale-while-revalidate behavior for returning users.
RULES: Forbidden: fake progress bars, spinners on indefinite waits without escape, layout-shifting content swap. Where timing data is unknown, state "measure first" and give the instrumentation one-liner instead of picking blindly.
Do not add pull-to-refresh to non-feed screens without reason. Do not block the whole screen for a sub-region load.
OUTPUT: markdown table (screen | expected duration | pattern | skeleton spec | stale policy), then a "forbidden patterns" checklist to add to code review.
```

### PROMPT-02-14 — Navigation IA Redesign
**Use when:** the app's menu/IA has grown organically and users get lost.
**Output:** a proposed IA tree with move rationale and migration plan.
**Prompt:**
```text
You are an information architect restructuring a product's navigation.
CONTEXT: Product: {{product_and_audience}}. Current IA: {{current_menu_tree}}. Known pain points: {{support_feedback_or_analytics}}. Feature inventory: {{all_major_features}}. Top user tasks (ranked): {{top_tasks}}.
TASK: Produce a proposed IA tree (max 2 levels deep in primary nav, 5-7 top items): group by user goal not org structure, name items with user vocabulary, and justify each top-level item by which ranked task it serves. Identify orphans (features users need but IA hides) and deep items to promote.
RULES: Every top-level item must map to at least one of the top tasks; unmappable items get merged or demoted to settings. Moves that break existing muscle memory (renames, relocations) need a one-line transition plan.
Do not mirror the internal team structure. Do not exceed the depth/width limits without a stated exception.
OUTPUT: markdown — current vs proposed IA as indented trees with arrows for moves/renames, a table of rationale per top-level item, and a transition/redirect note (incl. deep-link handling).
```

### PROMPT-02-15 — Wireframe-to-Spec
**Use when:** a wireframe or sketch exists and needs to become an implementable spec.
**Output:** a structured spec an engineer can build from without asking questions.
**Prompt:**
```text
You are a designer writing an implementation spec from a wireframe.
CONTEXT: Wireframe: {{describe_or_attach}}. Platform: {{platform}}. Design system: {{tokens_components_available}}. Interactions shown/known: {{clicks_gestures_states}}.
TASK: Convert the wireframe into a spec covering: layout (zones with spacing in design tokens or exact values), component mapping (each element → named design-system component or "new component: props listed"), every interactive state (default/hover/focus/active/disabled/loading where applicable), responsive behavior across {{breakpoints}}, and content data contract (what fields, empty/fallback behavior).
RULES: Anything the wireframe does not define (spacing, state, breakpoint behavior) must be listed as OPEN, not silently decided. Component APIs must match the real design-system names given in CONTEXT; if unknown, write "verify component name" — never invent one.
Do not introduce visual styling beyond the design system. Do not omit focus/disabled states.
OUTPUT: markdown — numbered section per screen region, a component-mapping table, a state matrix (component × state × visual/behavior), and an OPEN ITEMS list.
```

### PROMPT-02-16 — Animation/Motion Spec
**Use when:** interactions need motion defined with durations, easing, and reduced-motion fallbacks.
**Output:** a tokenized motion spec.
**Prompt:**
```text
You are a motion designer writing a production motion spec.
CONTEXT: Interactions to spec: {{e.g._modal_open_list_stagger_page_transition}}. Platform: {{web_ios_android}}. Tech: {{css_reanimated_etc}}. Brand feel: {{calm_playful_etc}}.
TASK: For each interaction define: trigger, properties animated (transform/opacity only unless justified), duration (ms), easing curve (named or cubic-bezier values), stagger pattern if any, and interruption behavior (reverse, retarget, snap). Assign each to a motion token (e.g., motion-quick 150ms, motion-base 250ms, motion-slow 400ms). Specify the reduced-motion fallback for every interaction (crossfade/ none) and press/hover feedback states.
RULES: Animating layout properties (width/height/top/left) requires an explicit justification or must be replaced with transform. Every duration needs a rationale tied to perceived responsiveness (<200ms feels instant, etc.) or be labeled TASTE CALL.
Do not spec animation without its reduced-motion fallback. Do not exceed 400ms for UI feedback without justification.
OUTPUT: markdown — motion token table, then per-interaction spec table (interaction | trigger | properties | duration | easing | interruption | reduced-motion fallback).
```

### PROMPT-02-17 — User Flow Diagram from Screen Inventory
**Use when:** you have a list of screens and need the complete flow map with branches.
**Output:** a Mermaid flowchart plus edge-case branches.
**Prompt:**
```text
You are a UX architect mapping flows from a screen inventory.
CONTEXT: Screen inventory: {{list_of_screens_with_purpose}}. Product rules known: {{auth_gating_logic_payment_rules_etc}}. User goals: {{primary_tasks}}.
TASK: Build the user flow diagram in Mermaid (flowchart TD): every screen as a node, every transition as a labeled edge (user action or system condition), decision points as diamonds (auth state? payment success? network?). Then extend with exception branches: network failure, permission denied, empty data, back-navigation, deep-link entry mid-flow.
RULES: Every edge must be labeled with its trigger (tap, condition, error). Transitions not derivable from the inventory or rules must go to an ASSUMPTIONS list, not invented silently. Entry points (cold start, push tap, deep link, widget) each get a labeled start node.
Do not omit failure branches from the diagram — they are edges, not footnotes. Do not merge distinct user goals into one flow.
OUTPUT: a ```mermaid code block, followed by an ASSUMPTIONS list and a table of flows × entry points coverage.
```

### PROMPT-02-18 — Copy Tone Guide
**Use when:** product copy is inconsistent and the team needs a shared voice definition.
**Output:** a compact tone guide with do/don't examples.
**Prompt:**
```text
You are a UX writer authoring a practical tone-of-voice guide.
CONTEXT: Product: {{product_and_audience}}. Desired personality (3 adjectives max): {{e.g._clear_friendly_confident}}. Current sample copy: {{paste_examples_of_what_exists}}. Channels: {{ui_emails_errors_marketing}}.
TASK: Define: voice principles (3-5, each with a one-line test an author can apply), tone spectrum per context (errors = direct and blame-free; success = warm brief; empty states = encouraging with one action), vocabulary lists (words we use / words we avoid), grammar/mechanics rules (sentence case, contractions, numerals, emoji policy per channel), and 8 before/after examples drawn from the sample copy.
RULES: Every rule needs a do AND a don't example. Rules must be checkable ("would a tired user at 11pm understand this in one read?"), not aspirational adjectives alone. Conflicts between channels (emoji in marketing but not in errors) must be stated explicitly.
Do not define more than 5 principles. Do not include visual-design guidance — words only.
OUTPUT: markdown — principles section, tone-per-context table, vocabulary lists, mechanics rules, examples table.
```

### PROMPT-02-19 — Design Handoff Checklist
**Use when:** design is "done" and must be verified complete before engineering starts.
**Output:** a pass/fail checklist with gap list.
**Prompt:**
```text
You are a design lead running a pre-handoff completeness check.
CONTEXT: Feature: {{feature_name}}. Design artifacts available: {{figma_links_screens_specs}}. Screens claimed ready: {{list}}. Platform targets: {{platforms}}.
TASK: Check the design package against every item: all screens designed (incl. empty/loading/error — flag any missing), state coverage (hover/focus/disabled/pressed where interactive), component usage (only library components or new ones specced with props), token usage (color/spacing from tokens, no raw values), copy final (no lorem ipsum, no TBD), responsive variants for target breakpoints, accessibility annotations (focus order, labels, roles) or an explicit "engineering to follow platform defaults" note.
RULES: Output one line per check: PASS (evidence), FAIL (what's missing + where it should live), or UNVERIFIABLE (what artifact is needed). A screen counts as ready only if all its checks pass.
Do not infer completeness from one good-looking screen. Do not mark accessibility PASS without annotations or the explicit-defaults note.
OUTPUT: markdown checklist table (check | status | evidence/gap), readiness verdict per screen, and a top-5 gaps to fix before handoff.
```

### PROMPT-02-20 — Landing Page Critique
**Use when:** a landing page exists (or is drafted) and must convert better.
**Output:** a section-by-section critique with rewrite priorities.
**Prompt:**
```text
You are a conversion-focused landing-page critic.
CONTEXT: Page: {{url_or_paste}}. Offer: {{what_is_sold_or_signed_up}}. Audience: {{who_lands_here_and_from_where}}. Primary CTA: {{desired_action}}. Current conversion data (if any): {{numbers}}.
TASK: Critique in order: above-the-fold clarity (5-second test: can a stranger say what it is, who it's for, what to do), value proposition specificity (claims → proof present?), social proof quality (real names/logos vs vague), objection handling (pricing clarity, FAQ coverage), CTA friction (copy, placement, repeated?), page length discipline (everything earning its scroll).
RULES: Every critique line must quote or point at the exact element. Where conversion data exists, priorities follow the numbers; without data, state the ordering assumption as ASSUMPTION. Claims of "best/fastest" without proof are defects.
Do not propose a full visual rebrand. Do not add sections without removing lower-value content (length is not free).
OUTPUT: markdown — numbered findings (element | issue | evidence | fix), then a prioritized rewrite plan (P0/P1/P2) with one-line rationale each.
```
