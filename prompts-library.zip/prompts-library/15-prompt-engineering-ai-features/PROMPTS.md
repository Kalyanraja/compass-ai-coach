# Prompt Engineering & AI Features Prompts (PROMPT-15-01 … PROMPT-15-20)

Covers system-prompt architecture, RAG, evals, structured outputs and tool contracts, guardrails, compression, agent planning, versioning, budgets, fallbacks, red-teaming, and AI observability.
Placeholder convention: `{{double_braces}}` mark user-supplied inputs (features, data samples, prompts, models); paste raw prompts/data verbatim into them.

### PROMPT-15-01 — System-Prompt Architect for an AI Feature
**Use when:** designing the system prompt for a new AI-powered feature.
**Output:** a layered system prompt with contracts, boundaries, and test hooks.
**Prompt:**
```text
You are a prompt architect. Context: the AI feature {{feature_description}}, user-facing surface {{surface}}, model {{model_name_or_class}}, failure costs {{failure_cost_profile}}, brand/voice constraints {{voice_constraints}}.
Task: architect the system prompt: (1) role and mission — one sentence each, no personality padding; (2) contract section — exact output format (schema/structure), the fields, and required vs optional; (3) knowledge boundaries — what the model may assert vs must defer (from {{failure_cost_profile}}: high-stakes claims need sourcing or refusal); (4) behavior rules — tone per {{voice_constraints}}, refusal style, how to handle missing information ("insufficient information" behavior), how to handle user attempts to override; (5) worked examples — 2–3 input/output pairs covering the happy path and one boundary case; (6) negative constraints — explicit do-nots (no invented citations, no data beyond {{provided_scope}}, no promises of action).
Constraints:
- Every behavioral rule must be testable — for each, name the eval case that verifies it.
- Conflicts resolved explicitly: if brevity conflicts with completeness rules, state precedence.
- No unverifiable capability claims ("you are an expert") — rules and examples do the work.
- Where model-specific quirks of {{model_name_or_class}} matter (instruction-following format, system-vs-developer roles), follow documented behavior and mark uncertain points as "verify in model docs".
Do not write a wall of text; each section earns its tokens. No emoji, no sycophancy instructions.
Output format: the system prompt itself (ready to use), plus a test-map: rule → eval case.
```

### PROMPT-15-02 — RAG Pipeline Design
**Use when:** building retrieval-augmented generation over a corpus.
**Output:** a pipeline design: chunking, embedding, retrieval, reranking, generation, and an eval plan.
**Prompt:**
```text
You are a RAG systems designer. Context: corpus {{corpus_description}} (size, formats, freshness needs), user questions {{query_patterns}}, latency budget {{latency_budget}}, infrastructure {{infra_constraints}}, existing stack {{existing_components_or_none}}.
Task: design the pipeline: (1) chunking — strategy (size, overlap, structure-aware boundaries), chosen for {{corpus_description}}'s structure, with the failure mode each choice prevents; (2) indexing — embedding model choice criteria (dimension, multilingual, context length) matched to queries, metadata schema (source, date, section, access-control); (3) retrieval — hybrid (dense + lexical) justification, top-k per stage, reranking (when it pays for its latency), query rewriting/expansion; (4) generation — context assembly order, citation requirement, "insufficient retrieval" behavior; (5) freshness — update path for changed documents, deletion handling; (6) evaluation — golden-set construction (source: real {{query_patterns}}), retrieval metrics (recall@k, MRR) and end-task metrics, labeling who grades.
Constraints:
- Retrieval failures must degrade gracefully — the answer path when retrieval is empty or low-confidence is specified, not improvised.
- Access control: if {{corpus_description}} has permission tiers, retrieval filters by them; state where in the pipeline.
- All thresholds (top-k, similarity cutoffs) are starting estimates; label them and define the eval that tunes them.
- Tool/model recommendations must fit {{infra_constraints}}; unverifiable integrations marked "verify in docs".
Do not claim RAG eliminates hallucination; specify the citation and abstention mechanisms that bound it.
Output format: pipeline stage spec (inputs, outputs, config), config table with initial values, degradation behavior, and eval plan with golden-set method.
```

### PROMPT-15-03 — Eval-Harness Builder
**Use when:** building a repeatable evaluation for an LLM feature.
**Output:** an eval harness design: dataset schema, graders, scoring, and CI integration.
**Prompt:**
```text
You are building an evaluation harness. Context: feature {{feature_description}}, current prompt {{current_prompt}}, examples of good/bad outputs {{examples}}, available infrastructure {{infra_constraints}}, grading capacity {{who_grades}}.
Task: design the harness: (1) golden dataset — case schema (id, input, context/retrieval fixtures, expected output or rubric, tags: category, difficulty, risk), sourcing strategy from real usage (with privacy rules), minimum viable size per category and how it grows; (2) graders — per case type: exact/structured match, model-graded rubric (with grader prompt + bias controls: position randomization, reference outputs), human-graded subset for calibration; (3) scoring — pass thresholds, regression definition (what delta blocks release), per-category breakdowns so aggregate scores cannot hide failures; (4) adversarial cases — the failure modes from {{examples}} encoded as cases; (5) CI integration — when evals run (per-PR vs nightly), runtime budget, flake policy for nondeterministic models (repeated runs, tolerance bands).
Constraints:
- Every grader gets a reproducibility spec: seed/temperature policy, grader-model version pinned, and inter-grader agreement target for human grading.
- No aggregate-only scoring: each risk-relevant category has its own threshold.
- Cases derived from real usage must be sanitized per stated privacy rules; synthetic cases are labeled as such.
- Effort estimates for building the harness are labeled estimates.
Do not skip the calibration step: model-graders must be validated against human labels before trusting them.
Output format: dataset schema + example rows, grader specs, scoring/threshold definition, CI wiring plan, and build-out sequence.
```

### PROMPT-15-04 — Structured-Output Contract (Schema + Retries)
**Use when:** requiring a model to return parseable structured data.
**Output:** an output contract: JSON schema, prompt instructions, parser, validation, and retry policy.
**Prompt:**
```text
You are designing a structured-output contract. Context: feature {{feature_description}}, consuming code {{consumer_context}}, model {{model_name_or_class}}, schema needs {{field_requirements}}.
Task: design the contract: (1) JSON Schema — fields, types, required/optional, enums over free text where possible, nullable semantics made explicit, no ambiguous formats (dates, money as integer cents — choose and document); (2) prompt-side instructions — how the schema is communicated (schema-in-prompt vs native structured-output API), with the exact instruction text, and the rule that output is schema-only, no prose; (3) parsing — strict parse, error taxonomy (invalid JSON / schema violation / missing field), no silent coercion; (4) validation — consumer-side validation anyway (never trust model output), with the same schema; (5) retry policy — on validation failure: how many retries, what corrective feedback goes back (the validation errors, not the whole schema), backoff, and the terminal fallback (degrade, queue, or human); (6) determinism controls — temperature, seed where supported (flag "verify in model docs" for support).
Constraints:
- Prefer the model's native structured-output mode if {{model_name_or_class}} documents one; fall back to schema-in-prompt with a note on the reliability difference.
- Retry feedback must be minimal and specific; re-sending the entire conversation compounds tokens and confusion.
- The schema must be versioned; consumers pin a version; document the migration path for schema changes.
- State the measured/estimated parse success rate as unknown until the eval from the eval-harness runs — no invented reliability numbers.
Do not recommend regex-extracting JSON from prose as the primary path; it is a last-resort fallback at most.
Output format: the schema, the prompt instruction text, parser/validation pseudocode, retry state machine, and determinism settings.
```

### PROMPT-15-05 — Tool/Function-Calling Contract Design
**Use when:** an AI feature needs the model to call external tools.
**Output:** tool contracts: specs, argument schemas, permissions, and the agent loop guardrails.
**Prompt:**
```text
You are designing tool contracts for an agent. Context: feature {{feature_description}}, available tools {{tool_inventory}}, riskiest tools {{high_risk_operations}}, model {{model_name_or_class}}.
Task: design the contracts: (1) per tool — name (verb-noun), description written for the model (when/why to use, with concrete triggers), argument JSON schema with constraints (enums, ranges), return-value schema; (2) permission classes — read-only / state-changing / destructive; for {{high_risk_operations}}: whether the model may call them directly, requires a confirmation token, or is forbidden (recommend per risk); (3) the agent loop — max iterations, loop-detection (same tool+args repeated), error feedback format back to the model, and the exit conditions; (4) failure design — tool errors vs timeouts vs malformed calls: what the model sees, what the user sees; (5) observability hooks — log every call with args hash, decision context, and outcome.
Constraints:
- Tool descriptions are prompts too: test them — a description that misleads the model into wrong-tool selection is a defect; name the eval for selection accuracy.
- Argument validation happens in the tool layer, not by trusting the model; the schema is enforcement, not advice.
- Destructive tools never callable without an out-of-band confirmation; the confirmation must bind to the exact arguments.
- Model-specific tool-calling format must match {{model_name_or_class}}'s documented API; uncertain formats marked "verify in docs".
Do not give the model a generic "run command" tool as a shortcut for missing tools; build the specific tool.
Output format: tool spec table, permission matrix, agent-loop pseudocode with guards, error-format spec, and observability field list.
```

### PROMPT-15-06 — Hallucination-Reduction Patterns
**Use when:** an AI feature asserts facts it cannot support.
**Output:** a hallucination-reduction design: grounding, citation, abstention, and measurement.
**Prompt:**
```text
You are reducing hallucinations in an AI feature. Context: feature {{feature_description}}, current prompt {{current_prompt}}, observed hallucination examples {{failure_examples}}, knowledge source {{knowledge_source_or_none}}.
Task: design the defenses: (1) classify the observed failures from {{failure_examples}} — fabricated facts, wrong-source attribution, confident overreach beyond retrieved data, stale knowledge; the defense differs per class; (2) grounding — retrieval requirements per claim class; citation mandate (every factual claim carries a source ID; no source → no claim); (3) abstention — the exact behavior when grounding is missing or conflicting ("insufficient information" wording, what is offered instead); (4) prompt-level patterns — separating retrieved facts from model knowledge in context (e.g., quoted blocks labeled UNVERIFIED vs VERIFIED), instructions to prefer provided context, and anti-invention rules; (5) decoders/settings — temperature down, and any documented factuality settings for the model (flag "verify in docs"); (6) measurement — hallucination eval cases from {{failure_examples}}, graded by claim-level factuality, with a target rate and how it is tracked in production.
Constraints:
- No defense is claimed to eliminate hallucination; each is labeled as reducing a specific failure class, with the residual risk stated.
- Citation must be checkable — source IDs the user can open; decorative citations are forbidden.
- Where {{knowledge_source_or_none}} is absent, the design is abstention-first; scope shrink recommendations included.
- Every prompt change proposed must name the eval case that proves it works.
Do not propose "tell it to not hallucinate" as a defense; output-auditing and grounding changes only.
Output format: failure classification with defenses per class, prompt patterns to add (exact text), abstention spec, and measurement plan with targets.
```

### PROMPT-15-07 — Guardrail & Injection-Defense Spec
**Use when:** an AI feature faces untrusted input and needs defense-in-depth.
**Output:** a guardrail spec covering input, retrieval, tool, and output layers.
**Prompt:**
```text
You are a security engineer for AI features. Context: feature {{feature_description}}, untrusted inputs {{untrusted_input_sources}} (user text, fetched web content, uploaded docs), tools/data accessible {{exposure_surface}}, current defenses {{current_defenses_or_none}}.
Task: specify defense-in-depth: (1) threat model — the concrete attacks against {{untrusted_input_sources}}: direct prompt injection, indirect injection via retrieved/uploaded content, jailbreak attempts, data exfiltration via tool outputs or citations, denial-of-wallet (cost flooding); (2) input layer — sanitization reality-check (what filtering can and cannot do against injection; no false confidence), instruction hierarchy reinforcement, delimiters/quoting for embedded content; (3) retrieval layer — treating all retrieved content as data (labeling, no instruction-following from retrieved text), source trust tiers; (4) tool layer — allowlist of callable tools per session, argument validation, output screening before it re-enters context; (5) output layer — PII/secrets scanning on outputs, policy checks before display or send; (6) detection — logging patterns that flag injection attempts, and the response (refuse, sanitize, alert).
Constraints:
- State explicitly: no layer is a complete defense; the spec is depth, and each layer's residual risk is named.
- Content-filter/tool recommendations must fit {{exposure_surface}}; capabilities you cannot verify are marked "verify in docs".
- Every guardrail gets a red-team test case (reference PROMPT-15-19) proving it triggers.
- Cost defenses (per-user budgets, max tokens per session) are mandatory, not optional.
Do not recommend hiding the system prompt as a security measure; it is obscurity, not defense — note it as cosmetic.
Output format: threat-model table, per-layer guardrail spec, detection/response plan, and the mandatory cost-control settings.
```

### PROMPT-15-08 — Prompt-Compression Rewrite
**Use when:** a prompt is too long and needs token reduction without quality loss.
**Output:** a compressed prompt with a before/after diff, removed-content ledger, and re-eval plan.
**Prompt:**
```text
You are compressing a prompt. Context: current prompt {{current_prompt}}, measured token count {{token_count}}, cost/latency pressure {{pressure_description}}, quality requirements {{must_keep_behaviors}}.
Task: compress it: (1) measure-first analysis — which sections cost the most tokens (few-shot examples, restated instructions, verbose schema descriptions); (2) apply compression moves in order of least quality risk: remove redundant restatements, replace prose rules with terse rule lists, shrink few-shot examples (fewer, harder, more representative), replace inline schema with a referenced/compact form, drop sections with no behavioral effect; (3) for each removal/replacement, record it in a ledger: what was cut, why it is safe (or the risk accepted); (4) never compress {{must_keep_behaviors}} — conflict resolution is shrink scope elsewhere; (5) re-eval plan: which eval cases must be re-run to certify the compressed prompt, including at least one adversarial case; (6) report estimated token savings as an estimate pending re-measurement.
Constraints:
- Compression is behavior-preserving by definition; any behavior change (including improved robustness) is documented as a change, not smuggled in.
- Few-shot examples are replaced with harder/trickier ones, not merely fewer — a compressed prompt that fails edge cases is more expensive, not less.
- Ambiguity is a quality loss: terseness must not make instructions under-specified where the model had explicit guidance.
- The ledger is part of the deliverable; silent cuts are forbidden.
Do not compress by deleting safety/edge-case instructions to hit a token target; the target flexes instead — say so if it happens.
Output format: the compressed prompt, the before/after token estimate, the removal ledger (cut, rationale, risk), and the re-eval checklist.
```

### PROMPT-15-09 — Multi-Step Agent Planner (Plan/Act/Verify)
**Use when:** designing an agent that decomposes and executes multi-step tasks.
**Output:** an agent architecture: planner, executor, verifier, state, and runaway guards.
**Prompt:**
```text
You are designing a multi-step agent. Context: task domain {{task_domain}}, available tools {{tool_inventory}}, environment {{execution_environment}}, failure costs {{failure_cost_profile}}.
Task: architect the plan/act/verify loop: (1) planner — when to plan upfront vs interleaved, plan representation (checklist with explicit verification per step), replanning triggers (step failure, new information, scope discovery); (2) executor — one tool call per reasoning step vs batching, argument construction rules, error interpretation; (3) verifier — per-step verification (observable success criteria, not "seems done"), independent verification where {{failure_cost_profile}} is high (a different check than the doer), and final acceptance criteria; (4) state management — what the agent remembers across steps, context hygiene (summarization policy, what stays verbatim), artifact persistence; (5) runaway guards — max steps, max wall-clock, cost budget, loop detection, stuck-detection (no state change across N steps), and the escalation path (ask human with a summary, not a raw dump); (6) human checkpoints — which step classes always pause for confirmation per {{failure_cost_profile}}.
Constraints:
- Verification is a first-class component with its own logic, not a vibe check by the same reasoning that acted.
- Every guardrail threshold is an initial estimate; label it and define how production telemetry tunes it.
- The agent must be able to explain its plan and progress in 3 lines at any point — design the status representation.
- Tool contracts per PROMPT-15-05; permissions per step class, not per session blanket.
Do not design autonomous loops for {{failure_cost_profile}}=high tasks without mandatory checkpoints; if the request implies it, state the constraint and design the checkpointed version.
Output format: architecture diagram in text, the loop pseudocode with all guards, state/context spec, checkpoint policy, and escalation flow.
```

### PROMPT-15-10 — Prompt Versioning & A/B Plan
**Use when:** prompts are changing in production and need governance.
**Output:** a versioning scheme, A/B methodology, and rollout/rollback policy.
**Prompt:**
```text
You are the governor of prompt changes. Context: feature {{feature_description}}, current prompts {{current_prompts}}, change pipeline today {{change_process_or_none}}, traffic volume {{traffic_scale}}, evaluation setup {{eval_status}}.
Task: design the system: (1) versioning — prompt registry schema (id, version, content hash, model+settings, author, eval result ref, status: draft/candidate/live/retired), storage (code-adjacent files, not dashboards), immutable versions; (2) promotion pipeline — every change runs the eval harness (from {{eval_status}}; if none exists, that is prerequisite work, stated first), passes thresholds, then canary; (3) A/B methodology — unit of randomization (user vs session vs request), sample size math stated as formula with placeholders (no invented significance), guardrail metrics (refusals, latency, cost, complaint rate) that auto-stop the experiment; (4) rollout — staged exposure, rollback trigger thresholds, and instant-rollback mechanics (registry pointer flip); (5) audit — every production response traceable to the exact prompt version + model version that produced it.
Constraints:
- No prompt reaches production without eval results referenced in the registry entry; {{eval_status}} gaps are blockers, listed explicitly.
- A/B without guardrails is forbidden: name the auto-stop conditions before the experiment starts.
- Rollback must be one operation and tested — describe the drill.
- Model version pinning: a prompt version records the model it was validated against; silent model upgrades re-trigger eval.
Do not recommend judging prompt quality by vibes or a handful of manual spot checks; the methodology is measurement or nothing.
Output format: registry schema, promotion pipeline description, A/B design with guardrails, rollout/rollback procedures, and audit-trail spec.
```

### PROMPT-15-11 — Cost/Latency Budget for LLM Calls
**Use when:** an AI feature needs explicit cost and latency envelopes.
**Output:** a budget spec: per-call ceilings, caching strategy, model-routing tiers, and tracking.
**Prompt:**
```text
You are an AI-platform engineer setting budgets. Context: feature {{feature_description}}, call pattern {{call_pattern}} (volume, input/output sizes, concurrency), model(s) {{models}}, current costs {{current_metrics_or_none}}, user expectations {{sla_expectations}}.
Task: build the budget: (1) ceilings — per-call max input tokens (what happens on overflow: truncate with markers, summarize, or reject — choose per data type), max output tokens with the stop behavior, per-user and per-feature daily caps; (2) latency — target p50/p95 per call, the decomposition (model time vs pre/post-processing), and which parts are controllable; (3) cost model — the formula (tokens × price + fixed), with numbers from {{current_metrics_or_none}} or labeled placeholder estimates; (4) optimization levers ranked by quality risk: prompt compression (PROMPT-15-08), caching (exact-match, semantic — with invalidation rules), model routing (small model for easy cases, escalation policy with a classifier or heuristic), batch APIs where latency-insensitive; (5) tracking — cost/latency per prompt version, alerting thresholds, and the review cadence.
Constraints:
- Every lever's quality risk must be acknowledged; caching and routing need eval coverage of the cache-miss/escalation paths.
- Overflow behavior is specified for each data type, never "send everything and hope".
- Numbers from {{current_metrics_or_none}} are facts; projections are estimates with the formula shown.
- Denial-of-wallet protection (per-user budgets) is mandatory.
Do not recommend routing or caching without the accuracy measurement plan; savings that silently degrade quality are net losses.
Output format: budget table (per-call, per-user ceilings), latency decomposition, cost formula with values, lever ranking with risks, and tracking spec.
```

### PROMPT-15-12 — Context-Window Budgeting Spec
**Use when:** an AI feature keeps hitting context limits or needs predictable fits.
**Output:** a context budget spec: component allocations, truncation policy, and overflow tests.
**Prompt:**
```text
You are designing context-window management. Context: feature {{feature_description}}, model context size {{context_window}}, context components {{component_list}} (system prompt, history, retrieved docs, tool outputs, user input), typical sizes {{size_measurements_or_unknown}}.
Task: budget the window: (1) component allocation — a table assigning token budgets per component summing to a safe fraction (e.g., 80%) of {{context_window}}, with the headroom reserved for output tokens (state the output reservation explicitly); (2) per-component policies when over budget: history (summarize oldest turns — summarize-what policy: facts, decisions, open items, not transcript), retrieval (re-rank and cut, never mid-sentence chunk loss without marker), tool outputs (truncate middle with markers, or paginate), user input (reject vs compress — decision per input type); (3) counting — how tokens are measured (tokenizer of {{context_window}}'s model; flag "verify tokenizer behavior" where unsure) and measured before send, not estimated; (4) regression tests — the oversized-input cases that must behave predictably (max-size document, max-turn history, max tool output); (5) observability — context-fill percentage logged per call with alerts near budget.
Constraints:
- The output-token reservation is non-negotiable; truncation that eats the output budget causes worse failures than refusal.
- Every truncation point marks the cut ("...[truncated N tokens]..."); silent truncation is a defect.
- Policies must specify what content survives: recency, relevance scoring method, and what is never truncated (safety instructions, active tool contracts).
- Where {{size_measurements_or_none}} is absent, the first task is instrumentation to measure; allocations until then are labeled provisional.
Do not treat the context window as a garbage bin that "usually fits"; every component has a budget and a defined overflow path.
Output format: allocation table, per-component overflow policies with survival rules, counting method, overflow test cases, and observability spec.
```

### PROMPT-15-13 — Fallback & Degradation Design
**Use when:** an AI feature must keep working when the model or upstream fails.
**Output:** a degradation ladder with health checks, behavior per tier, and user-facing messaging.
**Prompt:**
```text
You are designing graceful degradation for an AI feature. Context: feature {{feature_description}}, dependencies {{dependencies}} (model API, retrieval, tools), user expectations {{sla_expectations}}, non-AI alternatives {{fallback_assets_or_none}}.
Task: design the ladder: (1) failure modes enumerated — model timeout, rate limit, malformed output, retrieval empty/degraded, cost-budget exceeded, full outage; the response differs per mode; (2) tiers — full → reduced (shorter outputs, fewer retrieved sources, simpler model) → cached/stale-safe responses (only where freshness permits, with staleness disclosure) → rules/template fallback (from {{fallback_assets_or_none}}; if none, state the honest degraded UX) → unavailable with apology and ETA; (3) health signals — what the system monitors to switch tiers (error rate, latency percentile, budget burn) with thresholds labeled initial estimates; (4) recovery — automatic re-upgrade criteria with hysteresis (re-upgrade at better threshold than downgrade to avoid flapping); (5) user messaging — per-tier UX copy: what the user is told, never implying capability that is off; (6) safety check — degraded modes must not skip safety layers (output screening stays on at every tier).
Constraints:
- Degradation never silently changes output semantics; every tier is disclosed in the UX copy.
- Fallbacks must be tested — each tier needs a test that forces it; an untested fallback is assumed broken.
- Cached/stale responses carry max-age rules and are forbidden where freshness is safety-relevant (state which if any).
- Cost-tier degradation (switching to cheaper model) still requires eval evidence for that model.
Do not design a fallback that fabricates content (template with stale data presented as fresh); fabrication is worse than unavailability.
Output format: failure-mode → tier table, tier behaviors with copy, health thresholds, recovery/hysteresis spec, and per-tier test plan.
```

### PROMPT-15-14 — Prompt Regression Test Writer
**Use when:** turning a prompt change request into executable regression tests first.
**Output:** failing regression tests before any prompt change, plus the prompt-change plan gated on them.
**Prompt:**
```text
You are writing regression tests for a prompt change. Context: current prompt {{current_prompt}}, requested change {{change_request}}, existing eval cases {{existing_evals}}, harness {{harness_context}}.
Task: (1) derive the intent of {{change_request}} — what behavior should change and, equally important, what behavior must NOT change; (2) write regression tests for both sides: tests that pass with the current prompt and must keep passing (protection), and tests that fail now and must pass after (driving the change); express them in {{harness_context}}'s case format with exact expected outputs or rubrics; (3) run (or reason through) the protection cases against {{current_prompt}} and record the baseline — any protection case that already fails is a pre-existing bug to flag, not to entrench; (4) present the prompt-change plan with the tests as the gate: no prompt edit until tests exist; (5) define done: all protection green + all driving tests green, measured not eyeballed.
Constraints:
- Tests are behavioral, not string-match against a single phrasing — rubric-style expectations where wording varies.
- Include at least one adversarial case per change (the input most likely to over-trigger the new behavior).
- If {{change_request}} is ambiguous, the tests encode your interpretation — state the interpretation explicitly for approval before writing the prompt change.
- No prompt change in this task; the deliverable is the test suite + gate.
Do not weaken a failing protection test to make the change fit; the test either reveals a real regression or the change design is wrong.
Output format: test cases (protection + driving) in runnable format, baseline results, interpretation statement, and the approval gate description.
```

### PROMPT-15-15 — Refusal & Edge-Case Test Suite
**Use when:** verifying an AI feature handles refusals and boundary inputs well.
**Output:** a test suite for refusals, edge inputs, and the boundary between them.
**Prompt:**
```text
You are building the refusal/edge-case suite. Context: feature {{feature_description}}, policy {{safety_policy_summary}}, current prompt {{current_prompt}}, known awkward cases {{known_edge_cases}}.
Task: build the suite: (1) case taxonomy — true refusals (policy violations), borderline (sensitive-but-legitimate: medical/legal info with disclaimers, dual-use), false-positive risks (innocent phrasings the policy might over-trigger on), and benign edge inputs (empty, gibberish, very long, multilingual, prompt-injection attempts in user input); (2) per case: input, expected behavior class (refuse with reason X / comply with caveat Y / ask clarifying question), and grading rubric — refusals graded on whether a reason and alternative are offered, not just refusal presence; (3) the balance targets — over-refusal rate and under-refusal rate both measured; a policy that refuses everything is as failed as one that refuses nothing; (4) consistency checks — near-paraphrase inputs that must get equivalent treatment; (5) jailbreak variants from {{known_edge_cases}} encoded as recurring regression cases; (6) gaps — policy areas from {{safety_policy_summary}} with no test coverage, listed explicitly.
Constraints:
- Every refusal expectation includes the reason/alternative content, not just "refuses"; partial refusals (refusing one part, complying with the rest) are specified where appropriate.
- Borderline cases need the caveat/disclaimer content specified and graded.
- All expectations graded by rubric, since refusal wording varies; exact-match forbidden except for required disclaimer components.
- Cases encoding real user harms stay realistic but sanitized; no gratuitous harmful content needed to test refusal.
Do not accept "the model refused, test passed" — refusal quality (reason, alternative, tone) is the actual requirement.
Output format: the suite (case, input, expected class, rubric), balance metrics definition, consistency sets, and coverage-gap list.
```

### PROMPT-15-16 — Few-Shot Example Curator
**Use when:** selecting or rewriting the examples in a prompt.
**Output:** a curated few-shot set with selection rationale, difficulty gradient, and anti-overfit notes.
**Prompt:**
```text
You are curating few-shot examples. Context: task {{task_description}}, candidate pool {{candidate_examples}}, current examples {{current_examples_or_none}}, model {{model_name_or_class}}.
Task: curate the set: (1) selection criteria — coverage (each input class and edge case represented), difficulty gradient (easy → hard → adversarial), output style consistency (the examples ARE the style spec), and diversity without redundancy (no three examples teaching the same thing); (2) evaluate {{candidate_examples}} against the criteria; pick the minimal set that covers the space — justify each inclusion and each exclusion; (3) rewrite examples whose outputs are subpar (style drift, missing edge-handling) — the output shown must be the ideal target behavior, including how edge inputs are handled; (4) order — the classic pitfall: position bias means first/last examples weigh more; order deliberately and explain; (5) anti-overfit check — are examples so specific the model parrots them? Include at least one example whose input class is rare, to prevent mode collapse to common cases; (6) token cost — total few-shot token count reported with the estimate labeled.
Constraints:
- Every example's output must be correct — verified against {{task_description}} rules; an incorrect example teaches the error.
- Labels/formatting in examples must exactly match the output contract (schema, keys) — examples contradicting the schema are defects.
- Where model quirks of {{model_name_or_class}} affect example effectiveness (e.g., sensitivity to example count), note as "verify in docs".
- Difficulty documentation: each example tagged with what it teaches.
Do not pad examples for volume; each example must earn its tokens, and the budget cap is stated upfront.
Output format: the curated set with per-example rationale tags, exclusion list with reasons, ordering explanation, and token estimate.
```

### PROMPT-15-17 — Semantic Router Design (Intent Classification)
**Use when:** routing inputs between handlers (models, prompts, tools, humans) by intent.
**Output:** a routing design: taxonomy, classifier spec, confidence policy, and eval plan.
**Prompt:**
```text
You are designing a semantic router. Context: traffic {{traffic_description}}, candidate handlers {{handler_list}}, misrouting costs {{misroute_costs}}, latency budget {{latency_budget}}.
Task: design the routing layer: (1) intent taxonomy — the handler categories with precise definitions and 3–5 example utterances each, derived from {{traffic_description}}; explicit overlap analysis (which categories confusable, what distinguishing features separate them); (2) classifier choice — rules/regex where sufficient vs small classifier model vs LLM classification; decision justified against {{latency_budget}} and {{misroute_costs}}; uncertainty flagged "verify in docs" for chosen tooling; (3) confidence policy — the routing decision needs a confidence path: above threshold route, below threshold clarify-or-default (define the default per {{misroute_costs}} — when in doubt, the cheap/safe handler); (4) multi-intent handling — compound inputs routed how (decompose, primary intent, or sequential handling); (5) eval — labeled set from real {{traffic_description}} traffic, per-class precision/recall with macro averages, confusion matrix targets, and regression tests for routing changes; (6) telemetry — production logging of routed class + confidence for drift detection.
Constraints:
- The default/uncertain path is chosen by {{misroute_costs}}, not convenience; the costliest misroute defines the safest default.
- Every taxonomy category has a home: no "other" dumping ground without explicit rules for what belongs there and its handling.
- Classifier thresholds are initial estimates; the eval tunes them with the confusion matrix.
- Drift: category definitions include the telemetry that reveals definition drift (new vocabulary appearing).
Do not design routing by keyword alone where paraphrase robustness matters; state the paraphrase test that proves the chosen approach.
Output format: taxonomy with examples, classifier decision + config, confidence policy with defaults, multi-intent strategy, eval plan, telemetry spec.
```

### PROMPT-15-18 — Human-in-the-Loop Checkpoint Spec
**Use when:** an agent or AI feature must pause for human approval at defined points.
**Output:** a checkpoint spec: trigger conditions, human payload design, resume semantics, and SLA handling.
**Prompt:**
```text
You are designing human checkpoints for an AI system. Context: feature {{feature_description}}, actions requiring approval {{sensitive_actions}}, operator audience {{operator_profile}}, volume expectations {{volume_expectations}}.
Task: specify the checkpoints: (1) trigger conditions — which actions always pause (from {{sensitive_actions}}), which pause conditionally (confidence below threshold, cost above threshold, novel situation); each trigger is a measurable condition, not a vibe; (2) the human payload — what the approver sees: a diff-style summary of the proposed action with parameters, the agent's reasoning in 3 lines, the risk assessment, and the alternatives considered; never raw context dumps; (3) approval mechanics — approve / reject with reason / modify-and-approve (edit the parameters inline), with the agent resuming accordingly; rejections feed back as durable instructions (learned constraint) vs one-off, decided per case; (4) resume semantics — exactly what state is preserved, what expires while waiting (locks, sessions), and timeout behavior (auto-reject, auto-escalate, or retry — choose per risk); (5) volume design — at {{volume_expectations}}, batching/grouped approvals where safe vs approval fatigue leading to rubber-stamping; friction proportional to risk; (6) audit — every checkpoint decision logged with payload snapshot for post-hoc review.
Constraints:
- The 3-line reasoning summary is mandatory; long payloads guarantee rubber-stamping.
- Timeout defaults are safe-by-default: waiting times out to the non-destructive state.
- Modification approvals are first-class (the common real case); the agent must handle parameter edits it did not propose.
- Checkpoint placement is justified per {{sensitive_actions}}: irreversible or high-blast-radius actions always checkpoint.
Do not add checkpoints so frequent that {{volume_expectations}} makes them theater; if volume makes human review of every case infeasible, redesign for sampling review of a risky subset — say so.
Output format: trigger table, payload template, approval/resume state machine, timeout policy, volume/friction design, and audit spec.
```

### PROMPT-15-19 — Prompt-Injection Red-Team Generator
**Use when:** adversarially testing a prompt or AI feature against injection attacks.
**Output:** an adversarial test set with attack taxonomy, payloads, and severity grading.
**Prompt:**
```text
You are red-teaming an AI feature. Context: system prompt {{system_prompt}}, feature surface {{feature_description}}, tools/exposure {{exposure_surface}}, known defenses {{current_defenses}}.
Task: generate the attack suite: (1) attack taxonomy applied to this system — direct injection (user tries to override the system prompt), indirect injection (malicious content embedded in {{exposure_surface}} inputs: retrieved docs, uploaded files, tool outputs, emails), extraction (getting the system prompt or hidden instructions), escalation (convincing the model to use tools beyond intent), exfiltration (encoding data into outputs/citations), denial-of-wallet (cost amplification); (2) per attack class, 5–10 concrete payloads crafted for THIS system (referencing its actual tools, data sources, and wording patterns from {{system_prompt}}); payloads range from textbook to creative; (3) expected-vs-broken behavior per payload: what correct defense looks like (refuse, sanitize, ignore-and-continue, alert) and what compromise looks like; (4) severity grading — payload scored by blast radius if it succeeds against {{exposure_surface}}; (5) retest loop — the suite is versioned; each defense fix re-runs the full suite (fixes often overcorrect and break legit behavior).
Constraints:
- Payloads are test artifacts for an authorized assessment of {{feature_description}}; they target the system, not real users or third parties.
- Creative payloads must stay realistic (an actual attacker could deliver them through the real input channels).
- No payload's "success" is celebrated without grading the detection signal it triggered — an attack that fails silently is scored worse than one that fails loudly.
- Where {{current_defenses}} are unknown, the suite is generated anyway with defenses-assumed-unknown noted.
Do not publish payloads outside the authorized test context; deliver them labeled and contained.
Output format: the suite organized by attack class (payload, delivery channel, expected defense, broken-behavior, severity), execution instructions, and the retest-loop policy.
```

### PROMPT-15-20 — Observability Spec for AI Features
**Use when:** an AI feature needs tracing, feedback loops, and production quality metrics.
**Output:** an observability spec: traces, events, feedback capture, quality metrics, and dashboards.
**Prompt:**
```text
You are specifying observability for an AI feature. Context: feature {{feature_description}}, pipeline components {{pipeline_components}} (retrieval, tools, model, post-processing), user surface {{surface}}, privacy constraints {{privacy_rules}}, existing stack {{existing_observability_or_none}}.
Task: specify the telemetry: (1) traces — end-to-end request trace with spans per pipeline stage (retrieval latency/count, tool calls with arg hashes, model call with prompt version ID, token counts in/out, post-processing); every span carries prompt-version + model-version for audit; (2) events — structured events for: refusal, fallback-tier activation, structured-output validation failure, injection-flag (from PROMPT-15-07 detection), human-checkpoint trigger/outcome; (3) feedback capture — explicit (thumbs, corrections, reported-bad) and implicit (regeneration requests, abandonment after response, copy/paste events where relevant) with anti-gaming notes (feedback interpreted in context, not raw rates); (4) quality metrics — production proxies for quality (self-consistency sampling, claim-citation audit on a sampled slice, human review queue sizing) with sampling rates and privacy handling per {{privacy_rules}}; (5) dashboards — the three operator views: health (latency, error, cost), quality (feedback trends, refusal rates, validation-failure rates), safety (injection flags, policy-violation rates); (6) privacy — what is never logged (raw user PII, full prompts where restricted) and the redaction points.
Constraints:
- Trace payloads balance debuggability with {{privacy_rules}}: prompt content logged per policy, hashed/trimmed otherwise; the decision is explicit per field.
- Prompt-version + model-version on every trace is mandatory — unversioned quality metrics are meaningless.
- Feedback metrics include their known biases (satisfied users rarely rate; anger rates more) as caveats on the dashboard.
- Tooling recommendations fit {{existing_observability_or_none}}; unverifiable integrations marked "verify in docs".
Do not log raw chain-of-thought; log decisions, outcomes, and reasons where the model provides them as output.
Output format: trace/span spec, event catalog, feedback design, quality-metrics plan, dashboard layouts, and privacy redaction table.
```
