# 09 — Security

Threat modeling, auth review, vulnerability analysis, and security operations. Covers application and supply-chain security, incident response, and compliance-oriented checks.
Placeholder convention: `{{double_braces}}` mark user-supplied input (feature descriptions, code paths, findings, environment details). Replace every placeholder before sending; a prompt with unfilled placeholders should be treated as incomplete.

---

### PROMPT-09-01 — Threat Model (STRIDE-Lite) for a Feature
**Use when:** designing or reviewing a feature and needing its attack surface mapped early.
**Output:** a STRIDE-classified threat list with mitigations prioritized by risk.
**Prompt:**
```text
ROLE: Application-security engineer building a threat model.
CONTEXT: Feature: {{feature}}. Architecture/data flow: {{data_flow}} (diagram or description). Trust boundaries: {{trust_boundaries}}. Assets at stake: {{assets}}.
TASK: Identify components, data flows, and trust boundaries. For each element, enumerate threats across STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege). Rate each threat (likelihood JUDGMENT unless history exists, impact from {{assets}}) and map mitigations to existing mechanisms or new requirements.
CONSTRAINTS: Every threat must name the concrete attack path, not a category label. Mitigations must map to a real mechanism (framework feature verified against docs, or an explicit new requirement). Do not rate everything high — force a ranked order. Where {{data_flow}} lacks detail, list the missing flows instead of guessing.
OUTPUT FORMAT: Markdown: (1) System overview + trust-boundary diagram (Mermaid), (2) Threat table (element, STRIDE class, attack path, likelihood, impact, mitigation, status), (3) Top risks with mitigation requirements, (4) Security requirements to add to the feature spec, (5) Out-of-scope statements.
```

### PROMPT-09-02 — Authn Flow Review (Session/Token Lifecycle)
**Use when:** reviewing login, session, and token handling for lifecycle weaknesses.
**Output:** an authn lifecycle audit with weaknesses ranked and fixes specified.
**Prompt:**
```text
ROLE: Authentication-security reviewer.
CONTEXT: Auth flow code/config: {{auth_code}} (login, logout, refresh, password reset). Framework/libraries: {{framework}}. Token/session storage: {{storage}} (cookies: flags; mobile: keychain/keystore).
TASK: Walk the full lifecycle: credential submission (TLS, throttling), session fixation on login, token entropy and signing, expiry and refresh rotation, logout invalidation, password-reset token properties (one-time, short-lived, unguessable), and storage security (HttpOnly/Secure/SameSite or equivalent). Flag each weakness with its exploit scenario.
CONSTRAINTS: Verify framework defaults against current {{framework}} docs — defaults change and insecure ones are common. Do not recommend custom crypto; point to vetted library features. Every finding needs severity + exploit path; style opinions excluded. If {{auth_code}} omits a lifecycle stage, mark the review incomplete for that stage.
OUTPUT FORMAT: Markdown: (1) Lifecycle map (Mermaid), (2) Findings table (stage, weakness, exploit, severity), (3) Fix specification per finding, (4) Test cases to prove fixes, (5) Residual-risk statement, (6) Review gaps.
```

### PROMPT-09-03 — Authz Review (RBAC/ABAC, Privilege-Escalation Hunt)
**Use when:** hunting authorization flaws — horizontal/vertical privilege escalation — in code or design.
**Output:** an authorization matrix audit with concrete escalation scenarios.
**Prompt:**
```text
ROLE: Authorization-focused security reviewer.
CONTEXT: Authorization model: {{authz_model}} (roles/permissions/policies). Protected resources and actions: {{resources}}. Enforcement points: {{enforcement}} (middleware, decorators, manual checks).
TASK: Build the expected authorization matrix (role x resource x action). Trace each enforcement point: is the check server-side, does it verify ownership (horizontal) not just role (vertical), can parameters bypass it (IDOR via IDs), are admin functions reachable by lower roles through alternate routes (hidden endpoints, mass assignment, debug flags)?
CONSTRAINTS: Every claimed gap needs a concrete request scenario demonstrating it; theoretical gaps are labeled HYPOTHESIS with the test to confirm. Verify framework authorization APIs against docs. Deny-by-default must be verified, not assumed — find the catch-all. Do not report client-side hiding as a control.
OUTPUT FORMAT: Markdown: (1) Authorization matrix, (2) Enforcement-point audit table, (3) Escalation scenarios (steps, severity, confidence), (4) Fix patterns per scenario, (5) Regression-test additions, (6) Unreviewed surfaces list.
```

### PROMPT-09-04 — OWASP Top 10 Code Review
**Use when:** a codebase or diff needs a systematic pass against the OWASP Top 10.
**Output:** a findings report mapped to OWASP categories with fix guidance.
**Prompt:**
```text
ROLE: Security code reviewer running an OWASP Top 10 pass.
CONTEXT: Code under review: {{code_scope}} (repo paths or diff). Stack and framework: {{stack}}. Exposure: {{exposure}} (internet-facing, internal).
TASK: Review systematically: A01 Broken Access Control, A02 Cryptographic Failures, A03 Injection, A04 Insecure Design, A05 Security Misconfiguration, A06 Vulnerable Components, A07 Auth Failures, A08 Data-Integrity Failures, A09 Logging/Monitoring Gaps, A10 SSRF. For each: evidence from the code (file/line), exploit scenario, severity given {{exposure}}.
CONSTRAINTS: Findings require concrete evidence — no "consider adding" without a demonstrated gap. Framework-provided protections count only if configured (verify against docs). Severity considers {{exposure}}. Distinguish findings from informational hardening. Do not run or write exploit code beyond a proof-of-concept sketch.
OUTPUT FORMAT: Markdown: (1) Findings table (OWASP ID, evidence, scenario, severity), (2) Detailed findings with fix sketches, (3) Verified framework protections vs gaps, (4) Hardening backlog (non-blocking), (5) Re-test plan.
```

### PROMPT-09-05 — Secrets-Handling Audit
**Use when:** auditing where secrets live, how they flow, and where they leak.
**Output:** a secrets-exposure map with remediation and rotation steps.
**Prompt:**
```text
ROLE: Secrets-management auditor.
CONTEXT: Repository/config surface: {{scope}}. Secret storage currently: {{storage}} (env, vault, files). CI/CD pipeline: {{cicd}}. Known history concerns: {{history}}.
TASK: Trace secrets end-to-end: source (how they enter), storage (plaintext files, env, vault), transit (logs, error messages, URLs, analytics), and disposal (rotation, git history). Hunt leakage patterns: hardcoded secrets, secrets in logs, build artifacts, client-side bundles, test fixtures using real credentials. Check .env/.gitignore coverage and CI secret scoping (fork PR exposure).
CONSTRAINTS: If {{scope}} is a repository, use only static inspection — no commits, no pushes. Every found secret requires a rotation plan, not just removal (treat as compromised). Verify vault/CI features against official docs. Never print a found secret's value in the report — reference by location only.
OUTPUT FORMAT: Markdown: (1) Exposure map (stage, finding, location), (2) Findings ranked with rotation requirements, (3) Remediation plan (storage, scanning, CI scoping), (4) Git-history cleaning decision (rewrite vs accept + rotate), (5) Prevention controls checklist.
```

### PROMPT-09-06 — Dependency Vulnerability Triage (CVE to Fix Plan)
**Use when:** a vulnerability scan produced CVEs and you need a triaged, ordered fix plan.
**Output:** a triage table with exploitability assessment and fix order.
**Prompt:**
```text
ROLE: Vulnerability-triage engineer.
CONTEXT: Scan output: {{scan_output}} (tool, findings list). Application context: {{context}} (is the vulnerable function reachable? exposed to internet?). Update policy constraints: {{constraints}} (semver pinning, vendor approval).
TASK: For each finding: identify the vulnerable function and check reachability in {{context}} (direct dependency vs transitive; code path actually invoked — state UNREACHABLE if analysis incomplete, not assumed), assess exploitability (public exploit? severity score components), and propose action: upgrade (target version, breaking-change risk), patch, mitigate (config/WAF), or accept (with expiry date and owner).
CONSTRAINTS: Reachability is the key filter — a critical CVE in an unused code path is not a fire. Verify fixed versions against the advisory/vendor source, not just the scanner. Breaking-change risk must be labeled UNKNOWN until {{constraints}} are checked. Accepted risks require an expiry and an owner. No invented compatibility claims.
OUTPUT FORMAT: Markdown: (1) Triage table (CVE, package, reachability, exploitability, action, owner, due), (2) Detailed notes for top items, (3) Upgrade order with dependency-risk notes, (4) Accepted-risk register, (5) Re-scan command and schedule.
```

### PROMPT-09-07 — Injection-Surface Review (SQL/NoSQL/Command/Template)
**Use when:** auditing code paths that build queries, commands, or templates from input.
**Output:** an injection-surface inventory with sink-by-sink verdicts.
**Prompt:**
```text
ROLE: Injection-focused code reviewer.
CONTEXT: Code surface: {{code_scope}}. Data stores and template engines in use: {{stores}}. Input entry points: {{entry_points}}.
TASK: Inventory all sinks: SQL/ORM raw fragments, NoSQL query builders with $where/eval, shell/process execution, template rendering (SSTI), expression evaluators, LDAP/XML parsers. For each sink trace the input flow from {{entry_points}}: parameterized (safe), sanitized (name the sanitizer and its limits), or raw concatenation (vulnerable). Propose fixes using the stack's verified safe APIs.
CONSTRAINTS: Verify each proposed API against {{stores}} / framework docs — ORM escape hatches vary. Sanitization alone must be justified (allowlist vs blocklist). Every verdict cites the file/line; unverifiable flows are marked NEEDS TRACE, not safe. Proofs of concept are sketches only, no live exploitation.
OUTPUT FORMAT: Markdown: (1) Sink inventory table (sink, type, flow verdict, evidence), (2) Vulnerable findings with exploit sketch + fix, (3) Safe-pattern reference per store, (4) Static-analysis rules to enable (exact rule names), (5) Retest checklist.
```

### PROMPT-09-08 — SSRF/Path-Traversal Review
**Use when:** code fetches user-influenced URLs or reads user-influenced file paths.
**Output:** a review of URL/file sinks with validation designs.
**Prompt:**
```text
ROLE: Input-validation security reviewer.
CONTEXT: Features under review: {{features}} (URL fetchers, webhooks, importers, file serving). URL/path handling code: {{code}}. Network egress policy: {{egress}}.
TASK: For each sink: trace how user input shapes the URL/path, identify the attack (SSRF to internal metadata/admin services; traversal to read arbitrary files; scheme confusion file:// vs https; DNS rebinding notes). Design defense: allowlist hosts where feasible, deny internal IP ranges (with rebinding caveat), scheme allowlist, path canonicalization, and egress restrictions.
CONSTRAINTS: Verify language/library URL parsing behavior against docs — parsers disagree on what a "host" is; note which parser the fix uses. Internal-range blocking must handle IPv6 and redirects (redirect policy must be specified). Allowlist beats blocklist — justify any blocklist. Egress controls reference {{egress}} or are proposed with effort noted.
OUTPUT FORMAT: Markdown: (1) Sink table (feature, input path, attack scenario, verdict), (2) Defense design per finding, (3) Canonicalization approach (with library choice verified), (4) Redirect-handling policy, (5) Test cases (payloads), (6) Residual risks.
```

### PROMPT-09-09 — API Abuse-Case Design
**Use when:** designing how an API could be abused beyond its intended use and building defenses.
**Output:** abuse cases with detection and rate-limit design.
**Prompt:**
```text
ROLE: Abuse-case analyst for APIs.
CONTEXT: API surface: {{api}} (endpoints, auth model). Business limits that must hold: {{limits}} (e.g., one trial per user, no scraping). Attacker incentives: {{incentives}}.
TASK: Enumerate abuse cases per endpoint: enumeration (user IDs, tokens), replay, race conditions (double-spend of credits), resource exhaustion (expensive queries, large uploads), automation (credential stuffing, scalping), data harvesting. For each: detection signal, preventive control, and rate-limit/cost design (per-user, per-IP, per-token buckets — with limit values labeled ESTIMATE to tune).
CONSTRAINTS: Controls must not break legitimate power users — note the false-positive tension per control. Verify rate-limiting middleware features against framework docs. Every abuse case ties to a business harm in {{limits}} or {{incentives}}, not hypothetical paranoia. Detection signals must be loggable with existing observability.
OUTPUT FORMAT: Markdown: (1) Abuse-case table (endpoint, abuse, harm, detection, prevention), (2) Rate-limit design per resource, (3) Cost-based throttling notes, (4) Monitoring/alerting signals, (5) False-positive handling, (6) Unaddressed abuse (accepted risks).
```

### PROMPT-09-10 — Supply-Chain Review (CI/CD, Actions Pinning)
**Use when:** auditing the build pipeline and dependencies for supply-chain compromise.
**Output:** a pipeline trust audit with hardening actions ranked.
**Prompt:**
```text
ROLE: Supply-chain security auditor.
CONTEXT: CI/CD configuration: {{cicd_config}} (workflow files, build scripts). Registry/package sources: {{sources}}. Runner environment: {{runners}} (shared, self-hosted, ephemeral).
TASK: Audit: third-party actions pinned to SHA (not tags), permissions scope (GITHUB_TOKEN least privilege), secrets exposure to fork PRs, runner isolation, artifact integrity (signing/provenance if supported — verify against platform docs), dependency lockfiles enforced, package registry allowlists, and build script injection surfaces (PR titles in run steps).
CONSTRAINTS: Verify each platform feature (OIDC, provenance, pinned actions) against current docs — availability varies by plan. Every hardening item needs effort (small/medium/large). Do not recommend controls that break the team's release cadence without noting the process change. Severity considers {{runners}} trust level.
OUTPUT FORMAT: Markdown: (1) Pipeline trust map (stages, trust level), (2) Findings table (issue, evidence, severity, fix effort), (3) Hardening plan ordered by risk-reduction/effort, (4) Verification steps post-hardening, (5) Residual trust assumptions.
```

### PROMPT-09-11 — Incident-Response Runbook Builder
**Use when:** preparing a runbook for a specific incident class before it happens.
**Output:** an executable runbook with roles, timelines, and comms templates.
**Prompt:**
```text
ROLE: Incident-response lead writing a runbook.
CONTEXT: Incident class: {{incident_class}} (e.g., credential leak, RCE, data exposure). Systems involved: {{systems}}. Team structure: {{team}} (on-call, security, comms). Regulatory duties: {{regulatory}}.
TASK: Write the runbook: detection signals and triage questions, severity assignment, first-30-minutes actions (contain: revoke, isolate, block), evidence preservation (what to capture before rebuilding), eradication/recovery steps, communication plan (internal, users, regulators per {{regulatory}} with timelines), and post-incident hooks (hand-off to the post-incident lessons-learned extractor).
CONSTRAINTS: Actions must be executable by the on-call engineer alone — note any step requiring escalation. Legal/notification timelines from {{regulatory}} must be verified against current requirements, else marked VERIFY. Containment steps must not destroy evidence. Include a "when in doubt, escalate" trigger with named roles.
OUTPUT FORMAT: Markdown runbook: (1) Overview + severity table, (2) Detection and triage, (3) Timeline actions (0-30 min, 30 min-2 h, 2 h+), (4) Evidence checklist, (5) Comms templates (draft messages), (6) Recovery and verification, (7) Post-incident actions, (8) Escalation contacts.
```

### PROMPT-09-12 — Security-Headers/CSP Review
**Use when:** reviewing HTTP security headers and Content-Security-Policy for a web app.
**Output:** a header audit with a CSP build-up plan.
**Prompt:**
```text
ROLE: Web-security reviewer.
CONTEXT: Application: {{app}} (framework, serving layer). Current headers: {{current_headers}} (curl output or config). App's resource loading: {{resource_model}} (inline scripts? third-party domains? iframes?).
TASK: Audit: Strict-Transport-Security, Content-Security-Policy, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, frame protections. Build a CSP from {{resource_model}}: start restrictive, enumerate required sources per directive, and design a report-only roll-out with violation monitoring before enforcement. Note inline-script removal work needed.
CONSTRAINTS: CSP directive support varies by browser — verify against current compatibility data before relying on a directive. Do not weaken a header to make an existing bad pattern work — list the pattern as work instead. Report-only-first is mandatory. Every allowed source in the CSP must be justified by {{resource_model}}.
OUTPUT FORMAT: Markdown: (1) Header audit table (header, current, verdict, fix), (2) Proposed CSP with per-source justification, (3) Rollout plan (report-only → enforce), (4) Violation monitoring setup, (5) Removal work list (inline scripts etc.), (6) Verification commands.
```

### PROMPT-09-13 — Encryption-at-Rest/Transit Checklist
**Use when:** verifying data protection in transit and at rest across a system.
**Output:** a protection matrix with gaps and migration actions.
**Prompt:**
```text
ROLE: Data-protection auditor.
CONTEXT: Data inventory: {{data_inventory}} (data classes: PII, financial, internal). Storage locations: {{storage}} (DBs, object stores, backups, logs). Transit paths: {{transit}} (client-app, service-service, DB connections).
TASK: Build the matrix: data class x location/path with current protection (TLS version, at-rest encryption, key management) and required protection. Identify gaps: unencrypted backups, TLS termination points, internal plaintext hops, keys co-located with data, log leakage. Propose fixes with key-management approach (KMS/HSM as appropriate — verify provider features against docs).
CONSTRAINTS: "Encrypted" claims need mechanism evidence (config citation), else marked UNVERIFIED. Key rotation and access policies must be specified, not just "use KMS." Backups and replicas count as storage — common miss. Compliance requirements from {{data_inventory}} take precedence over generic advice; uncertain requirements flagged for review.
OUTPUT FORMAT: Markdown: (1) Protection matrix (class, location, current, required, gap), (2) Gap remediation plan, (3) Key-management design sketch, (4) Verification commands/tests, (5) Accepted-risk register.
```

### PROMPT-09-14 — Logging-PII Audit
**Use when:** checking that logs and telemetry do not capture PII or secrets.
**Output:** a PII-in-telemetry findings list with redaction design.
**Prompt:**
```text
ROLE: Privacy engineer auditing telemetry.
CONTEXT: Logging/telemetry code surface: {{code_scope}}. Telemetry backends: {{backends}} (log aggregator, APM, analytics). Data classes to protect: {{pii_classes}}.
TASK: Find PII/secrets capture points: request/response bodies logged wholesale, auth headers, cookies, query strings with tokens, user identifiers in analytics events, stack traces embedding data, debug dumps. For each: what's captured, where it lands (retention in {{backends}}), and redaction design (field denylist, structured logging with scrubbing middleware — verify framework hooks against docs).
CONSTRAINTS: Verify logging-middleware/scrubbing APIs against {{backends}} and framework docs. Retention matters — a redaction fix does not erase already-captured data; include purge handling. Do not propose disabling logs; propose structured minimization. Every finding cites the capture site; suspected-but-unconfirmed paths marked NEEDS TRACE.
OUTPUT FORMAT: Markdown: (1) Findings table (capture site, data class, destination, severity), (2) Redaction design, (3) Backlog purge/retention actions, (4) Prevention (lint rules, review checklist), (5) Verification method (sampled log audit procedure).
```

### PROMPT-09-15 — Penetration-Test Scoping Brief
**Use when:** preparing a brief for an external or internal penetration test.
**Output:** a scoping document with rules of engagement and success criteria.
**Prompt:**
```text
ROLE: Security lead preparing a pentest engagement.
CONTEXT: System: {{system}}. Prior security work: {{prior_work}}. Biggest concerns: {{concerns}}. Constraints: {{constraints}} (windows, environments, third-party approvals).
TASK: Write the brief: assets and attack-surface inventory, threat model summary (what an attacker wants), in-scope/out-of-scope with rationale, rules of engagement (allowed techniques, blackout times, data handling, legal authorization statement), test environment setup, credentials/roles to provision, and success criteria (what decisions the report should enable).
CONSTRAINTS: Legal authorization must be explicit (system ownership). Production testing limits stated per {{constraints}}. Out-of-scope items need a reason and a future consideration. Success criteria must be decision-oriented (e.g., "can we ship X"), not "find bugs." Third-party systems excluded unless written approval exists.
OUTPUT FORMAT: Markdown brief: (1) Engagement summary, (2) Scope tables (in/out with rationale), (3) Rules of engagement, (4) Environment and access prep, (5) Threat-priorities from {{concerns}}, (6) Deliverables expected, (7) Post-test remediation plan commitment.
```

### PROMPT-09-16 — Secure-Defaults Config Review
**Use when:** reviewing framework/server configuration against secure defaults.
**Output:** a config diff-style report with hardening changes.
**Prompt:**
```text
ROLE: Hardening reviewer comparing configuration to secure defaults.
CONTEXT: Configuration files: {{configs}} (server, framework, DB, cloud resources). Stack versions: {{versions}}. Deployment model: {{deployment}}.
TASK: Audit against known-baseline secure defaults for each component: debug modes off, default credentials changed, verbose errors suppressed, unnecessary services/ports disabled, TLS configured, admin interfaces unexposed, cloud resource public-access blocks, least-privilege service accounts. Output as a prioritized diff-style change list.
CONSTRAINTS: Every recommendation cites the baseline source (CIS benchmark, official hardening guide) and is verified against {{versions}} — defaults change across versions. Do not recommend changes that break {{deployment}} without noting the trade-off. Severity considers exposure. Verify cloud config claims against provider docs for the specific service.
OUTPUT FORMAT: Markdown: (1) Findings table (component, setting, current, recommended, source, severity), (2) Diff-style change list ordered by risk, (3) Trade-off notes, (4) Verification commands, (5) Recurring-audit plan.
```

### PROMPT-09-17 — Token/Credential-Rotation Plan
**Use when:** designing how secrets, keys, and credentials rotate without downtime.
**Output:** a rotation runbook per credential class with zero-downtime design.
**Prompt:**
```text
ROLE: Secrets-rotation engineer.
CONTEXT: Credential inventory: {{credentials}} (DB passwords, API keys, JWT signing keys, TLS certs, cloud keys). Consumers of each: {{consumers}}. Rotation constraints: {{constraints}} (downtime tolerance, multi-region).
TASK: Design rotation per credential class: dual-credential overlap (old+new valid during transition), propagation order (issue new → deploy → verify → revoke old), signing-key rotation with key IDs in tokens (verify framework JWKS support against docs), certificate renewal automation, and emergency rotation (compromise) path distinct from routine rotation.
CONSTRAINTS: No rotation design may require simultaneous restart of all consumers unless {{constraints}} explicitly allows it. Verify tooling capabilities (managed rotation, cert-manager, etc.) against docs — mark MANUAL where no tool exists. Emergency path must complete faster than routine; state both time targets as ESTIMATE. Rollback per phase required.
OUTPUT FORMAT: Markdown: (1) Credential-class table (rotation cadence, method, consumers), (2) Routine rotation runbook per class, (3) Emergency rotation runbook, (4) Automation opportunities and gaps, (5) Verification steps, (6) Calendar proposal with owners.
```

### PROMPT-09-18 — Security Regression Test Writer
**Use when:** converting security fixes or findings into permanent regression tests.
**Output:** regression test code plus CI placement guidance.
**Prompt:**
```text
ROLE: Security QA engineer writing regression tests.
CONTEXT: Security fix or finding: {{finding}} (description, affected code). Test stack: {{test_stack}}. Layer appropriate: {{layer}} (unit/integration/E2E) if known.
TASK: Write a failing-first regression test that demonstrates {{finding}} (attack input or scenario), then the passing version against the fixed code. Cover the fix and adjacent variants (boundary inputs, bypass attempts). Place at the lowest layer that exercises the real vulnerable path — a unit test of a sanitizer only counts if the sanitizer is actually invoked in the flow.
CONSTRAINTS: Attack payloads from documented classes (OWASP cheat sheets), not invented. Verify test-framework security utilities against docs. Mark tests that depend on environment (WAF, rate limits) as environment-gated. The test must fail on the vulnerable version — state how to verify that claim.
OUTPUT FORMAT: Markdown: (1) Finding summary, (2) Regression test code (vulnerable-verification note), (3) Variant cases list, (4) CI placement and gating notes, (5) Related-untested-surfaces list.
```

### PROMPT-09-19 — Third-Party Vendor Security Questionnaire
**Use when:** assessing a vendor's security posture before or during engagement.
**Output:** a structured questionnaire with evidence requirements and scoring.
**Prompt:**
```text
ROLE: Vendor-security assessor.
CONTEXT: Vendor and service: {{vendor}}. Data shared with vendor: {{data_shared}}. Risk tier: {{risk_tier}} (based on {{data_shared}}). Compliance needs: {{compliance}}.
TASK: Build the questionnaire: org-level (security program, certifications with scope evidence), product-level (encryption, authn/authz model, tenant isolation, logging), operational (incident history and notification SLAs, backup/DR, vuln management timelines, pentest cadence), and data lifecycle (retention, deletion on exit, subprocessors). Require evidence (reports, certificates with scope) not attestations; define pass/fail per item based on {{risk_tier}}.
CONSTRAINTS: Certification claims require scope verification (what product/infrastructure is covered). Vulnerability-timeline answers need contractual backing, not policy statements. Subprocessor lists must be current. Items the vendor refuses to answer are scored as gaps, not neutrally. Verify {{compliance}} obligations are reflected in required controls.
OUTPUT FORMAT: Markdown: (1) Questionnaire sections with items (question, evidence required, pass bar), (2) Scoring rubric, (3) Conditional-pass handling, (4) Contract-clause recommendations for gaps, (5) Re-assessment cadence, (6) Decision summary template.
```

### PROMPT-09-20 — Post-Incident Lessons-Learned Extractor
**Use when:** after an incident, extracting durable lessons instead of blame.
**Output:** a structured postmortem with action items that have owners and dates.
**Prompt:**
```text
ROLE: Post-incident facilitator producing a blameless postmortem.
CONTEXT: Incident summary: {{incident}} (timeline, impact, detection, resolution). Participants' notes: {{notes}}. Systems involved: {{systems}}.
TASK: Build the postmortem: impact statement (user-visible, with numbers MEASURED or ESTIMATE labeled), timeline reconstruction (detection lag emphasized), root cause (5-Whys to mechanism, not person), contributing factors, what went well, and action items classified as mitigate (prevent recurrence), detect (faster discovery), or process — each with owner, due date, and verification method.
CONSTRAINTS: Blameless by construction: actions name system/process changes, never individuals. Root cause stops at controllable mechanisms. Every action item has a verification ("how we'll know it's done"). Detection-lag must be quantified. Do not dilute with generic advice ("add more tests") — each action is specific and scoped. Distinguish facts (timeline evidence) from inferences.
OUTPUT FORMAT: Markdown: (1) Summary and impact, (2) Timeline, (3) Root-cause analysis, (4) Contributing factors, (5) Action items table (type, action, owner, due, verification), (6) Publish/share plan, (7) Follow-up review date.
```
