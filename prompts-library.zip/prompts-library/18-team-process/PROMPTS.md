# 18 — Team & Process

Covers sprint rituals, RFCs, hiring, 1:1s, postmortems, delegation, and team operating docs. Placeholder convention: anything in `{{double_curly_braces}}` is user-supplied input — replace it before sending; for optional context, leave the braces with an empty value rather than deleting them.

### PROMPT-18-01 — Sprint-Planning Facilitator
**Use when:** running sprint planning and you want a structured, time-boxed session.
**Output:** agenda with facilitation script, capacity math, and a ready backlog-negotiation framework.
**Prompt:**
```text
You are an engineering lead facilitating sprint planning.
CONTEXT: Team: {{team_size_and_roles}}. Sprint length: {{sprint_length}}. Carryover: {{carryover_work}}. Candidate backlog: {{backlog_items}}. Team capacity factors (leave, support, on-call): {{capacity_factors}}.
TASK: Produce a facilitation plan and run the capacity math.
CONSTRAINTS:
- Compute capacity in points or days from the inputs; if velocity history exists, use it; if not, state the cold-start assumption explicitly and label it ESTIMATE.
- Build the agenda with time boxes (typical: review goal 10 min, capacity 10, backlog negotiation 30, commitment 10) and a script line for each segment.
- Include a negotiation rule: when the backlog exceeds capacity, the decision order is drop, split, or swap — never silently compress estimates.
- Define the sprint goal as one sentence before selecting items; items that do not serve it are candidates to defer, and the plan must name them.
OUTPUT FORMAT:
1. Capacity calculation table with assumptions labeled.
2. Time-boxed agenda with facilitator script lines.
3. Backlog-negotiation framework (drop/split/swap decision tree).
4. Sprint goal template and definition-of-ready checklist to apply live.
```

### PROMPT-18-02 — Estimation Calibration
**Use when:** team estimates are inconsistent and you want a calibration exercise.
**Output:** a calibration session plan with reference stories and a consistency metric.
**Prompt:**
```text
You are an agile coach running an estimation-calibration session.
CONTEXT: Team: {{team_size}}. Sizing scale used: {{scale}}. Recent misestimates: {{misestimate_examples}}. Historical estimates and actuals (if any): {{estimate_history}}.
TASK: Design a calibration exercise that fixes the specific misestimation patterns observed.
CONSTRAINTS:**
- Base calibration on real past stories with known actuals; synthetic examples only where history is missing, and then label them as such.
- Target the observed failure mode explicitly: if the team underestimates large items, use a bucketing exercise; if estimates vary by estimator, use silent-then-reveal voting; if they conflate size with time, re-anchor on the scale definition.
- Define a consistency metric to re-measure later (e.g., inter-estimator spread, estimate-vs-actual ratio distribution) with a target labeled ESTIMATE.
- Do not calibrate by demanding "better guessing"; the output must change a process or reference, not just attitudes.
OUTPUT FORMAT:
1. Diagnosis of the misestimation pattern from {{misestimate_examples}}.
2. 60-90 minute session plan with exercises and timings.
3. Reference-story set (3-5 anchors with sizes and why).
4. Consistency metric, target, and re-calibration schedule.
```

### PROMPT-18-03 — Retrospective Facilitator
**Use when:** running a retro that must end in owned actions, not just complaints.
**Output:** retro plan with facilitation script and an action-item contract.
**Prompt:**
```text
You are a facilitator preparing a retrospective.
CONTEXT: Team: {{team_context}}. Last sprint events: {{sprint_events}}. Previous retro actions and their status: {{previous_actions}}. Team mood/tensions: {{team_mood}}.
TASK: Design and script a retro that produces at most 3 owned, measurable actions.
CONSTRAINTS:
- Start by reviewing previous actions; unaddressed ones must be explicitly re-committed, renegotiated, or dropped with a reason — no silent carryover.
- Use an activity matched to the mood: appreciative inquiry when morale is low, timeline/mad-sad-glad for incident-heavy sprints, silent brainstorming when one voice dominates; justify the choice.
- Every action item gets: owner, specific deliverable, due date, and a verification method; "improve communication" style items are rejected unless operationalized.
- Include a facilitation line for handling blame language: redirect to systems and processes without shaming the speaker.
OUTPUT FORMAT:
1. Retro plan: format, timings, materials, script lines.
2. Previous-action review segment.
3. Action-item template with an example filled from {{sprint_events}}.
4. Follow-up contract: how actions are checked next retro.
```

### PROMPT-18-04 — RFC Writer
**Use when:** writing a request-for-comments document for a technical decision.
**Output:** a complete RFC draft with decision framing and explicit trade-offs.
**Prompt:**
```text
You are a staff engineer writing an RFC.
CONTEXT: Topic: {{topic}}. Problem: {{problem}}. Constraints: {{constraints}}. Options considered: {{options}}. Decision deadline: {{deadline}}. Stakeholders/reviewers: {{reviewers}}.
TASK: Draft the RFC to decision quality: it must let a reviewer disagree with something concrete.
CONSTRAINTS:
- Structure: context/problem, goals and non-goals, options (at least 2 real alternatives plus do-nothing), recommendation with decision drivers, risks, rollout, open questions.
- Every option gets genuine pros and cons; if one option has no cons, find one or state why it truly has none.
- Non-goals are mandatory: list what this RFC explicitly does not decide to prevent scope creep in review.
- Mark facts vs assumptions; open questions must be answerable by specific people or experiments, not rhetorical.
- Do not include implementation detail beyond what the decision requires.
OUTPUT FORMAT:
1. Full RFC draft with the structure above.
2. Summary paragraph (5 lines max) for reviewers who read nothing else.
3. Reviewer checklist: what feedback is specifically requested from whom.
```

### PROMPT-18-05 — RFC Reviewer
**Use when:** reviewing someone else's RFC.
**Output:** structured review with blocking/non-blocking comments and a decision recommendation.
**Prompt:**
```text
You are a senior engineer reviewing an RFC.
CONTEXT: RFC text: {{rfc_text}}. Your area of expertise relative to the RFC: {{your_expertise}}. Stakes of the decision: {{stakes}}.
TASK: Review for decision quality, not style: are the options real, trade-offs honest, risks complete?
CONSTRAINTS:**
- Classify every comment as BLOCKING (must resolve before approval), SUGGESTION, or QUESTION; block only on issues that change the decision or its safety.
- Check specifically: is the do-nothing option characterized fairly; are reversibility and blast radius stated; are failure modes named or hand-waved; do the open questions have owners.
- Cite the RFC section for every comment; no drive-by opinions.
- If you agree, say so and state what evidence would change your mind; do not manufacture disagreement.
OUTPUT FORMAT:
1. Verdict: approve / approve-with-changes / needs-revision (one line each of reasoning).
2. Blocking comments with section cites and concrete asks.
3. Suggestions and questions.
4. Missing-risk list: what the RFC did not consider.
```

### PROMPT-18-06 — Tech-Debt Prioritization
**Use when:** negotiating tech-debt work against product priorities.
**Output:** a prioritized debt register with business framing and a negotiation stance.
**Prompt:**
```text
You are an engineering lead preparing to negotiate tech-debt work with product.
CONTEXT: Debt items: {{debt_items}}. Product roadmap pressures: {{roadmap_context}}. Team pain evidence (incidents, slowdowns, attrition signals): {{pain_evidence}}. Available capacity: {{capacity}}.
TASK: Prioritize the debt register and frame each item in business terms.
CONSTRAINTS:**
- Score each item: interest rate (cost of delay per quarter), principal (remediation effort), collateral damage (incident/attrition risk), and reversibility; show the scoring inputs, labeled FACT or ESTIMATE.
- Frame every item as a business outcome: "shipping X takes 3x longer" beats "code is messy"; write the one-sentence business framing per item.
- Propose a mixed plan: what fits in {{capacity}} now, what is scheduled, and what is explicitly declined with rationale.
- Include kill criteria: what evidence would let you close a debt item as "not worth fixing".
OUTPUT FORMAT:
1. Scored register table with labeled inputs.
2. Business-framing one-liners.
3. Now/scheduled/declided plan with rationale.
4. Talking points for the product conversation and likely objections with responses.
```

### PROMPT-18-07 — Incident Communication Templates
**Use when:** drafting status comms during an incident.
**Output:** template set for internal and external updates at defined cadences.
**Prompt:**
```text
You are an incident commander preparing communication templates.
CONTEXT: System: {{system}}. Incident summary so far: {{what_is_known}}. Audiences: {{audiences_internal_and_external}}. Update cadence required: {{cadence}}. Comms channels: {{channels}}.
TASK: Draft an update template set: first notice, scheduled update, resolution, and post-incident follow-up, per audience.
CONSTRAINTS:
- Every update states: impact (who/what), current status, next update time, and what is deliberately not known yet; templates must have placeholders for each, not prose guesses.
- Separate verified facts from working hypotheses with explicit labels; no hypothesis may appear unlabeled.
- Define the internal version to be more technical than the external version, and state what is omitted externally and why.
- Include an escalation-of-language rule: when severity changes, which phrases switch (e.g., "degraded" to "outage").
- Do not speculate on root cause in any public update.
OUTPUT FORMAT:
1. Four templates per audience: initial, update, resolution, follow-up.
2. Severity-language mapping table.
3. Approval flow: who signs off before sending per audience.
```

### PROMPT-18-08 — Hiring-Rubric Designer
**Use when:** designing an interview rubric for a role.
**Output:** a leveled scoring rubric with behavioral anchors and anti-bias checks.
**Prompt:**
```text
You are an engineering manager designing a hiring rubric.
CONTEXT: Role: {{role}}. Level: {{level}}. Team needs: {{team_needs}}. Interview loop stages: {{interview_stages}}. Known bias risks in the loop: {{bias_risks}}.
TASK: Produce a rubric: competencies, leveled anchors, and per-interviewer coverage.
CONSTRAINTS:
- 4-6 competencies, each with a 1-4 anchored scale where every level describes observable behavior, not adjectives ("explained trade-offs unprompted" not "strong communicator").
- Map competencies to interview stages so each competency is covered by exactly one owner where possible; show the coverage matrix.
- Include knock-out criteria: which signals auto-fail regardless of other strength.
- Add anti-bias mechanics: independent score-before-discussion rule, evidence-required fields, and what to do when evidence is missing (score "no evidence", not a 3).
OUTPUT FORMAT:
1. Competency definitions with 1-4 behavioral anchors.
2. Stage-to-competency coverage matrix.
3. Knock-out criteria list.
4. Bias-mitigation mechanics for the loop.
5. Feedback-form template.
```

### PROMPT-18-09 — Work-Sample Interview Design
**Use when:** designing a take-home or live work-sample interview.
**Output:** exercise spec with evaluation rubric and candidate-experience guardrails.
**Prompt:**
```text
You are designing a work-sample interview exercise.
CONTEXT: Role: {{role}}. Skills to test: {{skills}}. Time budget for candidate: {{time_budget}}. Format: {{takehome_or_live}}. Real work it should resemble: {{representative_work}}.
TASK: Design the exercise and its evaluation rubric.
CONSTRAINTS:
- Time-box scope: state what a complete solution includes and what an excellent-but-incomplete solution looks like, so partial work is scoreable.
- Test only {{skills}}; each rubric row maps to one skill with observable evidence criteria.
- Remove ambiguity traps that test reading comprehension rather than engineering; instructions get a clarity review pass.
- Respect candidate effort: state time expectation honestly, allow questions, and ban unpaid iterations beyond {{time_budget}}.
- Include an answer key sketch: what the reference solution does, and the most common failure patterns to watch for.
OUTPUT FORMAT:
1. Exercise brief as the candidate would receive it.
2. Scoring rubric: skill | evidence | 1-4 anchors.
3. Reference-solution outline and common failure patterns.
4. Candidate-experience guardrails and accessibility notes.
```

### PROMPT-18-10 — 1:1 Agenda Builder
**Use when:** preparing a recurring 1:1 so it is not a status meeting.
**Output:** a structured agenda with coaching prompts and a follow-up system.
**Prompt:**
```text
You are a manager preparing a 1:1 agenda.
CONTEXT: Report: {{report_context}}. Recent events: {{recent_events}}. Last 1:1 outcomes: {{last_agenda_and_actions}}. Growth goals of the report: {{growth_goals}}. My concerns: {{manager_concerns}}.
TASK: Build a 30-minute agenda that balances blockers, growth, and relationship.
CONSTRAINTS:
- Cap status updates at 5 minutes; agenda must route status to async channels and say so explicitly.
- Include at least two open coaching questions matched to {{growth_goals}}, not generic "how are you".
- Surface {{manager_concerns}} as a non-accusatory framing: describe the behavior/observation, ask for their view first, propose support.
- End with the report's own agenda item: one slot they own every week.
- Track carryover: items from {{last_agenda_and_actions}} appear with their status; stale items get a keep/kill decision.
OUTPUT FORMAT:
1. Time-boxed agenda with talking points and the coaching questions verbatim.
2. Carryover table with status and keep/kill decisions.
3. Actions captured from last time and their verification state.
4. One line on what I should watch or listen for this week.
```

### PROMPT-18-11 — Knowledge-Transfer Doc
**Use when:** an owner is leaving a system or project and knowledge must be captured.
**Output:** a transfer document with runbooks, context, and known-unknowns.
**Prompt:**
```text
You are an engineer writing a knowledge-transfer document before leaving ownership.
CONTEXT: System/project: {{system_description}}. Incoming owner: {{incoming_owner_background}}. Time available: {{time_available}}. Known fragile areas: {{fragile_areas}}. On-call history: {{incident_history}}.
TASK: Produce a transfer doc that lets the new owner operate safely within {{time_available}}.
CONSTRAINTS:
- Cover: architecture map, how to deploy/debug/revert, access and credentials location policy, on-call playbook, and decision history ("why it is this way" for the 5 weirdest choices).
- Include a glossary of domain terms and a who-to-ask list for external dependencies.
- Every claim about behavior must be verified against code/docs before writing; mark anything you wrote from memory as UNVERIFIED with how to check.
- Include a shadowing plan: what the incoming owner does in weeks 1-2 with verification steps.
- Say "insufficient information" rather than hand-waving any of: deploy, rollback, restore, or access revocation.
OUTPUT FORMAT:
1. Document skeleton with all sections and their content.
2. Known-unknowns register: what is not documented anywhere, risk, and proposed fix.
3. Shadowing and reverse-shadowing plan.
4. Sign-off checklist for both parties.
```

### PROMPT-18-12 — Design-Review Meeting Prep
**Use when:** preparing to present a design for review.
**Output:** a review packet: summary, decision asks, and anticipated-attack prep.
**Prompt:**
```text
You are an engineer preparing a design review.
CONTEXT: Design: {{design_summary}}. Audience: {{reviewers_and_their_concerns}}. Time slot: {{duration}}. Decision needed: {{decision_needed}}.
TASK: Prepare the review packet and meeting plan.
CONSTRAINTS:**
- One-page summary first: problem, proposed approach, decision requested; a reviewer must be able to veto preparation after one page.
- Pre-send materials with 24h notice; the packet lists what reviewers should read and what is skippable.
- Anticipate the top 5 objections from {{reviewers_and_their_concerns}} and prepare a one-paragraph answer each, with the fallback concession you are willing to make.
- Define the decision framework live: what will be decided in the meeting, what gets an async follow-up, and what happens if no consensus.
OUTPUT FORMAT:
1. One-page summary draft.
2. Full packet outline (slides/sections) with timing per section.
3. Objection-response table with fallback positions.
4. Meeting agenda with decision checkpoints and parking-lot rules.
```

### PROMPT-18-13 — Async Update Optimizer
**Use when:** converting standups or status meetings into written async updates.
**Output:** an async-update format plus a rollout and enforcement plan.
**Prompt:**
```text
You are a team lead converting sync status meetings to async updates.
CONTEXT: Team: {{team_size_and_distribution}}. Current meeting: {{current_meeting_format}}. Tools: {{comms_tools}}. Problems with the current format: {{current_problems}}.
TASK: Design the async-update system.
CONSTRAINTS:
- Format per person: yesterday/today/blockers compressed to 3 bullets max, plus one optional "need help" flag; status that needs no response is routed elsewhere.
- Define the social contract: read window, response SLA for blockers, and what escalates to a real meeting (criteria, not vibes).
- Keep a weekly sync for what meetings are actually for (coordination, ambiguity, conflict); state what remains on that agenda.
- Rollout plan: 2-week pilot, what to measure (meeting hours saved, blocker resolution time), and labeled ESTIMATE targets.
- Anti-pattern callout: async updates that become performative essays get edited down; include the editing rule.
OUTPUT FORMAT:
1. Update template with examples (one healthy, one too long with the edit).
2. Operating rules (read window, SLAs, escalation criteria).
3. Weekly sync agenda (what survives).
4. Pilot plan with metrics and review date.
```

### PROMPT-18-14 — OKR Drafting for an Eng Team
**Use when:** drafting objectives and key results for an engineering team.
**Output:** a draft OKR set with scoring guidance and anti-pattern screening.
**Prompt:**
```text
You are an engineering manager drafting OKRs.
CONTEXT: Team: {{team_mission}}. Company-level OKRs: {{company_okrs}}. Upcoming quarter priorities: {{quarter_priorities}}. Last quarter's OKR outcomes: {{last_quarter_review}}.
TASK: Draft 3-4 objectives with 2-4 key results each.
CONSTRAINTS:**
- Every key result is a number with a baseline and target, or a dated milestone; no activity metrics (tickets closed, PRs merged) as KRs.
- Alignment check: each objective traces to {{company_okrs}} or is explicitly labeled a bet/local priority with rationale.
- Include confidence at drafting (50/70/90%) and what would raise it.
- Screen against {{last_quarter_review}}: if a similar KR was missed last quarter, address why this time differs.
- Cap total KRs; state what was deliberately left out.
OUTPUT FORMAT:
1. OKR draft table: objective | key result | baseline | target | confidence.
2. Alignment mapping to company OKRs.
3. Left-out candidates and reasons.
4. Scoring guidance: how each KR is graded at quarter end.
```

### PROMPT-18-15 — Delegation Brief
**Use when:** handing off a task or project with real context, not just a title.
**Output:** a delegation brief with context, definition of done, constraints, and check-in plan.
**Prompt:**
```text
You are a lead writing a delegation brief.
CONTEXT: Task/project: {{task_description}}. Delegate: {{delegate_background}}. Why this person: {{why_them}}. Stakes and deadline: {{stakes_and_deadline}}. Non-negotiables: {{constraints}}.
TASK: Write the brief so the delegate can succeed with minimal re-asking.
CONSTRAINTS**
- Include: why this matters (one paragraph), what "done" looks like (observable, checkable), constraints that cannot be violated, decision rights (what they may decide vs must escalate), and resources (people, docs, access).
- Surface the top 3 ways this could go wrong and the early-warning sign of each, so check-ins are signal-based.
- Define check-in cadence by risk, not politeness: state the trigger-based check-ins instead of or in addition to scheduled ones.
- Write the escalation clause: what conditions justify interrupting you, so neither side guesses.
OUTPUT FORMAT:
1. Brief (max one page) with the sections above.
2. Definition-of-done checklist.
3. Risk/early-warning table.
4. Check-in and escalation protocol.
```

### PROMPT-18-16 — Meeting Notes to Actions
**Use when:** converting raw meeting notes into owned action items.
**Output:** cleaned decisions list, action table, and open-loop tracker.
**Prompt:**
```text
You are an operations lead processing meeting notes.
CONTEXT: Raw notes: {{meeting_notes}}. Meeting purpose: {{meeting_purpose}}. Attendees and roles: {{attendees}}. Follow-up expectations: {{followup_expectations}}.
TASK: Extract decisions, action items, and open loops into a tracker-ready format.
CONSTRAINTS**
- Every action item has: owner (a named person only; "the team" is invalid), deliverable, due date; any item missing one of these goes to "needs clarification" with the exact question.
- Decisions are separated from discussion: a decision records what was decided, by whom, and what options were rejected.
- Open loops (raised but unresolved) are tracked with a named next step and the meeting where they will be revisited.
- Flag any apparent contradiction between decisions in the notes rather than silently resolving it.
OUTPUT FORMAT:
1. Decisions list (with rejected alternatives where recorded).
2. Action table: item | owner | deliverable | due date.
3. Needs-clarification list with questions.
4. Open loops with revisit dates.
5. Suggested distribution message (3 lines).
```

### PROMPT-18-17 — Team-API Document
**Use when:** documenting how your team works so others can interact with you reliably.
**Output:** a team-API doc: interfaces, SLAs, and working agreements.
**Prompt:**
```text
You are a team lead writing your team's API document — how other teams interact with you.
CONTEXT: Team: {{team_purpose}}. Consumers (teams that depend on you): {{consuming_teams}}. Pain points reported: {{reported_frictions}}. Your constraints: {{team_constraints}}.
TASK: Draft the team-API doc.
CONSTRAINTS:**
- Sections: what we own, how to request work (intake format, required info), response SLAs by request type, escalation path, what we do NOT do, and our current capacity picture.
- Every SLA must be one the team can actually meet; if {{team_constraints}} make a requested SLA impossible, state the real SLA and the path to improve it.
- Address {{reported_frictions}} explicitly: which are fixed by the doc, which need behavior change, and which are unresolved trade-offs.
- Include a "how to give us feedback" interface and how the doc itself is versioned and kept honest.
OUTPUT FORMAT:
1. Full team-API doc draft.
2. SLA table by request type.
3. Friction-to-resolution mapping.
4. Review cadence and owner for the doc.
```

### PROMPT-18-18 — Cross-Team Dependency Mapper
**Use when:** mapping dependencies across teams for planning or unblocking.
**Output:** dependency map with critical path, risk flags, and negotiation plan.
**Prompt:**
```text
You are a program engineer mapping cross-team dependencies.
CONTEXT: Initiative: {{initiative}}. Teams and their deliverables: {{teams_and_deliverables}}. Known commitments: {{known_commitments}}. Historical reliability of each team: {{reliability_history}}.
TASK: Produce the dependency map and a plan to de-risk it.
CONSTRAINTS**
- Build the graph: deliverable -> depends-on -> deliverable, with required-by dates; identify the critical path and show it explicitly.
- Classify each dependency: committed (date agreed), assumed (one side does not know yet), or soft (nice-to-have); flag assumed dependencies as the top negotiation targets.
- For each high-risk edge, propose a de-risking action: contract-first, mock/stub interface, sequencing swap, or scope cut — choose one and justify.
- Where {{reliability_history}} shows a pattern, address it with a mechanism (checkpoint cadence, early integration), not hope.
OUTPUT FORMAT:
1. Dependency table and ASCII critical-path diagram.
2. Commitment classification table.
3. Risk register with de-risking actions and owners.
4. Negotiation talking points per flagged dependency.
```

### PROMPT-18-19 — Burnout-Risk Process Review
**Use when:** reviewing team process signals for overload risk, without diagnosing individuals.
**Output:** a process-level risk assessment with workload-balancing levers.
**Prompt:**
```text
You are an engineering manager auditing process for burnout risk.
CONTEXT: Team: {{team_context}}. Signals observed (overtime, PTO patterns, review load, on-call strain, velocity swings): {{signals}}. Workload sources: {{workload_sources}}. What has already been tried: {{previous_interventions}}.
TASK: Analyze burnout risk at the process level and propose structural levers.
CONSTRAINTS:**
- Analyze systems, not people: frame every finding as a workload/flow property (e.g., review latency, WIP limits, interrupt rate), never as personal failing or clinical judgment; you are not diagnosing anyone.
- Distinguish acute overload (specific deadline) from chronic structural overload (standing demand exceeds capacity); levers differ, and the plan must separate them.
- Every lever is structural: scope cuts, WIP limits, on-call redesign, meeting/load budgets, escalation triggers; do not propose resilience coaching as the fix for a structural problem.
- Include measurement: which signals to track and at what threshold you act; label thresholds as proposed (ESTIMATE) to calibrate with the team.
OUTPUT FORMAT:
1. Signal interpretation: acute vs chronic, with evidence.
2. Root-cause process analysis.
3. Structural levers with expected effect and cost.
4. Monitoring plan and intervention triggers.
5. What NOT to do (anti-patterns like hero-culture rewards).
```

### PROMPT-18-20 — Onboarding-Buddy Checklist
**Use when:** structuring a buddy/mentor program for a new hire.
**Output:** a 30-60-90 day buddy checklist with ownership split.
**Prompt:**
```text
You are designing an onboarding-buddy program.
CONTEXT: New hire: {{new_hire_role_and_background}}. Team: {{team_context}}. Buddy: {{buddy_context}}. Systems to learn: {{systems_to_learn}}. First deliverable expected: {{first_deliverable}}.
TASK: Produce the buddy checklist and operating rules.
CONSTRAINTS**
- Split ownership explicitly: what the buddy does, what the manager does, what the new hire drives; no orphan responsibilities.
- Sequence 30-60-90 days from safest to riskiest production access; each access grant has a verification task attached.
- Include social onboarding: intros, pairing rotations, and feedback loops (week-1 and week-4 structured check-ins with questions).
- Define the buddy's escalation duty: what signs (struggle, silence, overload) trigger looping in the manager.
- Build in off-ramp: buddy involvement decreases by design at day 60-90 to avoid dependency.
OUTPUT FORMAT:
1. 30-60-90 checklist table: item | owner | verification.
2. Access-gating sequence.
3. Check-in scripts (week 1 and week 4).
4. Buddy escalation triggers and off-ramp plan.
```
