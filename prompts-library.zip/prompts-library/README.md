# Prompts Library — 400 Curated Prompts for Application Development

A curated collection of **400 production-grade, model-agnostic AI prompts** covering the full application development lifecycle — from product discovery to deployment and operations. Every prompt is original work, optimized with current best practices: role–context–task–constraints–output-format structure, plan-first gates for coding work, named verification steps, explicit "do not" boundaries, and FACT vs ESTIMATE labeling to stop hallucinated answers.

## How to use

1. Open the category folder for your task.
2. Copy the prompt text (inside the fenced block).
3. Replace every `{{placeholder}}` with your real context — never send a prompt with unfilled placeholders.
4. For coding prompts: they will ask for a plan and wait for your OK before editing anything. Approve, correct, or narrow the plan.

## Design principles baked into every prompt

- **Plan first, act second** — coding prompts read the relevant files, propose a plan, and wait for approval.
- **Verification is named** — each prompt specifies the exact command or check that proves the result, and iterates until it passes.
- **No invented APIs** — anything not verified against code/docs is flagged `UNVERIFIED` rather than asserted.
- **Honest estimates** — numbers are labeled FACT, MEASURED, ESTIMATE, or JUDGMENT.
- **Exact output shape** — tables, checklists, diffs, JSON schemas, Gherkin, or Mermaid; never "something good".
- **Safe autonomy** — destructive or shared-state actions require explicit confirmation.

## The 20 categories (20 prompts each)

| # | Category | Covers |
|---|---|---|
| 01 | product-requirements | PRDs, user stories, JTBD, acceptance criteria, MVP scoping, prioritization, spec review |
| 02 | ux-ui-design | Heuristics, design tokens, state trios, WCAG 2.2 AA, motion specs, landing critique |
| 03 | frontend-web | Components, Web Vitals, hydration bugs, race conditions, virtualization, migrations |
| 04 | mobile-development | Screens, navigation, offline sync, store review, TTI, biometrics, deep links |
| 05 | api-design | REST review, RFC 7807 errors, idempotency, webhooks, OAuth2, contract tests |
| 06 | databases | Schema review, migrations, indexing, N+1, transactions, retention, seed data |
| 07 | architecture | System design, ADRs, event-driven, FMEA, capacity, tech selection, diagrams |
| 08 | testing-qa | TDD, integration/E2E plans, flaky tests, mutation testing, contract tests, smoke suites |
| 09 | security | Threat models, authn/authz, OWASP review, secrets, supply chain, incident runbooks |
| 10 | performance | Profiling, caching, latency budgets, memory leaks, benchmarks, perf CI gates |
| 11 | devops-ci-cd | Pipelines, Docker/K8s/IaC review, SLO alerting, rollouts, rollback, runbooks |
| 12 | debugging-troubleshooting | RCA, repro scripts, bisect, races, production debugging, hypothesis logs |
| 13 | code-review-refactoring | PR review, splitting large PRs, behavior-preserving refactors, smells, commit plans |
| 14 | documentation | READMEs, runbooks, ADRs, tutorials, changelogs, doc-drift audits, Mermaid diagrams |
| 15 | prompt-engineering-ai-features | System prompts, RAG, eval harnesses, structured output, guardrails, cost budgets |
| 16 | data-engineering | ETL/ELT, dimensional models, data quality, orchestration, CDC, backfills, lineage |
| 17 | analytics-growth | Event taxonomy, funnels, A/B design, metrics trees, retention, pricing experiments |
| 18 | team-process | Sprints, retros, RFCs, tech-debt prioritization, hiring rubrics, 1:1s, postmortems |
| 19 | ai-coding-workflows | Agent session bootstrap, verify loops, TDD driver, context budgeting, handoffs |
| 20 | fullstack-blueprints | 20 end-to-end app build prompts: SaaS starter, chat, CLI, extension, e-commerce, more |

## File layout

```
prompts-library/
  README.md          ← you are here
  INDEX.md           ← searchable index of all 400 prompt titles
  01-product-requirements/PROMPTS.md
  ...
  20-fullstack-blueprints/PROMPTS.md
```

Each category file opens with a short intro and its placeholder convention. Prompt IDs (`PROMPT-XX-NN`) are stable — reference them in docs and code reviews.

## License

MIT (same as the compass-ai-coach repository).
