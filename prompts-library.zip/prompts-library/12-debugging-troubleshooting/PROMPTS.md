# Debugging & Troubleshooting Prompts (PROMPT-12-01 … PROMPT-12-20)

Covers evidence-driven root-cause analysis, reproduction scripts, log/metric/heap triage, bisection, environment diffs, production-safe debugging, and post-fix regression guards.
Placeholder convention: `{{double_braces}}` mark user-supplied inputs (logs, stack traces, bug reports, environment details); paste the raw artifacts verbatim into the placeholder.

### PROMPT-12-01 — Evidence-First Root-Cause Analysis (5-Whys)
**Use when:** a bug or incident needs a defensible root cause, not a guess.
**Output:** a causal chain with evidence per link, alternative hypotheses ranked, and verification plan.
**Prompt:**
```text
You are a debugging lead applying 5-Whys with evidence discipline. Context: problem statement {{problem_statement}}, observed behavior {{observed_behavior}}, evidence artifacts below (logs, metrics, code snippets, deploy history).
{{evidence_artifacts}}
Task: build the causal chain: (1) restate the problem as a falsifiable observation; (2) for each "why" link, attach the specific evidence supporting it — quotes from artifacts with source; (3) stop when the chain reaches a controllable cause, and state what change would break the chain; (4) list alternative explanations for each link and why evidence favors or disfavors them; (5) define the cheapest test that would confirm the root cause.
Constraints:
- Never present inference as evidence: label each claim "evidence-backed" or "hypothesis".
- If a why-link has no supporting evidence, mark it as an assumption and design the observation or experiment to close the gap.
- Prefer the simplest chain that explains all observations (Occam), but state what observation would force a more complex one.
- If evidence is insufficient to reach a root cause, say so and deliver the ranked hypotheses with the next data to collect.
Do not jump to fixes before the causal chain is complete; do not blame a component without direct evidence touching it.
Output format: causal chain (link → evidence → confidence), alternative hypotheses table, confirmation experiment, and candidate fixes ranked by chain-break certainty.
```

### PROMPT-12-02 — Reproduction Script Writer
**Use when:** turning a vague bug report into an automated, minimal reproducer.
**Output:** a standalone reproduction script plus the minimized failing case.
**Prompt:**
```text
You are a test engineer specializing in reproduction. Context: bug report below, codebase at {{repo_context}}, how to run things {{run_instructions}}.
{{bug_report}}
Task: write a reproduction script: (1) extract concrete facts from the report (version, environment, inputs, expected vs actual) — list anything missing as questions-to-owner, not guesses; (2) write the smallest script that triggers the failure deterministically, using only documented APIs of the project; (3) structure it so it exits 0 on pass, 1 on failure, with clear printed diagnostics; (4) minimize: strip unrelated state, reduce inputs to the smallest trigger; (5) note what about the original report could not be encoded and why.
Constraints:
- The script must run against {{run_instructions}} without undeclared setup; every dependency it needs must be stated.
- If the report lacks facts needed to reproduce, write the script with clearly marked TODO placeholders and state what input would fill each.
- Do not "fix" the bug in the script — the script's job is to fail.
- If the failure is intermittent, add a bounded retry loop and report the failure rate.
Do not use mocks that bypass the code path under suspicion; reproduction must exercise the real path.
Output format: the reproduction script in a single code block, a facts-vs-unknowns table from the report, and run instructions.
```

### PROMPT-12-03 — Log Triage & Pattern Extraction
**Use when:** drowning in logs and needing to find the signal before an error.
**Output:** a triage report with the error timeline, correlated services, and next queries.
**Prompt:**
```text
You are an SRE triaging logs. Context: service {{service_name}}, timeframe {{timeframe}}, log sample below (raw lines), known-good baseline behavior {{baseline_notes}}.
{{log_sample}}
Task: triage the logs: (1) identify the earliest anomalous line — the first deviation from expected patterns, with the exact line quoted; (2) reconstruct the error timeline: what happened, in order, across lines/services present; (3) extract the distinguishing signature of the failure (error codes, correlation IDs, stack frames) suitable for a log query; (4) correlate entries by trace/request ID where present; (5) distinguish root-cause lines from cascading downstream errors.
Constraints:
- Quote exact log lines as evidence for every claim; never paraphrase a log line in the evidence position.
- If timestamps/timezones are ambiguous, state the assumption used to order events.
- Cascading errors must be labeled as such; do not present a symptom service as the origin without evidence.
- If the sample is too small to conclude, say what additional timeframe or service logs are needed.
Do not invent log lines not present in the sample; do not assume causes — distinguish "the log shows" from "the log suggests".
Output format: anomaly summary, ordered timeline with quoted evidence, query signature (with example grep/LogQL), and data-gaps list.
```

### PROMPT-12-04 — Git Bisect Assistant
**Use when:** finding the commit that introduced a regression.
**Output:** a bisect plan/run with the culprit commit, evidence, and summary for the author.
**Prompt:**
```text
You are guiding a git bisect. Context: repository {{repo_description}}, bad commit/branch {{bad_ref}}, last known good {{good_ref}}, how to test {{test_command}}, observed regression {{regression_description}}.
Task: (1) verify the test command fails on {{bad_ref}} and passes on {{good_ref}} — if that precondition is not established, stop and say how to establish it; (2) produce the exact bisect command sequence, preferring `git bisect run` with the test command; (3) at each step, state what you would check if the test is flaky (re-run policy, e.g., 3 consecutive results); (4) when bisect completes, examine the culprit commit: summarize what it changed and why it plausibly causes the regression, with the specific diff lines as evidence; (5) if the culprit is a merge commit, identify which parent side introduced it.
Constraints:
- Use only documented git flags; where a flag's behavior is version-dependent, note it.
- Handle the flaky-test case explicitly: define "pass" as N consecutive passes before declaring good.
- If the regression cannot be expressed as an automated check, design a manual binary question for bisect instead and say what makes it binary.
- Label the culprit-to-cause linkage as inference unless the mechanism is directly visible in the diff.
Do not edit or revert commits during bisect; do not skip commits silently — each skip must be justified (unbuildable, test unavailable).
Output format: bisect command sequence, decision log format to keep during the run, culprit commit analysis with quoted diff evidence, and a handoff note for the commit author.
```

### PROMPT-12-05 — Race-Condition Diagnosis
**Use when:** intermittent failures suggest concurrency bugs.
**Output:** a hypothesis set with the shared-state analysis and an instrumentation plan to confirm.
**Prompt:**
```text
You are a concurrency specialist. Context: failing behavior {{failure_description}}, relevant code below, runtime environment {{runtime}}, concurrency model in use {{threads_async_callbacks}}.
{{code_snippets}}
Task: diagnose the race: (1) inventory shared mutable state touched by the suspicious paths (variables, caches, files, external stores); (2) enumerate interleavings that produce the observed failure — for each, state the exact ordering of operations across threads/tasks; (3) map each hypothesis to evidence: does code inspection support the required interleaving?; (4) propose confirmation instrumentation: targeted logging (with ordering-safe output), stress tests, or runtime detectors appropriate to the language (race detector, thread sanitizer, deterministic replay); (5) sketch the minimal fix pattern (locking scope, atomic operation, queue handoff, immutability) per hypothesis without writing full code yet.
Constraints:
- Distinguish data races from higher-level races (lost updates, check-then-act, stale reads); name the precise category.
- Every claimed interleaving must be possible in the shown code — if it requires code not shown, mark it "needs more context".
- Instrumentation must not change timing enough to hide the bug; discuss observer-effect risk.
- Language-specific tool names must match the stated runtime; flag any you cannot confirm exists as "verify in docs".
Do not recommend fixing by adding sleeps or retries; those mask races and are forbidden as solutions here.
Output format: shared-state inventory, ranked interleaving hypotheses with evidence, instrumentation plan, and fix-pattern sketch per hypothesis.
```

### PROMPT-12-06 — Memory Leak / Heap Triage
**Use when:** a process grows unbounded or OOMs and heap data is available.
**Output:** a triage report identifying leak candidates, retention paths, and next profiling steps.
**Prompt:**
```text
You are a performance engineer triaging memory. Context: runtime {{language_runtime}}, symptom {{memory_symptom}}, heap profiles or dumps below/summarized {{heap_artifacts}}, workload during capture {{workload_description}}.
{{heap_artifacts}}
Task: triage the memory data: (1) classify the growth pattern — unbounded accumulation vs plateau-at-wrong-level vs fragmentation — with evidence from the data; (2) rank the top retained object types with their retention paths (what holds them, and what root holds that); (3) for each candidate leak, state the suspected code path and what evidence ties the retained objects to it; (4) distinguish true leaks (unreachable-by-design objects held accidentally) from caches/growth that may be legitimate; (5) recommend the confirming next step: second capture after GC/idle period, allocation profiling, or targeted reproduction.
Constraints:
- Report sizes as percentages and absolute units where the data provides them; never fabricate numbers.
- If the dump format is ambiguous (tool version differences), state the assumption.
- Retention analysis must name the actual fields/references from the dump, not generic guesses.
- Recommendations must be safe for production if the system is live (sampling rates, capture cost); flag any capture that adds significant overhead.
Do not recommend "just increase the heap" as a resolution; it may appear only as an interim mitigation clearly labeled as masking.
Output format: growth classification, retained-objects ranking with paths, candidate-leak table with evidence, and next-step profiling plan.
```

### PROMPT-12-07 — Production Debugging Guide (Safe, Read-Only)
**Use when:** debugging live production and every action must be reversible and observable.
**Output:** a read-only debugging sequence with safety gates and escalation triggers.
**Prompt:**
```text
You are an SRE writing a live-debugging procedure. Context: production system {{system_description}}, symptom {{symptom}}, access level {{access_level}}, observability available {{logs_metrics_tracing}}, constraints {{safety_constraints}}.
Task: design a strictly read-only debugging sequence: (1) ordered diagnostic steps — each with exact command/query, expected healthy output, and what deviation indicates; (2) safety classification per step: read-only by inspection vs read-only in practice but rate-limited (queries, traces) — set rate limits; (3) escalation triggers — which observations mean "stop debugging, page owner / consider mitigation"; (4) evidence capture — what to save (timestamps, query outputs) for post-incident analysis; (5) explicit forbidden list for this system based on stated constraints.
Constraints:
- Every step must be reversible-by-construction (no state change possible from the command itself); if a diagnostic could perturb the system (cache warming, query load), quantify and warn.
- Time-box the sequence; if diagnosis exceeds {{debug_budget}}, switch to mitigation mode and say what that means here.
- If access level cannot perform a needed step, mark it and give the request-template to send the owning team.
- Label anything that depends on undocumented system behavior as "verify before running".
Do not include restart, config change, feature-flag flip, data fix, or deploy steps — this prompt is diagnosis only; mitigation is a separate explicit decision.
Output format: numbered diagnostic sequence table (step, command, expected, deviation meaning, safety class), escalation triggers, evidence-capture list, and forbidden-actions list.
```

### PROMPT-12-08 — Flaky-Failure Bisect
**Use when:** a test is flaky and you need to find what makes it non-deterministic.
**Output:** a bisection of flakiness sources with a quarantine plan.
**Prompt:**
```text
You are a test-stability engineer. Context: flaky test {{test_name_and_code}}, failure modes observed {{failure_modes}}, CI environment {{ci_environment}}, recent changes near the test {{recent_changes}}.
Task: bisect the flakiness: (1) classify the failure mode — ordering dependency, timing assumption, shared state leakage, external dependency, resource contention — with evidence from failure output; (2) for each candidate class, give the discriminating experiment (run order shuffled, clock faked, state isolation checked, dependency stubbed); (3) design a repetition strategy: how many runs establish a flakiness rate with stated confidence, and the exact command; (4) until fixed, define quarantine: mark, track rate, owner, and a deadline policy; (5) propose the fix direction per class without full implementation.
Constraints:
- Never claim "fixed" from a handful of green runs; define the pass-count bar (e.g., 200 consecutive passes) before un-quarantining.
- Experiments must isolate one variable at a time; state what each experiment rules in or out.
- If the flake is environmental (CI resource pressure), say what evidence would show that vs code-level nondeterminism.
- Fix directions must remove the nondeterminism source, not add retries.
Do not delete or weaken the test as a resolution; quarantine is a tracking state, not a fix.
Output format: failure-mode classification with evidence, experiment matrix, repetition plan, quarantine policy, and fix directions ranked.
```

### PROMPT-12-09 — "Works on My Machine" Environment Diff
**Use when:** a failure happens in one environment but not another.
**Output:** a systematic environment-diff report with the ranked cause hypothesis.
**Prompt:**
```text
You are an environment-drift detective. Context: failing environment {{failing_env_description}}, working environment {{working_env_description}}, failure {{failure_description}}.
Environment details:
Failing: {{failing_env_facts}}
Working: {{working_env_facts}}
Task: find the environment difference that explains the failure: (1) enumerate diff dimensions — versions (runtime, deps, OS), configuration (env vars, feature flags, config files), data (datasets, seeds, user state), resources (CPU/memory limits, network), time (clock, timezone), and permissions; (2) for each dimension present in the facts, state same/different/unknown; (3) map the failure mode to the dimensions it could plausibly be sensitive to, and rank hypotheses; (4) define the discriminating check per top hypothesis (a command or config value to compare); (5) recommend the durable fix — version pinning, config validation at startup, containerized dev, or explicit requirement documentation.
Constraints:
- Only compare dimensions for which facts were provided; list unknown dimensions explicitly instead of assuming parity.
- Each hypothesis must connect to the failure mechanism ("version X changed behavior Y"), not just "versions differ".
- Fix recommendations must prevent recurrence class-wide, not just patch the one diff found.
- Where a dimension's facts conflict between sources, flag the conflict.
Do not suggest "rebuild your environment" as a first step; root-cause the difference first.
Output format: dimension diff table, ranked hypotheses with mechanism, discriminating checks, and prevention recommendations.
```

### PROMPT-12-10 — Stack-Trace Decoder for Juniors
**Use when:** a junior dev needs to learn how to read a stack trace.
**Output:** an annotated, educational walkthrough of the trace plus next steps.
**Prompt:**
```text
You are a patient senior engineer teaching debugging. Context: stack trace below, application domain {{app_domain}}, framework {{framework}}.
{{stack_trace}}
Task: decode the trace pedagogically: (1) identify each frame — application code vs framework vs library vs runtime — and explain how you can tell; (2) pinpoint the exception type, message, and the frame where the fault occurred; (3) explain the call path in plain language: who called whom to get there, using the trace order; (4) list the 2–3 most likely causes for this exception in this context, and what evidence in the trace supports each; (5) give concrete next steps: which file/line to open first, what to inspect (inputs, state), and one logging addition that would confirm the cause; (6) teach the pattern: how to recognize this category of failure next time.
Constraints:
- Define jargon on first use (frame, caused by, suppressed, async stack) — assume no prior knowledge.
- If frames are missing (async elision, optimized builds), explain what is missing and how to get complete traces (e.g., flags to enable), naming the exact flag per the stated framework with "verify in docs" where unsure.
- Distinguish what the trace proves from what it suggests.
- Keep the teaching tone; explain reasoning, do not just assert.
Do not dump a generic fix; every recommendation must tie to a specific frame or message in this trace.
Output format: annotated trace walkthrough, likely causes with evidence, ordered next steps, and the reusable recognition pattern.
```

### PROMPT-12-11 — Timeout & Cascade-Failure Analysis
**Use when:** a timeout in one component caused a system-wide failure.
**Output:** a cascade map with the original timeout, amplification analysis, and hardening plan.
**Prompt:**
```text
You are a distributed-systems diagnostician. Context: incident summary {{incident_summary}}, service graph {{service_graph}}, timeout/retry configuration {{timeout_config}}, failure timeline {{failure_timeline}}.
Task: analyze the cascade: (1) build the failure map — which component timed out first, what each downstream did as a result, in order; (2) quantify amplification where data allows: retries × concurrency = load multiplier at each hop (show calculation; label inputs as facts or estimates); (3) identify each missing or wrong protection: timeouts set too high/absent, unbounded retries, missing circuit breakers, missing bulkheads, blocking threads waiting on downstream; (4) state the counterfactual — which single change would have stopped or contained this cascade; (5) produce a hardening checklist ordered by containment value.
Constraints:
- Default stance: retries without backoff+jitter and without a circuit breaker are defects; justify any exception.
- Every amplification calculation must show its inputs; where concurrency data is unavailable, say so and give the formula with placeholders.
- Distinguish the original timeout (root trigger) from downstream timeouts (symptoms) using the timeline.
- Timeout values recommended must be derived from stated latency requirements or SLOs; if none exist, state that the first deliverable is defining them.
Do not recommend removing timeouts; recommend correcting them and adding containment.
Output format: cascade map, amplification calculations, protection-gap list, counterfactual analysis, and prioritized hardening checklist.
```

### PROMPT-12-12 — Data-Corruption Forensics
**Use when:** data is wrong or corrupted and the scope and cause must be established.
**Output:** a forensic report with corruption scope, probable cause, and recovery options.
**Prompt:**
```text
You are a data-integrity investigator. Context: corruption report {{corruption_report}}, data store {{data_store}}, schema {{schema_description}}, recent changes {{recent_change_history}}, backup/replication status {{backup_status}}.
Task: run the forensic analysis: (1) characterize the corruption — pattern (systematic transform, boundary truncation, interleaving, partial writes), scope (which rows/ranges/tables), and onset time if determinable; (2) build the evidence table: each observation, its source (query result, user report, checksum), and what it rules in or out; (3) rank probable causes consistent with the pattern — bad deploy, race in writer, encoding bug, manual edit, replication issue, hardware — and state the evidence for each; (4) scope assessment queries: exact safe read-only queries to establish blast radius (counts, affected ranges, integrity checks); (5) recovery options with tradeoffs: point-in-time restore (data-loss window), surgical repair, regeneration, accepting loss — with decision criteria.
Constraints:
- All assessment queries must be read-only and safe on production; state their cost profile.
- Onset time is only claimed when evidence supports it; otherwise give the bound ("between last known good X and first observed bad Y").
- Recovery recommendations must state what data is lost in each option; never claim a lossless path without evidence.
- If backups are unverified, the first action is restore-verification, before any repair decision.
Do not run or recommend any write/repair query in this analysis; repair is a separate approved step.
Output format: corruption characterization, evidence table, ranked causes, blast-radius queries, and recovery decision matrix.
```

### PROMPT-12-13 — Intermittent Network-Issue Checklist
**Use when:** sporadic connectivity failures resist reproduction.
**Output:** a layered diagnostic checklist with capture strategy and decision points.
**Prompt:**
```text
You are a network diagnostician. Context: symptom {{network_symptom}}, endpoints involved {{endpoints}}, infrastructure path {{network_path}}, frequency {{frequency_pattern}}, prior checks {{already_tried}}.
Task: build a layered network triage: (1) checklist ordered by layer — DNS resolution, TCP connect, TLS handshake, HTTP/application, with one discriminating test per layer that isolates it from the ones below; (2) timing analysis: for intermittent issues, define what to record per occurrence (timestamps, resolved IPs, error types, durations) so patterns can be extracted; (3) capture strategy: the least-invasive capture that will catch the event (verbose client logging, tcpdump window, synthetic probes) with storage/rotation notes; (4) correlation angles: time-of-day, specific nodes/IPs, deploy windows, certificate expiry, MTU/MSS mismatches, connection reuse (keep-alive exhaustion); (5) decision points: which outcomes shift the investigation to a different layer or team.
Constraints:
- Each test must be copy-paste runnable and state its expected output for healthy behavior.
- Never propose captures on third-party networks you do not control — state what the third party must provide instead.
- If the error type (timeout vs reset vs refused vs DNS failure) is not yet known, that is the first discriminator to instrument.
- Distinguish application-layer causes (connection pool exhaustion looks like network failure) with the specific check that separates them.
Do not recommend blanket MTU changes or firewall relaxations without the discriminating evidence.
Output format: layered checklist, per-occurrence record template, capture plan, correlation angles, and decision-point table.
```

### PROMPT-12-14 — Regression-Window Finder
**Use when:** behavior regressed but the exact window and trigger are unknown.
**Output:** a narrowed regression window with candidate triggers and confirmation plan.
**Prompt:**
```text
You are a regression investigator. Context: working behavior description {{expected_behavior}}, current broken behavior {{current_behavior}}, deployment/release history {{release_history}}, feature-flag changes {{flag_history}}, data/config changes {{config_history}}.
Task: find the regression window: (1) establish the last-verified-good and first-verified-bad points from the provided history; if none, define the cheapest observation to establish them; (2) map every change event in the window — deploys, flag flips, config changes, data migrations, dependency updates — into a timeline; (3) for each candidate trigger, assess plausibility against the failure mechanism; (4) design confirmation: the flag to flip back, the deploy to revert in staging, the config diff to re-apply — each reversible and evidence-producing; (5) if the window stays wide, specify what bisection (deploy-level, flag-level, code-level) narrows it next.
Constraints:
- Candidate triggers must connect to the failure mechanism; "changed around the same time" is not evidence.
- Every confirmation action must be reversible; state the reversal for each.
- Distinguish trigger (what changed) from precondition (what made the system vulnerable); both belong in the report.
- If history is incomplete, list the missing sources (deploy logs, flag audit trail) rather than guessing.
Do not recommend reverting production as a diagnostic step; confirmation happens in staging or with flags.
Output format: regression window statement, change timeline with plausibility ranking, confirmation experiments with reversals, and bisection plan if needed.
```

### PROMPT-12-15 — Error-Message Improvement (Actionable Diagnostics)
**Use when:** an error message is confusing and needs to be actionable.
**Output:** rewritten error messages following a diagnostic-quality rubric.
**Prompt:**
```text
You are a developer-experience engineer. Context: current error message(s) below, where they surface {{user_context}} (end user, API caller, operator, developer), system {{system_description}}.
{{error_messages}}
Task: rewrite each error message to be actionable: (1) diagnose the failure against a rubric — states what happened, why (root category), what to do next, and where to look; identify which elements are missing; (2) rewrite for each audience level: a safe external-facing message (no internals leakage), an operator-facing message (with diagnostics: IDs, relevant state, doc/runbook links), and a developer-facing message (with the internal context that makes it debuggable); (3) add the stable error code / machine-readable identifier strategy; (4) for each rewrite, list the supporting logging changes needed so the message plus logs fully diagnose.
Constraints:
- External messages must never leak internals (stack frames, SQL, paths, hostnames, other tenants); check each rewrite against this.
- "Why" must be stated at the correct confidence: known cause asserted, suspected cause labeled, unknown cause omitted rather than guessed.
- Every "what to do next" must be something the audience can actually perform.
- If the underlying code cannot know the cause at throw-site, specify what context must be threaded (error wrapping, cause chains) to make the message accurate.
Do not use generic messages ("something went wrong") or blame-the-user phrasing.
Output format: rubric scorecard per message, three-audience rewrites, error-code strategy, and required logging changes.
```

### PROMPT-12-16 — Hypothesis-Log Template (Scientific Debugging)
**Use when:** a long, confusing debugging session needs discipline.
**Output:** a running hypothesis log structure plus worked example entries.
**Prompt:**
```text
You are a debugging coach installing scientific method discipline. Context: problem {{problem_description}}, team {{team_context}}, where the log will live {{log_location}}.
Task: design a hypothesis log system: (1) the entry schema — timestamp, current hypothesis (one sentence, falsifiable), prediction ("if true, we will observe X"), experiment/check performed, result (observed vs predicted), verdict (confirmed/refuted/inconclusive + confidence), next action; (2) rules that keep it honest — one active hypothesis at a time, inconclusive results must change the next experiment not repeat it, every "fix attempt" logged as an experiment with predicted outcome; (3) a worked example with 5–6 realistic entries showing a refutation chain and a confirmation; (4) red-flag detectors — when to step back (N inconclusive experiments, same experiment repeated, hypothesis drift without evidence); (5) how to hand off the log to another engineer mid-investigation.
Constraints:
- The schema must be lightweight enough to maintain under incident pressure; total per-entry effort under two minutes.
- Verdicts must map to concrete next states (pursue / abandon / gather-data), not just labels.
- The worked example must show at least one refuted hypothesis — demonstrate that refutation is progress.
- If the team already keeps an incident doc, define how the hypothesis log differs and links to it.
Do not turn the log into a narrative diary; enforce the schema with examples of both good and bad entries.
Output format: entry schema (as a fill-in template), operating rules, worked example, red-flag detectors, and handoff procedure.
```

### PROMPT-12-17 — Performance-Regression Bisect
**Use when:** something got slower and you need to find which change and why.
**Output:** a measurement plan, bisection strategy, and per-change impact attribution.
**Prompt:**
```text
You are a performance engineer. Context: regression description {{slowdown_description}}, benchmark available {{benchmark_or_none}}, change history {{change_history}}, environment {{bench_environment}}.
Task: hunt the performance regression: (1) measurement foundation — define the benchmark (workload, warmup, iterations, statistics: median + p95, variance threshold), or critique the provided one; (2) establish the magnitude: current vs baseline numbers with the benchmark run as evidence; label all numbers as measurements or estimates; (3) bisection strategy — change-level bisect with the benchmark as the oracle (and a repetition count for noisy benchmarks); (4) for each suspect change, the mechanism hypothesis (algorithmic, allocation, I/O pattern, config) and the micro-benchmark or profile that would confirm it; (5) guard against environment noise: what to control or co-measure (machine load, thermals, neighbor noise, clock behavior).
Constraints:
- No attribution without measurement: a change is only "the cause" when the benchmark flips when it is applied/reverted in isolation.
- Define the noise floor first (variance of the benchmark on unchanged code); claims below the noise floor are inconclusive.
- If no benchmark exists, the deliverable is building one before any bisection.
- Profiler/tool recommendations must fit the stated language/runtime; unverifiable tool flags marked "verify in docs".
Do not accept wall-clock impressions ("feels slower") as evidence; convert them into measurements first.
Output format: benchmark definition, measurement results table, bisection plan, suspect-analysis table, and noise-control checklist.
```

### PROMPT-12-18 — Crash-Loop Back-Off Diagnosis
**Use when:** a container or service is crash-looping and restarts hide the evidence.
**Output:** an evidence-preservation plan and crash-cause diagnosis workflow.
**Prompt:**
```text
You are a production engineer. Context: crash-looping workload {{workload_description}}, platform {{orchestrator}}, current state {{current_state}}, logs available {{log_availability}}.
Task: diagnose the crash loop: (1) evidence preservation first — how to capture state before the next restart kills it (previous container logs, core dumps, state snapshots, debug containers/sidecars), with exact commands per the stated orchestrator; (2) classify the crash pattern from available evidence — startup failure (never ready), OOM kill (exit 137 / OOMKilled events), liveness-probe flapping, panic-on-startup, dependency-unavailable retry loop — with the discriminating signal per class; (3) back-off dynamics — how the restart back-off obscures logs and timing, and how to reconstruct the true timeline; (4) safe mitigation ladder — increase backoff observation window, run one-off debug instance, attach debugger/trace — each with blast radius; (5) distinguish fixable-by-config crashes from code bugs and state the handoff for each.
Constraints:
- All capture commands must be read-only or non-disruptive; state any that briefly add load.
- If logs are unavailable because the process dies before logging, specify the earliest reliable instrumentation point (e.g., entrypoint wrapper logging to a file outside the container).
- OOM classification requires memory evidence (events, limits vs usage), not just exit codes.
- Mitigations must not mask the crash (no infinite-restart-without-observation); every mitigation must increase diagnosability.
Do not recommend simply removing liveness probes or raising memory limits without evidence of the root cause.
Output format: evidence-capture commands, crash-class decision tree with signals, timeline reconstruction method, mitigation ladder, and fix-vs-handoff classification.
```

### PROMPT-12-19 — Third-Party Outage Assessment
**Use when:** an external dependency may be down and you must decide your response.
**Output:** an assessment with confidence levels, impact analysis, and decision-ready options.
**Prompt:**
```text
You are an incident analyst. Context: suspected dependency {{dependency_description}}, symptoms observed {{symptoms}}, dependency status sources {{status_page_or_none}}, your system's dependency posture {{integration_details}}.
Task: assess the third-party outage: (1) confirm vs rule out — discriminating checks that isolate the dependency from your own stack (direct probe, status page, community reports, error signature specificity), each with what a positive/negative result means; (2) confidence ladder — confirmed / probable / possible / unlikely, with the evidence needed to move up; (3) impact analysis — which of your functions degrade vs fail, blast radius from the integration details; (4) options with tradeoffs: fail gracefully/degrade, cached/stale-data mode, queue-and-retry, circuit-break, failover to alternate provider — feasibility per integration facts; (5) communication: internal status note and external user message templates; (6) what to log/measure during the window for post-incident review.
Constraints:
- No claim of third-party fault until at least two independent signals agree; state the signals used.
- Every degraded mode must state its data-consistency and UX consequences.
- Retry amplification rules apply: any retry traffic during their outage must be bounded; specify bounds.
- If a status page exists, cite what it said and when — do not rely on memory of it.
Do not recommend switching providers mid-incident as an improvised action; only pre-built failover may be activated.
Output format: confirmation checks, confidence assessment, impact map, options table with tradeoffs, comms templates, and observability capture list.
```

### PROMPT-12-20 — Post-Fix Regression Guard Writer
**Use when:** a bug is fixed and a guard is needed so it cannot silently return.
**Output:** a targeted regression test (or monitoring guard) with rationale and coverage notes.
**Prompt:**
```text
You are a quality engineer. Context: the bug {{bug_description}}, the fix {{fix_description_or_diff}}, test framework {{test_framework}}, why existing tests missed it {{coverage_gap_analysis}}.
Task: write the regression guard: (1) a test that fails on the pre-fix code and passes on the fixed code — describe how you would verify both directions, and write the test to target the invariant the fix establishes, not the fix's implementation details; (2) place it at the right level (unit/integration/E2E) with justification, mirroring how the bug manifested; (3) cover the boundary conditions adjacent to the fix (off-by-one, empty input, concurrency window, error path) as additional cases; (4) if the bug is non-deterministic or environment-dependent and cannot be unit-tested, design the alternative guard: invariant assertion, synthetic probe, or alert; (5) document in the test why it exists — a comment linking the failure mode.
Constraints:
- The test must fail for the right reason on old code, not incidentally; state how you verified mutation-sensitivity.
- Do not overfit to the exact reported input when the invariant is broader; generalize the test to the class.
- Where timing/concurrency is involved, keep the test deterministic; if that is impossible, use the non-test guard path and justify.
- All framework APIs used must exist in {{test_framework}} — flag uncertain APIs as "verify in docs".
Do not add the guard silently to an unrelated test file; give it a clear identity and name referencing the bug.
Output format: the guard test code, mutation-direction verification steps, adjacent boundary cases, placement rationale, and (if applicable) the non-test guard design.
```
