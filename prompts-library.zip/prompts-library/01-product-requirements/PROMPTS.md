# 01 — Product Requirements

Prompts for turning ideas, evidence, and stakeholder input into precise, testable product artifacts: PRDs, user stories, acceptance criteria, roadmaps, and scope controls.
Replace every `{{placeholder}}` with your own project detail before running; leave a placeholder empty only if the prompt says it is optional.

### PROMPT-01-01 — PRD Generator
**Use when:** you have a feature idea and need a complete product requirements document.
**Output:** a structured PRD in markdown.
**Prompt:**
```text
You are a senior product manager writing a production-grade PRD.
CONTEXT: Product: {{product_name}}. Audience: {{target_users}}. Feature: {{feature_description}}. Business goal: {{goal}}. Constraints: {{constraints}}.
TASK: Write a full PRD with these sections: Problem Statement, Goals/Non-Goals, User Stories (with acceptance criteria), Functional Requirements (numbered FR-1…), Non-Functional Requirements, Out of Scope, Open Questions, Success Metrics, Rollout Plan.
RULES: Label every metric target as ESTIMATE or MEASURED. Where information is missing, write "insufficient information" in Open Questions instead of guessing. Do not invent user research; cite only what is in CONTEXT.
Do not add dependencies, integrations, or scope not implied by CONTEXT.
OUTPUT: markdown with the exact section headers above, no preamble.
```

### PROMPT-01-02 — User Story Breakdown (INVEST)
**Use when:** an epic needs to be split into sprint-ready user stories.
**Output:** a numbered story list with INVEST validation.
**Prompt:**
```text
You are an agile coach decomposing an epic into INVEST-compliant stories.
CONTEXT: Epic: {{epic_description}}. Team velocity: {{velocity}} points/sprint. Technical context: {{stack_or_architecture_notes}}.
TASK: Break the epic into 5-12 user stories, each with: title, "As a … I want … so that …", acceptance criteria (3-6 bullets), story-point estimate (1/2/3/5/8) labeled ESTIMATE, and dependencies.
RULES: Every story must independently pass INVEST: Independent, Negotiable, Valuable, Estimable, Small, Testable — append a one-line INVEST check to each. Stories larger than 8 points must be split further.
Do not create technical-only stories with no user value. Do not guess domain rules not present in CONTEXT; list them as assumptions.
OUTPUT: markdown, one `####` section per story, ending with a dependency-ordered sprint suggestion table.
```

### PROMPT-01-03 — JTBD Interview Synthesis
**Use when:** you have raw user interview transcripts to synthesize into Jobs-to-be-Done.
**Output:** JTBD statements with evidence quotes.
**Prompt:**
```text
You are a researcher synthesizing interviews using the Jobs-to-be-Done framework.
CONTEXT: Product area: {{product_area}}. Interview transcripts: {{paste_transcripts_or_file_paths}}.
TASK: For each distinct job, produce: JTBD statement ("When [situation], I want to [motivation], so I can [outcome]"), the functional/emotional/social dimensions, current solutions used, and pains with the status quo.
RULES: Quote the transcript verbatim (short quotes) as evidence for every claim; if a job has no supporting quote, mark it UNVERIFIED HYPOTHESIS. Distinguish what users did from what they say they want.
Do not generalize from a single interview; note sample size per job. Do not recommend features; report jobs only.
OUTPUT: markdown table: Job Statement | Evidence Quotes | Frequency | Confidence (High/Med/Low), followed by a themes summary.
```

### PROMPT-01-04 — Acceptance Criteria Writer (Gherkin)
**Use when:** a user story exists but needs testable Gherkin acceptance criteria.
**Output:** Gherkin scenarios in a feature file.
**Prompt:**
```text
You are a BDD practitioner writing Gherkin scenarios for a user story.
CONTEXT: Story: {{user_story}}. Business rules: {{business_rules}}. Actors/roles: {{roles}}. System boundaries: {{what_is_out_of_scope}}.
TASK: Write a Gherkin feature file: a Feature description, Background block for shared preconditions, and 6-12 Scenarios covering the happy path, each business rule, and edge cases (empty input, permissions, limits, failures).
RULES: Each scenario must have exactly one When (action) and at least one Then (observable outcome). Steps must be implementation-agnostic (no CSS selectors, no API internals). If a rule is ambiguous, write two scenario variants and flag the ambiguity instead of choosing silently.
Do not invent rules not stated in CONTEXT; list unknowns as `@pending` scenarios.
OUTPUT: a single ```gherkin code block, nothing else.
```

### PROMPT-01-05 — MVP Scope Cutter
**Use when:** a feature set is too big and must be cut to a shippable MVP.
**Output:** a cut list with rationale and a keep-list.
**Prompt:**
```text
You are a ruthless scope editor preparing an MVP cut.
CONTEXT: Product: {{product_name}}. Full desired feature list: {{feature_list}}. Launch constraint: {{time_or_budget_limit}}. Core user promise: {{core_value_proposition}}.
TASK: Classify every feature as MUST (core promise fails without it), SHOULD (valuable, first fast-follow), or CUT (defer). For each CUT, give the one-sentence rationale and the smallest manual workaround users could tolerate temporarily.
RULES: The MUST set must be shippable within {{time_or_budget_limit}} — if it is not, cut harder and say so explicitly. Challenge every MUST: "what breaks if this ships 4 weeks later?"
Do not mark anything MUST solely because it is easy to build. Do not add new features during cutting.
OUTPUT: markdown — three sections (MUST/SHOULD/CUT) as tables: Feature | Rationale | Risk of cutting, then a 5-line launch-risk paragraph.
```

### PROMPT-01-06 — Feature Spec from Vague Idea
**Use when:** a stakeholder gives a one-line idea and you must turn it into a spec.
**Output:** a clarifying-question-first feature spec.
**Prompt:**
```text
You are a product manager converting a vague idea into a spec, and you refuse to guess.
CONTEXT: Raw idea: {{one_line_idea}}. Stakeholder: {{who_asked}}. Product: {{product_context}}.
TASK: Step 1: Ask exactly 8-12 clarifying questions grouped as User, Problem, Behavior, Constraints, Success. Wait for answers before proceeding. Step 2 (after answers): produce a feature spec with Problem, Proposed Behavior (happy path + top 5 edge cases), Non-Goals, Open Questions, and a recommendation (build / don't build / needs spike).
RULES: Never fill gaps with assumptions — each unanswered question stays in Open Questions. Label every effort guess as ESTIMATE.
Do not expand scope beyond the answered questions. Do not write marketing copy.
OUTPUT: Step 1 as a numbered question list; Step 2 in markdown with the exact headers above.
```

### PROMPT-01-07 — Competitive Teardown
**Use when:** you need a structured comparison of competitors before building.
**Output:** a comparison matrix with differentiation opportunities.
**Prompt:**
```text
You are a competitive analyst producing a teardown for product decision-making.
CONTEXT: Our product: {{our_product}}. Competitors: {{competitor_list}}. Comparison dimensions: {{dimensions_or_default_core_workflows_pricing_onboarding}}. Date of analysis: {{date}}.
TASK: Build a teardown across: core workflows, pricing model, onboarding friction, target segment, stated differentiators, and weaknesses visible from public sources.
RULES: Every cell must cite its source (URL, review site, docs page) or be labeled INFERENCE. Distinguish facts (verified this month) from claims (vendor-stated). If you cannot verify a cell, write "not verified".
Do not recommend copying features without a fit argument. Do not use knowledge older than {{date}} without flagging it as possibly stale.
OUTPUT: markdown comparison table per competitor, then a "white space" section with 3-5 opportunities ranked by our advantage.
```

### PROMPT-01-08 — User Interview Question Designer
**Use when:** planning a generative (not sales-y) user interview.
**Output:** an interview script with probes.
**Prompt:**
```text
You are a user researcher writing a generative interview script.
CONTEXT: Research goal: {{what_decision_this_informs}}. Participant segment: {{participant_profile}}. Product area: {{product_area}}. Known context: {{what_we_already_know}}.
TASK: Write a 30-45 minute script: warm-up (3 questions), current-behavior walkthrough (5-7 questions), past-incident reconstruction (2-3 questions), closing (2 questions). Add 2-3 follow-up probes per key question.
RULES: All questions must be open, past-behavior-focused, and non-leading — rewrite any question that contains the product idea, a solution hint, or "would you use". Include one "show me how you do it today" task if the behavior is digital.
Do not ask about hypothetical future usage. Do not ask participants to rank feature lists.
OUTPUT: markdown script with timings, questions in numbered lists, probes indented as sub-bullets, plus a 3-line note-taking template.
```

### PROMPT-01-09 — Assumption/Risk Register
**Use when:** before kicking off a feature, you need every assumption and risk on record.
**Output:** a register table with test plans.
**Prompt:**
```text
You are a delivery lead building an assumption and risk register.
CONTEXT: Feature: {{feature_description}}. Timeline: {{timeline}}. Team: {{team_composition}}. Technical context: {{stack}}. External dependencies: {{integrations_or_vendors}}.
TASK: Produce a register with at least 12 entries mixing: user-behavior assumptions, technical unknowns, dependency/vendor risks, compliance/legal risks, and operational risks.
RULES: Each entry: ID, statement, category, likelihood (L/M/H), impact (L/M/H), why we believe it (evidence or "untested assumption"), cheapest test to run, and owner placeholder. Mark anything with no evidence as ASSUMPTION, not fact.
Do not rate anything Low just to shrink the list; justify every H. Do not propose tests costing more than {{test_budget_hint}}.
OUTPUT: a single markdown table sorted by likelihood×impact, plus a "top 3 kill risks" paragraph.
```

### PROMPT-01-10 — Prioritization (RICE)
**Use when:** a backlog of items needs an evidence-based ranking.
**Output:** a RICE-scored, ranked table.
**Prompt:**
```text
You are a product lead running a RICE prioritization.
CONTEXT: Items: {{backlog_items_with_one_line_each}}. Time horizon: {{horizon}}. Strategic theme: {{current_focus}}. Team size: {{team_size}}.
TASK: Score each item on Reach (users affected/period), Impact (3=massive,2=high,1=medium,0.5=low), Confidence (%), Effort (person-months). Compute RICE = Reach×Impact×Confidence/Effort. Rank and flag any item where Confidence < 50% as "research before committing".
RULES: Every Reach and Effort number must be labeled ESTIMATE with a one-line basis, or FACT with a source. Where basis is missing, write "insufficient information — needs estimation spike" instead of inventing a number.
Do not let strategic theme override the math silently — if you re-rank for strategy, show both columns and explain.
OUTPUT: markdown table sorted by RICE descending: Rank | Item | R | I | C | E | RICE | Basis | Flags, then a 4-line commentary on the top 3 picks and biggest disagreements.
```

### PROMPT-01-11 — Roadmap Narrative
**Use when:** a ranked backlog exists and leadership needs the "why now" story.
**Output:** a roadmap narrative with themes and sequenced bets.
**Prompt:**
```text
You are a product leader writing a roadmap narrative for leadership.
CONTEXT: Product: {{product_name}}. Ranked backlog (already prioritized): {{backlog_with_rationale}}. Horizon: {{quarters}}. Company strategy: {{company_strategy}}. Known capacity: {{team_capacity}}.
TASK: Group items into 2-4 outcome themes (not feature buckets), sequence them across the horizon, and write the narrative: where we are, the bet each theme represents, what we deliberately defer and why, and the metric that proves each theme worked.
RULES: Total named work per quarter must fit stated capacity — cut or defer visibly rather than overstuffing. Every deferral gets a one-line "what we risk by waiting".
Do not promise dates for items with Confidence below 50% in the source backlog. Do not use feature-count as a success metric.
OUTPUT: markdown — one `##` section per theme, a quarter-by-quarter sequence table, and a closing paragraph on biggest risks to the plan.
```

### PROMPT-01-12 — Edge-Case Brainstormer
**Use when:** before build, you want every edge case a feature could hit.
**Output:** a categorized edge-case matrix with handling rules.
**Prompt:**
```text
You are a QA-minded product thinker stress-testing a feature before build.
CONTEXT: Feature: {{feature_description}}. Expected happy path: {{happy_path}}. Environment: {{platforms_regions}}. User segments: {{user_types}}. Limits known so far: {{known_limits}}.
TASK: Brainstorm edge cases across these categories: input extremes (empty/max/malformed), concurrency (two users, double-submit), permissions, network/environment failure, data staleness, timezone/locale, account lifecycle (new/suspended/deleted), and abuse. Aim for 20+ cases.
RULES: For each case: ID, category, trigger scenario, expected correct behavior, and whether it is IN SCOPE for v1 (with a one-line reason). Cases with undefined correct behavior go to "needs product decision", not to engineering guesses.
Do not invent business rules to resolve ambiguous cases — escalate them. Do not repeat the same case in two categories.
OUTPUT: markdown matrix grouped by category, ending with a "needs product decision" list.
```

### PROMPT-01-13 — Spec Review (Devil's Advocate)
**Use when:** a spec looks done and you want it attacked before engineering starts.
**Output:** a severity-ranked critique with fix suggestions.
**Prompt:**
```text
You are a skeptical staff engineer reviewing a spec adversarially.
CONTEXT: Spec: {{paste_spec_or_path}}. System context: {{architecture_notes}}. Team constraints: {{constraints}}.
TASK: Attack the spec on: unspoken assumptions, failure modes with no handling, metrics that can't be measured as written, scope that hides complexity, dependencies treated as trivial, and security/privacy gaps. Rank each finding Critical/Major/Minor with the exact spec section referenced and a concrete fix.
RULES: Quote the spec text for every finding — no finding without a quote. Separate "spec is wrong" from "spec is silent"; silence is its own finding class.
Do not rewrite the whole spec; produce a findings list only. Do not raise stylistic preferences as findings.
OUTPUT: markdown table: Severity | Section | Quote | Problem | Suggested fix, sorted by severity; end with a one-paragraph verdict (ship / revise / rescope).
```

### PROMPT-01-14 — Metrics Definition for a Feature
**Use when:** a feature ships and you need the measurement plan defined up front.
**Output:** a metrics spec with event schema and guardrails.
**Prompt:**
```text
You are a product analyst writing the metrics definition for a feature.
CONTEXT: Feature: {{feature_description}}. North star: {{product_north_star}}. Instrumentation stack: {{analytics_tools}}. Privacy constraints: {{privacy_rules}}.
TASK: Define: 1 primary metric (direct outcome), 2-3 guardrail metrics (things that must not regress), and 3-5 diagnostic events with exact event names, properties, and trigger points. Specify the baseline, target (labeled ESTIMATE), and decision rule (what result leads to iterate vs keep vs revert).
RULES: Every metric needs a precise formula ("weekly users completing X / weekly active users"), not a vague label. Events must not collect PII unless listed in privacy constraints.
Do not propose metrics requiring infra you don't know exists — flag them as "verify instrumentation capability". Do not use vanity metrics (page views) as primary.
OUTPUT: markdown — Metric table (name, formula, type, baseline, target, decision rule), then Event schema as JSON code block.
```

### PROMPT-01-15 — Deprecation Plan
**Use when:** a feature or API must be retired without breaking users.
**Output:** a phased deprecation plan with comms.
**Prompt:**
```text
You are a product/eng lead writing a user-safe deprecation plan.
CONTEXT: Thing being deprecated: {{feature_or_api}}. Users affected: {{affected_segments}}. Usage data: {{current_usage_numbers}}. Replacement (if any): {{replacement}}. Hard deadline driver: {{why_now}}.
TASK: Produce a phased plan: Announcement (what, why, when, alternatives), Grace period (length justified by usage data, sunset headers/flags if API), Enforcement milestones (warnings → hard errors), and Post-removal (cleanup checklist, comms, support macros).
RULES: Timeline must be justified by usage numbers — label every duration choice with the data or as JUDGMENT CALL. If usage data is missing, say "insufficient information" and propose how to get it.
Do not set a hard date without a comms plan at least 2 touchpoints before it. Do not deprecate silently.
OUTPUT: markdown with `##` per phase, a milestone table (date | state | user-visible behavior), and a rollback contingency note.
```

### PROMPT-01-16 — Changelog-from-Diff
**Use when:** a release diff exists and you need user-facing changelog entries.
**Output:** a changelog entry separating user-facing from internal changes.
**Prompt:**
```text
You are a technical writer turning a code diff into a changelog.
CONTEXT: Diff or commit range: {{paste_diff_or_range}}. Product: {{product_name}}. Audience: {{audience_end_users_or_admins_or_devs}}. Previous release notes: {{style_reference_optional}}.
TASK: Classify each meaningful change as: Added, Changed, Fixed, Deprecated, or Security (conventional commits categories). Write one changelog line per change: user-visible impact first, then mechanism only if it clarifies. Drop pure refactors/tests/internal tooling into a one-line "Internal" note.
RULES: Only describe behavior a user or admin can observe — if a diff line has no observable effect, omit it. Mark anything ambiguous about user impact as "verify with author" instead of guessing.
Do not editorialize ("amazing new feature"). Do not omit security fixes — they get their own section.
OUTPUT: markdown changelog in Keep a Changelog format, `## [version]` with ### Added/Changed/Fixed/Security/Internal sections.
```

### PROMPT-01-17 — Stakeholder One-Pager
**Use when:** leadership or a client needs the whole project on one page.
**Output:** a single-page brief in markdown.
**Prompt:**
```text
You are a product manager compressing a project into a one-page stakeholder brief.
CONTEXT: Project: {{project_summary}}. Status: {{current_status_with_real_numbers}}. Decisions needed: {{what_you_need_from_reader}}. Risks: {{top_risks}}. Timeline: {{milestones}}.
TASK: Write a one-pager with exactly six blocks: TL;DR (2 sentences), Why now (3 bullets), Status (numbers only: done/total, metric deltas labeled FACT or ESTIMATE), Plan next 30/60/90 days, Asks (decisions needed with due dates), Top risks with mitigation.
RULES: If it does not fit one printed page, cut words not sections. Every number must carry its as-of date. "Green" status is forbidden — every status line needs one risk next to it.
Do not hide bad news in the risks section while the TL;DR says "on track" — they must agree. Do not include team-internal process detail.
OUTPUT: markdown, six `###` sections exactly as named above, total under 350 words.
```

### PROMPT-01-18 — Regulatory/Compliance Checklist Mapper
**Use when:** a feature touches regulated data and you need to know which obligations apply.
**Output:** an obligation map with gaps and owners.
**Prompt:**
```text
You are a compliance-aware product lead mapping a feature to regulatory obligations.
CONTEXT: Feature: {{feature_description}}. Data handled: {{data_types}}. Users' locations: {{jurisdictions}}. Industry: {{industry}}. Current controls: {{existing_compliance_posture}}.
TASK: Map the feature against: data minimization, consent/notice, retention/deletion, access rights requests, security controls, audit logging, and vendor/processor requirements. For each: obligation summary (one line), applicability (applies/likely applies/needs legal review), current gap, and required action before launch.
RULES: Cite the specific regulation section (e.g., GDPR Art. 17, HIPAA §164.310) for every "applies" — label anything you cannot cite as NEEDS LEGAL REVIEW, never present it as settled law.
Do not give legal advice — frame everything as "questions for counsel". Do not mark a gap closed without evidence of the control existing.
OUTPUT: markdown table: Obligation area | Regulation cite | Applicability | Gap | Action | Owner placeholder, then a pre-launch gate checklist.
```

### PROMPT-01-19 — User Persona Builder from Support Tickets
**Use when:** you have support-ticket data and want evidence-based personas.
**Output:** personas with verbatim-ticket grounding.
**Prompt:**
```text
You are a researcher building personas from support evidence, not stereotypes.
CONTEXT: Product: {{product_name}}. Ticket export or themes: {{tickets_or_file_paths}}. Time range: {{date_range}}. Ticket volume: {{count}}.
TASK: Cluster tickets into 3-5 distinct user patterns. For each persona: name/role, context of use, top 3 frustrations (with 1-2 verbatim ticket quotes each), what they tried before contacting support, and what outcome they actually wanted (not the feature they asked for).
RULES: Every persona claim must trace to at least 2 ticket quotes or be labeled PATTERN GUESS with low confidence. Report cluster sizes ("12 of 140 tickets") so weight is visible. Separate the persona's stated request from the underlying job.
Do not invent demographics (age, income) absent from tickets. Do not merge clusters that want opposite outcomes.
OUTPUT: markdown — one `##` persona per cluster with a quote-backed evidence table, plus a final "what support data can't tell us" section.
```

### PROMPT-01-20 — Scope-Creep Guard
**Use when:** a new request arrives mid-project and you must compare it to the original spec.
**Output:** a diff verdict: in scope / negotiation / out of scope.
**Prompt:**
```text
You are a delivery lead adjudicating a mid-project request against the original spec.
CONTEXT: Original spec (authoritative): {{paste_spec_or_path}}. New request: {{new_ask}}. Requested by: {{stakeholder}}. Current phase: {{phase_and_remaining_capacity}}.
TASK: Compare the new ask against the spec line by line. Verdict exactly one of: IN SCOPE (spec already covers it — point to the section), SCOPE ADDITION (spec is silent — cost it and list trade-offs), or CONTRADICTS SPEC (conflicts with an agreed requirement — show both texts). For SCOPE ADDITION, produce a mini-estimate table (areas touched, risk, test impact) labeled ESTIMATE.
RULES: Quote both the spec and the new ask for every finding. The spec text outranks stakeholder seniority — if the stakeholder disagrees, the output is a decision point for them, not silent absorption.
Do not estimate without stating the basis. Do not expand the spec yourself; only the comparison and cost.
OUTPUT: markdown — verdict header, evidence table (Spec quote | New ask quote | Relationship), then if addition: estimate table and a one-line decision prompt for the stakeholder.
```
