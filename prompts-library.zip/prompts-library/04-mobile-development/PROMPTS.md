# 04 — Mobile Development

Prompts for shipping and hardening mobile apps across iOS, Android, and React Native: architecture, performance, store operations, and accessibility.
Replace every `{{placeholder}}` with your project specifics (paths, SDK versions, store links). Coding prompts use a strict plan→approve→edit→verify loop and require reading project files before proposing changes.

### PROMPT-04-01 — Screen Scaffold (SwiftUI / Jetpack Compose / RN)
**Use when:** scaffolding a new screen in an existing app with correct architecture patterns.
**Output:** a plan, then the screen implementation matching project conventions.
**Prompt:**
```text
You are a senior mobile engineer scaffolding a new screen.
CONTEXT: Repo: {{repo_path}}. Platform: {{swiftui_jetpack_compose_react_native}}. Screen: {{purpose_and_user_goal}}. Architecture in use: {{mvvm_mvi_tca_etc}}. Data source: {{endpoint_or_store}}.
TASK: Step 1 — read the project's existing screens, navigation setup, and state/data layers; present the plan: file locations, state model (view state sealed class / state object / reducer), how the screen observes data, and navigation hooks. WAIT for approval. Step 2 — implement the screen with loading/empty/error states, lifecycle correctness, and a preview/snapshot if the project has them.
RULES: Match the project's real architecture and conventions exactly — verify by reading at least 2 existing screens, not by assumption. Use only dependencies already in the project (Package.swift/gradle/podfile/package.json verified). Verification: {{build_and_test_command}} until green.
Do not introduce a new architecture or DI framework. No new dependencies without approval.
OUTPUT: plan summary, diff, build/test verification results.
```

### PROMPT-04-02 — Navigation Architecture (Stack/Tabs/Deep-Link)
**Use when:** designing or refactoring app navigation across stacks, tabs, and deep links.
**Output:** a navigation map plus implemented changes.
**Prompt:**
```text
You are a mobile architect designing the navigation layer.
CONTEXT: Repo: {{repo_path}}. Platform/framework: {{swiftui_uikit_compose_navigation_rn_navigation}}. Screens: {{screen_inventory}}. Deep-link requirements: {{urls_notifications_ads}}. Modals/sheets: {{which_flows_are_modal}}.
TASK: Step 1 — read the current navigation code and produce a navigation map: root structure (tabs vs single stack), per-tab stacks, modal presentation points, and the deep-link routing table (URL pattern → destination, argument handling, auth gating). Identify problems (cycles, dead ends, state loss on process death). WAIT for approval. Step 2 — implement the agreed structure and route handling, including back-stack correctness and restoration.
RULES: Verify the navigation library's actual API version against the project's config before using any API. Deep links must survive process death and respect auth state. Back from a deep-linked screen must land somewhere sensible — specify the back stack per route.
Do not hand-roll a navigation system if a library is already in use. No new dependencies without approval.
OUTPUT: navigation map (ASCII), routing table, diff, verification via {{build_and_test_command}}.
```

### PROMPT-04-03 — Offline-First Data Layer
**Use when:** the app's data layer must work without connectivity and sync later.
**Output:** an architecture doc plus implemented slice.
**Prompt:**
```text
You are a mobile data engineer designing an offline-first layer.
CONTEXT: Repo: {{repo_path}}. Platform: {{ios_android_rn}}. Local persistence in use: {{coredata_room_realm_realm_js_none}}. API: {{endpoints_and_shapes}}. Edit conflicts: {{who_edits_same_records}}. Offline UX scope: {{read_only_or_full_editing}}.
TASK: Produce the design: local schema and mapping from API models, sync strategy (push mutations from an outbox queue, pull with delta tokens/etags — verify what the API supports), conflict policy per entity type, staleness display rules, and retry/backoff on failed sync. Then implement the agreed first slice with tests.
RULES: Verify the persistence framework's real API from the project's version before writing code. The API's actual sync capabilities (etags? delta endpoints?) must be confirmed from code/docs — if unknown, mark NEEDS BACKEND CONFIRMATION. Queue must survive app kill.
Do not promise last-write-wins for fields needing merge. No new dependencies without approval.
OUTPUT: design doc (schema, outbox flow, conflict table), slice diff, test results from {{test_command}}.
```

### PROMPT-04-04 — Push-Notification Strategy
**Use when:** designing the full notification system: permissions, types, handling, and metrics.
**Output:** a strategy spec plus implementation of agreed pieces.
**Prompt:**
```text
You are a mobile platform engineer designing push notifications.
CONTEXT: App: {{app_and_platforms}}. Services: {{fcm_apns_or_provider_like_onesignal}}. Notification types: {{transactional_marketing_reminder}}. User settings: {{existing_preferences_model}}. Cold-start handling: {{what_tapping_each_type_should_do}}.
TASK: Design: permission priming (when and with what copy — before or after value moment), token registration/refresh flow, payload contract (data-only vs alert, deep-link field, versioning), presentation handling in foreground, tap routing (cold start vs warm), preference gating per type, and delivery/analytics events.
RULES: Verify OS behavior and provider APIs against current platform docs — flag anything version-dependent. Transactional and marketing channels must be separable so settings and OS channel config can gate them. Payload contract must be versioned from day one.
Do not request permission at first launch without the priming screen. Do not put PII in payloads.
OUTPUT: markdown spec (flows as numbered steps, payload JSON schema, routing table), then implement agreed pieces with verification via {{build_command}}.
```

### PROMPT-04-05 — App-Store Listing Optimizer
**Use when:** preparing or improving App Store / Play Store listing metadata.
**Output:** an optimized listing package with rationale.
**Prompt:**
```text
You are an ASO specialist producing a store listing.
CONTEXT: App: {{name_and_core_value}}. Audience: {{primary_segments}}. Differentiators (evidence-backed): {{what_we_beat_competitors_on}}. Current listing: {{existing_text_keywords_ratings}}. Locale: {{primary_and_secondary_languages}}.
TASK: Produce: subtitle/short description (within {{platform_char_limits}}), keyword field strategy (iOS: comma-separated, no spaces, no repeats of title words; Play: natural-language integration), full description (first 2 lines carry the hook; features as scannable bullets), screenshot caption strategy (one message per screenshot, ordered by decision importance), and review-response templates for the 5 most common complaints.
RULES: Every keyword claim must come from the actual metadata or competitor analysis provided — label INFERENCE otherwise. No superlatives without proof ("#1", "best") — store policy risk flagged. Character counts stated and enforced per field.
Do not keyword-stuff into visible copy. Do not promise features from the roadmap as shipped.
OUTPUT: markdown — field-by-field listing (with char counts), keyword table (term | source | priority), screenshot order plan, response templates.
```

### PROMPT-04-06 — Startup Performance Audit (TTI)
**Use when:** the app launches slowly and cold-start time must come down.
**Output:** a measurement-first audit then prioritized fixes.
**Prompt:**
```text
You are a mobile performance engineer auditing cold start.
CONTEXT: Repo: {{repo_path}}. Platform: {{ios_android_rn_flutter}}. Symptom: {{tti_seconds_by_device_tier}}. Known suspects: {{heavy_init_sdk_splash_sync_work}}. Measurement tooling available: {{xcode_instruments_android_studio_profiler_flipper}}.
TASK: Step 1 — define the measurement method (instruments/template, startup tracing, RN: Hermes profiling flags) and the baseline protocol (device, OS, cold vs warm, 5-run median). WAIT for me to paste numbers. Step 2 — from the profile, attribute time: process creation, framework/SDK init, first render, network-gated content — then rank fixes (lazy SDK init, deferring non-critical work past first paint, image/asset weight, main-thread I/O).
RULES: No fix without profile attribution. Expected gains labeled ESTIMATE with the profile evidence cited. Distinguish cold start from warm start in all numbers.
Do not recommend a rewrite. Do not remove SDKs unilaterally — propose deferral/config changes.
OUTPUT: measurement protocol, attribution table, ranked fix list (effort | est. gain | evidence), and the top fix's diff with re-measured before/after.
```

### PROMPT-04-07 — Memory-Leak Hunt
**Use when:** the app memory grows unboundedly (screens, camera, WebView, RN bridges).
**Output:** a leak-suspect map then verified fixes.
**Prompt:**
```text
You are a mobile stability engineer hunting memory leaks.
CONTEXT: Repo: {{repo_path}}. Platform: {{ios_android_rn}}. Symptom: {{which_flows_grow_memory_by_how_much}}. Tooling: {{leaks_profiler_mat_android_studio_rn_flipper}}. Suspect areas: {{closures_handlers_subscriptions_timers_images}}.
TASK: Step 1 — give the measurement protocol (repeat the suspect flow N times, force GC where possible, capture heap/leaks report) and WAIT for pasted results. Step 2 — from evidence, identify retainers/cycles: strong self-captures, uninvalidated timers/observers, leaked view controllers/activities (screen rotations are the classic detector), unbounded caches/image stores, RN: listeners not removed on unmount. Fix the confirmed ones with the minimal change and re-measure.
RULES: Every fix cites the retaining path from the actual profiler output. Fixes must include a prevention note (pattern to avoid in review). If tooling cannot confirm, the item stays on the suspect list — no speculative "fixes".
Do not sprinkle weak references blindly. Do not add a cache-clearing hack without an eviction policy.
OUTPUT: protocol, evidence table (leak | retaining path | fix | status), diffs, re-measured results.
```

### PROMPT-04-08 — Deep-Link/Universal-Link Setup
**Use when:** configuring universal links (iOS) / app links (Android) and verifying end-to-end.
**Output:** a config + verification checklist, then implemented changes.
**Prompt:**
```text
You are a mobile engineer wiring up deep links correctly.
CONTEXT: Repo: {{repo_path}}. Platform(s): {{ios_android_both}}. Domain: {{domain}}. URL scheme fallbacks needed? {{yes_no}}. Links originate from: {{email_sms_web_ads}}. Edge cases: {{logged_out_expired_content_already_installed}}.
TASK: Produce the full setup: associated-domains/apple-app-site-association file (exact JSON shape, served over HTTPS with correct content type, no redirects), Android assetlinks.json (with sha256 fingerprint instructions), intent-filter/autoVerify config, in-app routing (cold start vs foreground handoff, fallback when content missing, web fallback page), and a testing matrix per OS version and install state.
RULES: Verify current AASA/assetlinks requirements from platform docs — these formats change. The verification checklist must include the CDN/redirect pitfalls (AASA must not redirect, must be served fast). Mark any CDN behavior you cannot verify as NEEDS INFRA CHECK.
Do not enable autoVerify without the assetlinks being live. Do not drop users on home screen when a deep link fails — define fallback behavior.
OUTPUT: config files content, routing code diff, and the pass/fail test matrix with status per row.
```

### PROMPT-04-09 — Biometric Auth Flow
**Use when:** adding Face ID / fingerprint sign-in or app-lock with secure fallback.
**Output:** a flow spec then implemented code.
**Prompt:**
```text
You are a mobile security engineer implementing biometric auth.
CONTEXT: Repo: {{repo_path}}. Platform: {{ios_android_rn}}. Purpose: {{app_lock_or_transaction_approval_or_login}}. Fallback policy: {{device_passcode_password_none}}. Server side: {{does_server_need_attestation_or_just_session}}.
TASK: Design and implement: availability detection (hardware + enrolled biometrics + lockout states), the system prompt with fallbacks (LAContext policy / BiometricPrompt), secure credential storage (Keychain/Keystore — where the session token actually lives), failure handling (lockout backoff, too-many-attempts path), and the explicit opt-in/out settings entry. Document what biometrics prove locally vs to the server.
RULES: Use only platform security APIs (Keychain/Keystore access-control flags) — verify against current SDK docs, no custom crypto. Never store secrets in UserDefaults/SharedPreferences. Failure states must never soft-lock the user without the passcode/password path.
Do not roll your own biometric UI on top of the system prompt. No new dependencies without approval.
OUTPUT: flow diagram (ASCII), diff, verification via {{test_command}}, and a security-note section on local-only vs server-verified auth.
```

### PROMPT-04-10 — Accessibility Audit (VoiceOver/TalkBack)
**Use when:** auditing a screen or flow for screen-reader and keyboard/switch usability.
**Output:** a per-element audit with fix list.
**Prompt:**
```text
You are a mobile accessibility specialist auditing with VoiceOver/TalkBack criteria.
CONTEXT: App/screen: {{screen_or_flow}}. Platform: {{ios_android_both}}. UI framework: {{swiftui_uikit_compose_rn}}. Audit material: {{screenshots_screen_recording_code}}.
TASK: Audit: labels (every interactive element has a meaningful accessibilityLabel, images decorative or labeled), traits/button roles, focus order (matches visual and logical order), grouping (related content as one element vs fragmented reads), dynamic type/text scaling (layout survives largest sizes, no truncation of critical text), contrast, touch target sizes, and custom-control behavior (does the control announce state changes like toggle on/off?).
RULES: Every finding names the element and the exact failure ("price label reads as three separate elements"). Distinguish CONFIRMED (from provided evidence) from NEEDS DEVICE TEST (give the exact VoiceOver/TalkBack gesture steps). Fixes must use platform-appropriate APIs (verify against current SDK docs).
Do not recommend accessibilityLabel on everything — decorative elements must be hidden. Do not fix contrast by lowering text size.
OUTPUT: markdown table (element | issue | severity | platform API fix | evidence type), plus a device-test backlog with steps.
```

### PROMPT-04-11 — Release Checklist (Store Review)
**Use when:** preparing a build for App Store / Play review and production release.
**Output:** a gate checklist with status per item.
**Prompt:**
```text
You are a release manager running a pre-submission gate.
CONTEXT: Repo: {{repo_path}}. Version: {{version_and_build}}. Platform: {{ios_android_both}}. Store accounts: {{appstore_connect_play_console_access}}. This release contains: {{changelog_items}}. Config differences prod vs staging: {{api_urls_flags}}.
TASK: Run through every gate: version/build numbers incremented and consistent, release notes written, store metadata/screenshots updated if UI changed, privacy labels/nutrition labels match actual data collection (diff against manifest/Info.plist declarations), export-compliance/encryption declaration correct, demo account for review provided, feature flags in safe default state, crash reporting and analytics verified live on the release build, rollback plan (phased rollout %, staged tracks).
RULES: Every item gets PASS (evidence), FAIL (blocker — stop), or UNVERIFIABLE (who/what can verify it). Privacy declarations must be cross-checked against the actual SDK manifest — list any SDK whose data collection is unknown as NEEDS CHECK, not assumed clean.
Do not mark "tested" without stating on which build/device. Do not submit with feature flags in unknown state.
OUTPUT: markdown checklist table grouped by (build, store, privacy, ops), overall GO/NO-GO verdict with blockers listed.
```

### PROMPT-04-12 — OTA Update Strategy
**Use when:** planning over-the-air JS bundle updates (CodePush/EAS Update/expo-updates).
**Output:** a strategy spec plus implementation of the rollout mechanism.
**Prompt:**
```text
You are a mobile release engineer designing an OTA update strategy.
CONTEXT: Repo: {{repo_path}}. Platform: {{react_native_expo_bare}}. OTA service: {{eas_update_codepush_self_hosted}}. Native change cadence: {{how_often_native_ship}}. Rollback requirements: {{immediate_or_next_release}}. User base risk tolerance: {{consumer_enterprise}}.
TASK: Design: channel strategy (production/staging/preview branches or deployments), targeting (by version, runtime version, rollout percentage), the native/JS compatibility matrix (how runtime version gates updates, what happens when an OTA targets an incompatible binary), rollback procedure, and update-prompt UX (forced vs optional, when to show). Implement the update-check/prompt integration per the plan.
RULES: Verify the OTA service's current API and rollback semantics from its docs — flag anything version-dependent. Every OTA must be tied to a runtime/native version it is compatible with; the check must fail closed (no update) on mismatch.
Do not force-update users for non-critical fixes without a policy. No new dependencies without approval.
OUTPUT: strategy doc (channels, matrix, rollback steps), diff, and verification via {{test_command}}.
```

### PROMPT-04-13 — Gesture Handling Spec
**Use when:** a screen needs custom gestures (swipe, drag, pinch, long-press) without fighting the OS.
**Output:** a gesture spec then implemented handlers.
**Prompt:**
```text
You are a mobile interaction engineer specifying custom gestures.
CONTEXT: Repo: {{repo_path}}. Platform: {{ios_android_rn}}. Gesture: {{swipe_drag_pinch_longpress}}. On which element: {{list_cell_map_canvas_sheet}}. Conflict surface: {{scroll_view_nav_back_os_gestures}}. Haptics: {{desired_feedback_points}}.
TASK: Specify: gesture recognizer configuration (directions, thresholds, velocity/fail requirements per platform), simultaneous/exclusive recognition relationships with existing scroll and OS back gestures (explicit conflict matrix), cancelation behavior (gesture fails mid-drag → snap back?), accessibility fallback (the same action available via button/double-tap for users who can't perform the gesture), and haptic feedback points (light/medium at success boundaries). Implement per spec.
RULES: Verify platform gesture API specifics from current docs; on Android/RN, document how the handler coexists with system back gesture. Every gesture must have a non-gesture alternative (WCAG 2.5.1/2.5.7 alignment).
Do not disable OS back/scroll gestures to make room for custom ones. No new dependencies without approval.
OUTPUT: spec (config + conflict matrix + fallback), diff, verification via {{test_command}} plus manual test steps.
```

### PROMPT-04-14 — Haptic/Motion Design
**Use when:** defining the app's haptic and motion language consistently.
**Output:** a haptic/motion token spec with usage rules.
**Prompt:**
```text
You are a mobile motion designer defining haptics and animation language.
CONTEXT: App: {{app_and_brand_feel}}. Platform: {{ios_android_rn}}. Existing motion: {{what_exists_or_none}}. High-stakes moments: {{payments_destructive_success_errors}}.
TASK: Define: haptic patterns mapped to semantic events (success/error/warning/selection/light impact) with per-platform generators (UIImpactFeedbackGenerator/HapticFeedback constants — verify current API names), animation durations/easings as tokens (fast 150ms / base 250ms / slow 400ms with platform curves), rules for parallax/reduced-motion handling, and the "never haptic" list (background events, repeated scrolling, non-user-initiated).
RULES: Every token needs a usage example and an abuse warning. Reduced-motion setting must degrade haptics/animations per platform guidance — verify current OS behavior. Haptics only on user-initiated actions or completion of user-started tasks.
Do not haptic on passive content arrival. Do not exceed one haptic per user action.
OUTPUT: markdown token tables (haptic event → generator → when; motion token → duration/curve → use), then the never-list and reduced-motion rules.
```

### PROMPT-04-15 — Crash-Report Triage
**Use when:** a crash spike or recurring crash needs rapid triage and fix.
**Output:** a ranked diagnosis then fix with regression test.
**Prompt:**
```text
You are a mobile stability engineer triaging crash reports.
CONTEXT: Repo: {{repo_path}}. Crash data: {{stack_traces_symbols_affected_versions_devices_from_crashlytics_sentry}}. When it started: {{first_seen_version_date}}. Repro steps (if any): {{known_or_none}}.
TASK: Symbolicate/interpret the top crashes, cluster by root cause (not just stack similarity), and rank by affected users × frequency. For each top cluster: hypothesized root cause traced into the actual code (read the files), the minimal fix, and a regression test or guard (force-unwrap/nullable audit, lifecycle race, forced-unwrap on parsing, main-thread violation).
RULES: Read the actual code at every frame of the stack before proposing fixes — quote file/line. If symbolication is incomplete, state what dSYM/mapping file is needed instead of guessing. Crashes without repro get a defensive-fix proposal labeled HYPOTHESIS, clearly separated from confirmed fixes.
Do not silence crashes with catch-all handlers. Do not mark fixed without the regression mechanism.
OUTPUT: cluster table (crash | users | versions | root cause | confidence), fixes as diffs, regression tests, and verification via {{test_command}}.
```

### PROMPT-04-16 — Dependency Upgrade Plan (SDK Bump)
**Use when:** upgrading a major SDK/framework version (e.g., iOS SDK, compileSdk, RN version).
**Output:** a risk-assessed upgrade plan, then executed step.
**Prompt:**
```text
You are a mobile platform engineer planning a major SDK upgrade.
CONTEXT: Repo: {{repo_path}}. Current → target versions: {{from_to}}. Platform: {{ios_android_rn_flutter}}. Breaking changes known: {{changelog_highlights_or_none}}. Downstream dependencies at risk: {{third_party_sdks_libs}}. Release pressure: {{deadline}}.
TASK: Step 1 — inventory the blast radius read-only (all usages of deprecated/renamed APIs in the codebase, third-party libs' compatibility matrices verified against their current releases, build/CI impact), and produce a staged plan: spike branch, mechanical migration, behavioral fixes, soak period. WAIT for approval. Step 2 — execute stage 1 on a branch with {{build_and_test_command}} green before proceeding.
RULES: Every "incompatible" claim cites the dependency's official release notes/changelog as of today, or is marked NEEDS VERIFICATION. Lockfile/config diffs reviewed explicitly. Plan includes a rollback (pin previous version) step.
Do not upgrade unrelated dependencies in the same pass. Do not proceed past a red build.
OUTPUT: blast-radius inventory, staged plan with gates, stage-1 diff + verification results.
```

### PROMPT-04-17 — Screenshot/Test-Plan Generation
**Use when:** a new feature needs its full manual QA matrix before release.
**Output:** a device/OS test matrix with expected results.
**Prompt:**
```text
You are a QA lead generating the manual test plan for a feature.
CONTEXT: Feature: {{feature_description}}. Repo: {{repo_path_for_behavior_reference}}. Supported matrix: {{devices_os_versions_min_targets}}. Network conditions to cover: {{offline_slow_3g_switching}}. Locale/accessibility combos: {{rtl_large_text_dark_mode}}.
TASK: Generate the matrix: functional paths (happy path + every branch/error state from the code's actual handling — read the implementation, don't guess), device-specific risks (notch/foldable/tablet layouts, low-RAM devices), OS-version-specific behaviors (permission dialogs, back gestures), lifecycle interruptions (call, background 30min+, process death mid-flow, low battery), and visual states (dark mode, dynamic type largest, RTL). Each case: steps, expected result, and severity if failed.
RULES: Every case must trace to behavior visible in the code or stated requirements — mark derived-from-assumption cases clearly. Include at least one process-death test per flow. Prioritize P0 (blocks release) vs P1.
Do not write "app works as expected" as an expected result — state the exact observable outcome. Do not skip offline/lifecycle columns for networked features.
OUTPUT: markdown tables grouped by category: ID | Preconditions | Steps | Expected result | Severity | Platform scope.
```

### PROMPT-04-18 — In-App Purchase/Subscription Flow
**Use when:** implementing or reviewing purchases/subscriptions with store compliance.
**Output:** a flow spec plus implementation/review findings.
**Prompt:**
```text
You are a mobile monetization engineer implementing store purchases.
CONTEXT: Repo: {{repo_path}}. Platform(s): {{ios_android_both}}. Products: {{consumables_subscriptions_one_time}}. Billing lib: {{storekit_billingclient_revenuecat_none}}. Server receipt validation: {{exists_or_none}}. Restore purchases needed? {{yes_no}}.
TASK: Produce/verify the full flow: product loading and localized pricing display, purchase initiation, transaction states (purchasing/purchased/failed/deferred — family sharing, pending transactions), receipt validation path (local vs server — state which and its trust boundary), entitlement unlock, restore purchases, subscription lifecycle events (renewal/lapse/grace period via server notifications or client polling — state what's implemented vs missing), and refund/edge handling.
RULES: Verify store billing APIs against current platform docs (these change frequently) — flag version-sensitive calls. Prices must come from the store (localized), never hardcoded. Pending/failed states must never grant entitlement. Without server validation, state clearly what fraud exposure exists.
Do not hardcode product IDs scattered — centralize and flag if not. No new dependencies without approval.
OUTPUT: flow spec with state machine (ASCII), findings table if reviewing, diff if implementing, verification via {{test_command}}.
```

### PROMPT-04-19 — Background-Task Design
**Use when:** work must continue when the app is backgrounded (sync, location, uploads).
**Output:** a background-task architecture with OS-constraint compliance.
**Prompt:**
```text
You are a mobile systems engineer designing background execution.
CONTEXT: Repo: {{repo_path}}. Platform: {{ios_android_rn}}. Task type: {{upload_sync_location_audio_fetch}}. Trigger model: {{user_initiated_periodic_event_driven}}. Latency tolerance: {{seconds_minutes_hours}}. Data constraints: {{size_battery_metered_network}}.
TASK: Design within real OS constraints (verify against current platform docs): iOS (BGTaskScheduler refresh window realism, URLSession background config, push-triggered wakes, what iOS will NOT let you do), Android (WorkManager constraints — network/battery/charging, expedited jobs quotas, foreground service requirements), and cross-platform RN options. Specify: schedule/constraints, retry/backoff, partial-failure handling, and user-visible indicators (required for some Android cases).
RULES: Explicitly state what the OS forbids for the chosen model (e.g., exact-interval periodic work on iOS) and offer the compliant alternative. Battery/network constraints must be first-class inputs, not afterthoughts. Task must be idempotent — document the dedup key.
Do not design polling loops the OS will kill. No new dependencies without approval.
OUTPUT: architecture doc (triggers, constraints, retry policy, OS-limit table), then implement the agreed slice with verification via {{test_command}}.
```

### PROMPT-04-20 — Beta Feedback Synthesis
**Use when:** a beta/testflight cohort has submitted feedback that needs action.
**Output:** clustered findings with severity and fixes.
**Prompt:**
```text
You are a product engineer synthesizing beta feedback into an action list.
CONTEXT: Beta: {{cohort_size_platforms_build_version}}. Feedback source: {{testflight_feedback_play_console_form_survey_paste_or_files}}. Known issues already tracked: {{existing_tickets}}. Release target: {{date}}.
TASK: Cluster feedback by theme: deduplicate overlapping reports, separate defects from enhancement requests from confusion/onboarding issues, and for each cluster: affected users (count), severity (crash/blocker/major/minor), evidence quotes, probable root cause (label HYPOTHESIS unless traceable to code — read the repo where relevant), recommended action (fix / needs design / needs instrumentation / won't fix with reason), and owner suggestion.
RULES: Report counts per cluster so weight is visible; a single-user report is not a trend — label accordingly. Cross-reference against existing tickets to avoid duplicates. Everything claimed about app behavior must be verified against the actual code or marked unverified.
Do not prioritize by loudness — severity and affected-user counts decide. Do not turn every request into a commitment; the won't-fix bucket needs honest reasons.
OUTPUT: markdown — cluster table (theme | users | severity | root cause | action | owner), then P0/P1 action list and a "respond to beta users" draft paragraph.
```
