# 07 — Architecture

System design, decision records, trade-off analysis, and architecture health. Covers design docs, ADRs, failure analysis, and fitness against non-functional requirements.
Placeholder convention: `{{double_braces}}` mark user-supplied input (system description, constraints, NFRs, diagrams). Replace every placeholder before sending; a prompt with unfilled placeholders should be treated as incomplete.

---

### PROMPT-07-01 — System Design Doc (Interview-Style)
**Use when:** designing a system from a one-paragraph requirement, interview or real.
**Output:** a complete design document with estimates, trade-offs, and an iteration plan.
**Prompt:**
```text
ROLE: Principal engineer writing a system design document.
CONTEXT: Requirement: {{requirement}}. Constraints: {{constraints}} (scale targets labeled ESTIMATE unless measured, latency SLOs, budget, team size). Scale assumptions: {{scale}}.
TASK: Produce the design: requirements breakdown (functional, non-functional), capacity model (QPS, storage, bandwidth with arithmetic shown), API surface, data model, high-level components with responsibility boundaries, and a scaling path (what breaks at 10x).
CONSTRAINTS: Every number must be labeled MEASURED or ESTIMATE and its arithmetic shown. Explicitly list at least two alternative designs considered and why rejected. Do not select technologies by fashion — justify each against a requirement. Flag where {{constraints}} are internally inconsistent.
OUTPUT FORMAT: Markdown design doc with sections: (1) Requirements, (2) Capacity model (table with formulas), (3) Architecture overview + Mermaid diagram, (4) Component details, (5) Data model sketch, (6) Alternatives considered, (7) Risks and unknowns, (8) Build order.
```

### PROMPT-07-02 — Architecture Decision Record Writer
**Use when:** capturing a significant technical decision as a durable ADR.
**Output:** a complete ADR in standard format, ready to commit.
**Prompt:**
```text
ROLE: Technical writer producing an Architecture Decision Record.
CONTEXT: Decision to record: {{decision}}. Options considered: {{options}}. Forces at play (requirements, team skills, legacy, cost): {{forces}}. Decision status (proposed/accepted/deprecated): {{status}}.
TASK: Write an ADR with: context and problem, decision drivers ranked, options table (with honest pros/cons), the chosen option and rationale, consequences (positive, negative, follow-ups), and compliance/rollback notes. Write neutrally enough that a future reader can re-litigate with the same facts.
CONSTRAINTS: Do not soften known downsides — list them under consequences. Do not invent evaluation results; if options were not actually compared, say "options documented retrospectively." Dates must be provided or left as {{date}}. Links to evidence (benchmarks, spikes) must be real or omitted.
OUTPUT FORMAT: Markdown ADR: Title, Status, Context, Decision Drivers, Considered Options, Decision Outcome, Consequences, Links. Sections exactly in this order.
```

### PROMPT-07-03 — Monolith vs Microservices Decision Matrix
**Use when:** debating whether to split a system (or keep it whole) and needing an evidence-based answer.
**Output:** a weighted decision matrix with a recommendation and trigger conditions.
**Prompt:**
```text
ROLE: Architecture advisor on service decomposition.
CONTEXT: System description: {{system}}. Team structure and count: {{team}}. Deployment pain points: {{pain_points}}. Domain boundaries (if known): {{domains}}. Current infra maturity (CI/CD, observability): {{maturity}}.
TASK: Build a weighted decision matrix scoring monolith, modular monolith, and microservices against criteria: team autonomy needs, independent deploy requirements, scaling profile per component, data-consistency needs, operational maturity required, failure isolation. Recommend an option plus the conditions (triggers) under which the answer would change.
CONSTRAINTS: Default to the simplest option that fits; splitting must be justified by a named criterion, not fashion. All scores are JUDGMENT unless backed by a cited measurement — label them. Include "do not split" failure modes (distributed monolith, shared DB). State observability/CI prerequisites before any split.
OUTPUT FORMAT: Markdown: (1) Criteria and weights table, (2) Scored matrix, (3) Recommendation with rationale, (4) Change triggers (what evidence would flip the decision), (5) Prerequisite checklist before executing.
```

### PROMPT-07-04 — Event-Driven Architecture Review
**Use when:** reviewing a proposed or existing event-driven design for delivery, ordering, and consistency pitfalls.
**Output:** a review report with failure-mode table and corrections.
**Prompt:**
```text
ROLE: Distributed-systems reviewer specializing in messaging.
CONTEXT: Architecture description or diagram: {{architecture}}. Broker and client libraries: {{broker}}. Event catalog (topics, schemas): {{events}}. Consistency requirements: {{consistency}}.
TASK: Review for: at-least-once vs exactly-once semantics (and idempotency of consumers), ordering guarantees per key, schema evolution strategy, poison-message handling, DLQ policy, consumer lag monitoring, and event-as-source-of-truth vs derived-state consistency.
CONSTRAINTS: Verify broker feature claims (transactions, ordering) against {{broker}} version docs. Every "guarantee" must be traced to a configured mechanism, not assumed. Flag any consumer that cannot tolerate duplicates. Where {{events}} lacks schemas, mark the review gap explicitly.
OUTPUT FORMAT: Markdown: (1) Architecture flow restated (Mermaid), (2) Semantics analysis table (component, claimed semantics, mechanism, gap), (3) Ordered findings by severity, (4) Correction sketches, (5) Observability checklist, (6) Open questions.
```

### PROMPT-07-05 — CQRS Suitability Analysis
**Use when:** deciding whether Command Query Responsibility Segregation earns its complexity for your system.
**Output:** a suitability verdict with conditions, costs, and a simpler fallback.
**Prompt:**
```text
ROLE: Architecture advisor evaluating CQRS.
CONTEXT: System: {{system}}. Read/write load characteristics: {{loads}}. Consistency tolerance between read and write models: {{tolerance}}. Team distributed-systems experience: {{experience}}.
TASK: Evaluate whether CQRS is justified: name the specific problem it solves here (scaling asymmetry, separate models, event sourcing needs) and compare against the simpler alternative (single model + indexes/read replicas). Enumerate the real costs: eventual-consistency UX, sync mechanism (events/outbox), duplicate model maintenance, debugging complexity.
CONSTRAINTS: If no concrete scaling or model-mismatch problem is stated, recommend against full CQRS. Partial CQRS (separate read DB, same write model) must be presented as an option. Consistency windows must be stated in user-visible terms. Label all load numbers MEASURED or ESTIMATE.
OUTPUT FORMAT: Markdown: (1) Problem statement, (2) Options compared (plain, partial CQRS, full CQRS) with cost table, (3) Verdict with conditions, (4) If yes: sync design sketch, (5) If no: what to do instead, (6) Re-evaluation triggers.
```

### PROMPT-07-06 — Capacity-Planning Model
**Use when:** projecting infrastructure needs for a growth scenario.
**Output:** a capacity model with formulas, headroom, and a measurement plan.
**Prompt:**
```text
ROLE: Capacity-planning engineer.
CONTEXT: Current usage metrics: {{current_metrics}} (QPS, CPU, memory, storage, bandwidth — MEASURED preferred). Growth scenario: {{growth}} (2x in 6 months, launch event, etc.). Service resource profile: {{resource_profile}}.
TASK: Build a bottom-up model: derive per-request resource costs from current metrics, project at {{growth}}, add headroom (state the percentage and why), identify the first bottleneck at each growth step, and produce a provisioning table. Include a measurement plan to validate model assumptions.
CONSTRAINTS: Every input must be labeled MEASURED or ESTIMATE; ESTIMATE inputs carry the largest uncertainty and must be flagged. Show all arithmetic — no unexplained outputs. Non-linear effects (caches saturating, connection limits) must be called out. State the model's expiration (re-validate by date).
OUTPUT FORMAT: Markdown: (1) Inputs table (metric, value, source, confidence), (2) Derivation of per-unit costs, (3) Projection table at each growth step, (4) Bottleneck analysis, (5) Headroom policy, (6) Validation plan.
```

### PROMPT-07-07 — Technology-Selection Scorecard
**Use when:** choosing between frameworks, databases, or platforms with competing claims.
**Output:** a weighted scorecard with evidence links and a testable decision.
**Prompt:**
```text
ROLE: Technical evaluator running a technology selection.
CONTEXT: Options: {{options}}. Evaluation criteria and weights proposed by the team: {{criteria}}. Non-negotiable constraints (license, hosting, team skills): {{constraints}}. Project context: {{context}}.
TASK: Score each option per criterion with an evidence basis: docs quote, benchmark, community data, or team experience. Mark each score's evidence quality (VERIFIED / ANECDOTAL / UNKNOWN). Identify the decisive criterion and run a sensitivity check (does the winner change if weights shift 20%?).
CONSTRAINTS: Scores without evidence must be UNKNOWN, not guessed. Do not rely on vendor benchmarks without noting the source's interest. Verify licensing and support claims against official pages. End with a concrete spike/prototype plan to close the top UNKNOWNs before committing.
OUTPUT FORMAT: Markdown: (1) Criteria and weights, (2) Scorecard with evidence column, (3) Sensitivity analysis, (4) Recommendation, (5) Spike plan with pass/fail questions, (6) Decision review date.
```

### PROMPT-07-08 — Integration Pattern Choice (Sync/Async/BFF)
**Use when:** deciding how two systems or a frontend and backend should integrate.
**Output:** a pattern decision with sequence diagrams and failure behavior.
**Prompt:**
```text
ROLE: Integration architect.
CONTEXT: Systems integrating: {{systems}}. Interaction requirements: {{requirements}} (latency SLO, who owns the data, availability coupling tolerance, consistency needs). Call patterns: {{call_patterns}}.
TASK: For each integration point choose: synchronous call (REST/gRPC), asynchronous (events/queue), or BFF aggregation. Justify via coupling and availability analysis (what happens when the dependency is down?), and produce sequence diagrams for the chosen flows including timeout/retry/fallback behavior.
CONSTRAINTS: Every synchronous chain must state its end-to-end latency budget and failure cascade. Async options must state ordering/idempotency handling. Verify protocol/library claims against docs. If {{requirements}} lacks a latency or availability number, list it as a blocking unknown.
OUTPUT FORMAT: Markdown: (1) Integration-point inventory, (2) Decision per point with rationale, (3) Mermaid sequence diagrams, (4) Failure-behavior table, (5) Blocking unknowns, (6) Migration notes if changing an existing integration.
```

### PROMPT-07-09 — Failure-Mode Analysis (FMEA-Lite)
**Use when:** proactively identifying how a system can fail before it does.
**Output:** a ranked failure-mode table with detections and mitigations.
**Prompt:**
```text
ROLE: Reliability engineer running an FMEA-lite session.
CONTEXT: System description: {{system}}. Components and dependencies: {{components}}. Existing monitoring: {{monitoring}}. Severity framework: SEV definitions {{sev_definitions}} if any.
TASK: Enumerate failure modes per component (crash, hang, corrupt output, resource exhaustion, dependency down, slow). For each: cause, local effect, user-visible effect, likelihood (label JUDGMENT unless historical data), detectability via {{monitoring}}, and mitigation (prevent / detect-and-recover / accept-with-runbook).
CONSTRAINTS: Do not list failure modes without a detection story or explicit acceptance. Likelihood ratings must state their basis (postmortem history, load-test, guess). Cap the analysis at the top risks — rank by severity x likelihood and cut the tail. Single points of failure must be flagged even if unlikely.
OUTPUT FORMAT: Markdown: (1) FMEA table (component, failure mode, cause, effect, S, L, D, RPN-like rank, action), (2) Top-5 risks with mitigation detail, (3) Monitoring gaps to close, (4) Accepted risks needing runbooks, (5) Follow-up session triggers.
```

### PROMPT-07-10 — Architecture Diagram Generator (Mermaid from Description)
**Use when:** turning a prose system description into a clean, reviewable diagram.
**Output:** Mermaid diagram(s) plus a legend and an assumptions list.
**Prompt:**
```text
ROLE: Technical illustrator producing Mermaid diagrams from prose.
CONTEXT: System description: {{description}}. Diagram purpose: {{purpose}} (onboarding, design review, incident doc). Audience: {{audience}}. Notation preference: {{notation}} if any (C4, simple flow).
TASK: Produce Mermaid source for the requested view (system context, container, or sequence). Keep nodes at consistent abstraction levels — no mixing services and functions. Label edges with protocols/mechanisms. Where the description is ambiguous, pick the most likely reading and record it in assumptions.
CONSTRAINTS: Every element must trace to {{description}} or be listed as an assumption — no invented components. Mermaid must be syntactically valid for rendering in GitHub/GitLab; avoid exotic node shapes. Max one primary diagram plus optional zoom-ins. Do not add styling that obscures structure.
OUTPUT FORMAT: Markdown: (1) Primary Mermaid code block, (2) Optional detail diagram, (3) Legend, (4) Assumptions made, (5) Review questions for the description author.
```

### PROMPT-07-11 — Bounded-Context Mapping (DDD)
**Use when:** mapping domain boundaries and the relationships between them.
**Output:** a context map with relationship patterns and ownership notes.
**Prompt:**
```text
ROLE: Domain-driven-design facilitator.
CONTEXT: Domain description: {{domain}}. Existing modules/teams: {{modules}}. Known integration points and frictions: {{integrations}}.
TASK: Identify candidate bounded contexts from the domain language (list the terms that change meaning across areas — e.g., "Order" in sales vs fulfillment). Propose context boundaries, the relationship pattern between each pair (partnership, shared kernel, customer-supplier, conformist, anticorruption layer, separate ways), and the team/ownership mapping.
CONSTRAINTS: Boundaries must be justified by language shifts or lifecycle differences, not by current code layout alone. Flag where a shared kernel is creating coupling. Where the domain info is insufficient, state "insufficient information" and list the questions/events to observe. Do not design aggregates inside contexts — that is a separate exercise.
OUTPUT FORMAT: Markdown: (1) Ubiquitous-language conflicts table, (2) Context map (Mermaid), (3) Relationship pattern per pair with rationale, (4) Ownership/team mapping, (5) Open questions for domain experts, (6) Validation plan (event storming or interview).
```

### PROMPT-07-12 — Technical-Debt Register Builder
**Use when:** cataloging technical debt so it can be prioritized instead of complained about.
**Output:** a structured debt register with interest/principal framing.
**Prompt:**
```text
ROLE: Engineering lead building a technical-debt register.
CONTEXT: Codebase or area: {{codebase}}. Known pain points: {{pain_points}}. Business roadmap: {{roadmap}} (what is coming that touches this area). Team size: {{team}}.
TASK: Convert each pain point into a register entry: description, type (code, architecture, test, infra, docs), principal (cost to fix, labeled ESTIMATE), interest (recurring cost of not fixing — dev time, incident risk, slowed features — with the evidence), and contagion (what new work it slows). Rank by interest-to-principal ratio and roadmap collision.
CONSTRAINTS: Every entry needs an evidence link or file reference — no vague "code is messy." Interest estimates must name who pays it and how often. Explicitly separate debt from "stuff we just don't like." Include a proposed pay-down slice per entry sized for one sprint or less.
OUTPUT FORMAT: Markdown: (1) Register table (ID, description, type, principal, interest, evidence, rank), (2) Top entries with pay-down plan, (3) Debt-to-avoid list (patterns to stop adding), (4) Review cadence proposal, (5) Items needing investigation before entry.
```

### PROMPT-07-13 — Scaling-Bottleneck Analysis
**Use when:** a system is nearing its limits and you need to find what breaks first.
**Output:** a ranked bottleneck analysis with scaling options per layer.
**Prompt:**
```text
ROLE: Performance architect analyzing scale limits.
CONTEXT: System architecture: {{architecture}}. Current load metrics: {{metrics}} (MEASURED preferred; label ESTIMATES). Resource ceilings known: {{ceilings}} (DB max connections, single-thread limits, partition counts).
TASK: Walk the request path and identify the limiting resource at each hop under load growth: stateless services (CPU/memory bound), database (connections, lock contention, write throughput), queues (consumer throughput, partition limits), downstream APIs (rate limits). Rank bottlenecks by which hits first at {{growth_target}} and give scaling options per layer (vertical, horizontal, caching, sharding) with cost notes.
CONSTRAINTS: Rankings require numbers — use {{metrics}} where available and label projections ESTIMATE with the formula shown. Do not propose sharding while simpler options (caching, read replicas, batching) are unexhausted. Verify any platform limit against official quotas/docs.
OUTPUT FORMAT: Markdown: (1) Request path with per-hop limits, (2) Ranked bottleneck table (order of failure, evidence, headroom), (3) Scaling options per layer, (4) Cost note per option (EFFORT small/medium/large), (5) Load-test plan to validate.
```

### PROMPT-07-14 — Single-Point-of-Failure Audit
**Use when:** auditing a system for components whose failure takes everything down.
**Output:** an SPOF inventory with redundancy options and cost.
**Prompt:**
```text
ROLE: Availability auditor.
CONTEXT: System architecture: {{architecture}}. Availability target: {{slo}}. Current redundancy mechanisms: {{redundancy}}. Deployment topology: {{topology}}.
TASK: Inventory every component and classify: redundant (failover automatic), redundant (manual), single instance but restartable, hard SPOF (stateful singletons, single region, single vendor, one person with credentials). For each hard SPOF propose redundancy or a documented accept-with-runbook decision, with effort and cost noted.
CONSTRAINTS: Distinguish process SPOFs from data SPOFs (a replica is not redundancy if it shares the corruption source). Verify managed-service HA claims against the provider's SLA/docs. Human SPOFs (single on-call, single admin) count — list them. Every accepted risk needs an owner and a detection alert.
OUTPUT FORMAT: Markdown: (1) Component inventory table (component, class, failure blast radius, detection), (2) Hard SPOF list with remediation options, (3) Accepted risks with owner + alert, (4) Priority order by blast radius, (5) Verification plan (failover drill).
```

### PROMPT-07-15 — Cross-Cutting Concerns Checklist
**Use when:** reviewing whether a system has consistent logging, tracing, config, and error handling.
**Output:** a gap checklist with conventions and adoption plan.
**Prompt:**
```text
ROLE: Platform engineer auditing cross-cutting concerns.
CONTEXT: System: {{system}}. Languages/frameworks: {{stack}}. Existing conventions (if any): {{conventions}}. Observability backend: {{observability}}.
TASK: Audit across axes: structured logging (levels, correlation IDs, no secrets), distributed tracing (propagation, sampling), metrics (RED/USE coverage, naming), configuration (env validation, secrets sourcing), error handling (retry policy, timeout discipline, user-facing errors), and API conventions (pagination, versioning, idempotency keys). Report per axis: present / partial / missing, with the gap.
CONSTRAINTS: Recommend conventions adopted by the ecosystem of {{stack}}, verified against current docs. Do not demand tooling the team cannot operate. Every gap needs a smallest-viable fix, not a platform rebuild. Include a rollout order that starts with new code.
OUTPUT FORMAT: Markdown: (1) Checklist table (axis, status, gap, smallest fix), (2) Proposed convention snippets per axis, (3) Rollout plan (new code first, then migration), (4) Definition-of-done additions, (5) Items needing codebase access.
```

### PROMPT-07-16 — Third-Party Dependency Risk Review
**Use when:** auditing SaaS/API dependencies that the system cannot afford to lose silently.
**Output:** a dependency risk register with exit strategies.
**Prompt:**
```text
ROLE: Dependency-risk analyst.
CONTEXT: Third-party dependencies: {{dependencies}} (APIs, SaaS, critical libraries). Usage depth: {{usage}} (which flows break without it). Contract terms: {{terms}} if known.
TASK: For each dependency assess: criticality (what breaks), substitutability (is there a drop-in alternative), exit cost (migration effort labeled ESTIMATE), concentration risk (same vendor across multiple functions), and monitoring (do we detect its degradation before users do?). Propose risk tiers and per-tier strategy (wrapper/abstraction layer, cached fallback, dual-vendor, documented accept).
CONSTRAINTS: Substitutability claims require evidence (existence of alternative API with feature parity) or are marked UNVERIFIED. Do not recommend building in-house replacements without an honest total-cost comparison. Include rate-limit and breaking-change monitoring in every strategy.
OUTPUT FORMAT: Markdown: (1) Dependency register (name, criticality, tier, exit cost), (2) Per-dependency strategy, (3) Abstraction-layer design where proposed, (4) Monitoring additions, (5) Accepted risks with owners, (6) Annual re-review checklist.
```

### PROMPT-07-17 — Data-Consistency Strategy (Eventual vs Strong)
**Use when:** choosing consistency levels per data flow and handling their user-visible consequences.
**Output:** a consistency map with UX mitigations and technical mechanisms.
**Prompt:**
```text
ROLE: Distributed-data architect.
CONTEXT: Data flows: {{flows}} (e.g., payment → ledger → notification). Invariants that must never break: {{invariants}}. User-visible staleness tolerance: {{tolerance}}. Storage/queue stack: {{stack}}.
TASK: Assign each flow a consistency level (strong, bounded staleness, eventual) by testing it against {{invariants}} and {{tolerance}}. For each assignment specify the mechanism (transactions, sagas with compensations, outbox pattern, read-your-writes tokens) and the user-visible staleness with its UX mitigation (pending states, optimistic UI with rollback).
CONSTRAINTS: Strong consistency must be justified by a named invariant; default to weaker where allowed. Verify mechanism support in {{stack}} docs. Every async flow needs a reconciliation/story for when the event is lost. Do not claim exactly-once semantics without a mechanism.
OUTPUT FORMAT: Markdown: (1) Flow-to-consistency map table, (2) Mechanism per flow, (3) Failure and reconciliation behavior, (4) UX staleness mitigations, (5) Invariant audit checklist, (6) Open questions.
```

### PROMPT-07-18 — Cloud Cost-Estimation Model
**Use when:** estimating the monthly cloud bill for a proposed or existing architecture.
**Output:** a cost model with line items, assumptions, and reduction options.
**Prompt:**
```text
ROLE: FinOps-aware architect building a cost model.
CONTEXT: Architecture: {{architecture}}. Usage profile: {{usage}} (requests/day, data stored, transfer, uptime hours — ESTIMATE unless measured). Cloud provider and region: {{provider_region}}. Pricing source: official pricing pages {{pricing_date}}.
TASK: Break the estimate into line items: compute, database, storage, data transfer, managed services, observability tooling. For each: usage driver, unit price (cite provider page), monthly estimate, and confidence. Sum with a stated contingency (e.g., +20% for unknowns) and identify the top-3 cost drivers with reduction options.
CONSTRAINTS: Every unit price must carry its source and date; label all usage inputs ESTIMATE with sensitivity noted (bill doubles if X doubles). Verify against {{provider_region}} pricing only. Include cost-of-idle (non-prod environments) as a line item. No invented discounts (reserved/spot) unless their commitment terms are stated.
OUTPUT FORMAT: Markdown: (1) Line-item table (item, driver, unit price + source, monthly estimate), (2) Total with contingency and confidence range, (3) Top-3 drivers with reduction options, (4) Cost guardrails to implement (budgets, alerts), (5) Re-estimate triggers.
```

### PROMPT-07-19 — Strangler-Fig Migration Path
**Use when:** replacing a legacy system incrementally without a big-bang rewrite.
**Output:** a phased migration plan with routing design and rollback per phase.
**Prompt:**
```text
ROLE: Legacy-modernization architect.
CONTEXT: Legacy system: {{legacy}} (tech, data stores, integration points). Target architecture: {{target}}. Traffic/routing layer: {{routing}} (proxy, gateway, load balancer). Seams identified: {{seams}} if any.
TASK: Design a strangler-fig plan: identify carve-out seams (features, endpoints, data subsets), sequence migrations by risk-increasing order with a reversible first phase, design the routing/facade layer (how traffic splits legacy vs new), dual-write/read-sync strategy per migrated slice, and per-phase rollback.
CONSTRAINTS: First phase must be small and reversible — no data migrations that cannot be unwound. Verify routing-layer features against {{routing}} docs. Each phase needs a parity-verification method (shadow traffic, comparison jobs) before cutover. State which legacy behaviors have no documented spec and how they will be characterized.
OUTPUT FORMAT: Markdown: (1) Seam inventory, (2) Phase plan table (phase, scope, verification, cutover, rollback), (3) Routing/facade design, (4) Data sync strategy, (5) Risks per phase, (6) Decommission criteria for the legacy system.
```

### PROMPT-07-20 — Architecture Fitness Review Against NFRs
**Use when:** checking whether a design actually meets its non-functional requirements.
**Output:** a requirement-by-requirement fitness report with evidence and gaps.
**Prompt:**
```text
ROLE: Architecture reviewer auditing NFR compliance.
CONTEXT: Architecture/design: {{design}}. NFR list: {{nfrs}} (availability, latency percentiles, durability, security, compliance, maintainability with target values). Evidence available: {{evidence}} (benchmarks, prior incidents, tests).
TASK: For each NFR: state the requirement, the architectural mechanism that satisfies it, the evidence (test result, calculation, prior measurement — labeled MEASURED/ESTIMATE/UNVERIFIED), and verdict (met / at-risk / unmet / unverifiable). For unmet items propose the smallest architectural change; for unverifiable items propose the cheapest verification.
CONSTRAINTS: Verdicts require mechanism + evidence; "should be fine" is not a verdict. Calculations shown for any derived NFR (e.g., availability from component MTBF). Do not gold-plate — flag NFRs in {{nfrs}} that are stated but never verified as a documentation gap. Verify any claimed product capability against docs.
OUTPUT FORMAT: Markdown: (1) NFR compliance table (requirement, mechanism, evidence, verdict), (2) Unmet items with fix proposals, (3) Unverifiable items with verification plan, (4) Documentation gaps, (5) Sign-off checklist.
```
