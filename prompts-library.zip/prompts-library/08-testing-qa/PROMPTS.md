# 08 — Testing & QA

Test strategy, TDD workflows, test design patterns, and quality processes. Covers unit through E2E, flaky-test management, contract testing, and risk-based prioritization.
Placeholder convention: `{{double_braces}}` mark user-supplied input (module names, test commands, acceptance criteria, coverage data). Replace every placeholder before sending; a prompt with unfilled placeholders should be treated as incomplete.

---

### PROMPT-08-01 — Unit-Test Strategy for a Module
**Use when:** planning unit tests for a module from scratch or auditing existing ones.
**Output:** a test plan with case matrix, boundaries, and faking decisions.
**Prompt:**
```text
ROLE: Test architect planning unit tests.
CONTEXT: Module under test: {{module}} (path or description). Its public interface: {{interface}}. Dependencies: {{dependencies}}. Existing tests: {{existing_tests}}. Test framework: {{framework}}.
TASK: Design a unit-test plan: enumerate behaviors (happy path, boundaries, error paths, concurrency if relevant) as a case matrix mapping each behavior to its input partitions and expected output. For each dependency decide real/fake/stub with reasoning. Identify untestable seams and propose minimal refactoring to open them.
CONSTRAINTS: Read the actual code of {{module}} before planning; behavior claims not visible in code are marked ASSUMED. Prefer fakes over mocks where behavior matters. Do not mandate coverage percentages without stating what they do and do not prove. Verification command: {{test_command}} must be named and the plan must note how to run just this module's tests.
OUTPUT FORMAT: Markdown: (1) Behavior inventory, (2) Case matrix table (behavior, partition, expected, dependency treatment), (3) Faking decisions, (4) Seams needing refactor, (5) Run commands and iteration loop.
```

### PROMPT-08-02 — TDD Red-Green-Refactor Driver
**Use when:** driving a feature implementation strictly test-first.
**Output:** a red-green-refactor session transcript with the final diff summary.
**Prompt:**
```text
ROLE: TDD pair-programming driver.
CONTEXT: Feature to implement: {{feature}}. Module location: {{module_path}}. Test framework and commands: {{framework_command}}. Related code to read first: {{related_files}}.
TASK: Enforce the loop: (RED) write the smallest failing test for the next behavior, run {{framework_command}}, confirm failure for the right reason; (GREEN) write the minimum production code to pass, run again; (REFACTOR) clean up with tests green, run again. One behavior per cycle. Continue cycle by cycle until {{feature}} is covered.
CONSTRAINTS: No production code without a failing test first. If a test fails for an unexpected reason, stop and diagnose before writing more. Read {{related_files}} before naming APIs — no invented methods. Do not refactor while red. Report test output verbatim at each stage; fabricated results are forbidden.
OUTPUT FORMAT: Per cycle: (1) Test code added, (2) RED output (verbatim, trimmed), (3) GREEN output (verbatim), (4) Refactor notes. End with: summary table (cycles, behaviors covered), final diff description, remaining gaps.
```

### PROMPT-08-03 — Integration-Test Plan (Testcontainers)
**Use when:** planning integration tests that hit real databases, queues, or APIs in containers.
**Output:** a test plan with container topology, isolation strategy, and CI notes.
**Prompt:**
```text
ROLE: Integration-test architect.
CONTEXT: System under test: {{system}}. External dependencies to integrate: {{dependencies}} (DB, broker, cache). Language/test stack: {{stack}}. CI environment constraints: {{ci_constraints}}.
TASK: Design the integration suite: which behaviors genuinely need real dependencies (vs unit-testable), container topology (compose file sketch), test isolation strategy (per-suite containers vs per-test reset), migration/seed handling, and CI performance budget with parallelism plan.
CONSTRAINTS: Verify testcontainers API usage against the current library docs for {{stack}}; mark UNVERIFIED otherwise. Each test must clean up after itself or use fresh state — no order dependence. Label CI runtime targets as ESTIMATE. Name the exact command to run the suite locally and in CI.
OUTPUT FORMAT: Markdown: (1) Behavior-to-layer table (unit vs integration), (2) Container topology sketch (compose YAML excerpt), (3) Isolation and reset strategy, (4) Test case list, (5) CI integration with commands, (6) Runtime budget table.
```

### PROMPT-08-04 — E2E Test Plan (Critical Paths Only)
**Use when:** defining a lean E2E suite that covers only what unit/integration tests cannot.
**Output:** a critical-path E2E suite with scenarios, selectors, and flake controls.
**Prompt:**
```text
ROLE: E2E test strategist.
CONTEXT: Application: {{app}} (URL or repo). Critical user journeys: {{journeys}} (login, checkout, etc.). E2E framework: {{framework}}. Test environments: {{environments}}.
TASK: Select the minimal critical paths (aim for the few journeys whose failure means "the product is down"), write scenarios in Given/When/Then, choose stable selectors (prefer role/text over CSS paths — verify what {{framework}} supports), define test data strategy (ephemeral accounts, seeded state), and bake in flake controls (automatic retries only for infrastructure errors, explicit waits).
CONSTRAINTS: Cap the suite — every proposed scenario needs a justification for why lower layers cannot cover it. No scenarios dependent on external third-party systems unless stubbed. Explicit-wait claims must match {{framework}} docs. Include quarantine rules for flaky tests.
OUTPUT FORMAT: Markdown: (1) Selected paths with justification, (2) Scenario files in Gherkin, (3) Selector conventions, (4) Test-data plan, (5) Flake-control policy, (6) CI cadence (per-merge vs nightly).
```

### PROMPT-08-05 — Test-Data Builder Patterns
**Use when:** test setup is verbose or fragile and needs builder/fixture patterns.
**Output:** builder pattern design with code sketches and validity invariants.
**Prompt:**
```text
ROLE: Test-craftsmanship coach.
CONTEXT: Domain objects under test: {{domain_objects}}. Current test setup pain: {{pain}} (verbose, invalid states, shared mutable fixtures). Language: {{language}}.
TASK: Design test-data builders: a default-valid object per domain type with overridable fields, constrained randomization where useful (seeded for determinism), and invariants that cannot be violated (e.g., order.total == sum(lines)). Show code sketches in {{language}} using idioms verified against the codebase style.
CONSTRAINTS: Read existing test code first; builders must match existing conventions rather than introduce a second style. Determinism is mandatory — any randomness is seeded. Builders must default to valid states; invalid states require explicit opt-in methods. No unapproved dependencies — use only libraries already in the project or the standard library.
OUTPUT FORMAT: Markdown: (1) Builder design per object (sketch code), (2) Invariant enforcement approach, (3) Migration plan from current setup (file by file, incremental), (4) Anti-patterns to avoid list, (5) Verification: name the test command proving builders compile and work.
```

### PROMPT-08-06 — Flaky-Test Quarantine Protocol
**Use when:** a test is flaky and you need a disciplined contain-diagnose-fix process.
**Output:** a quarantine ticket with diagnosis steps and re-entry criteria.
**Prompt:**
```text
ROLE: QA engineer running a flaky-test triage.
CONTEXT: Flaky test: {{test_name}}. Failure history: {{failure_history}} (logs, frequency). Test code: {{test_code}}. Environment: {{environment}}.
TASK: Determine the flake class: time-dependent, order-dependent, resource race, external dependency, or non-deterministic data. Quarantine the test (mark skip/quarantine per project convention), design a reproduction strategy (repeat runs, stress loop with exact command), and propose the fix with re-entry criteria (N consecutive green runs in CI).
CONSTRAINTS: Do not fix by adding retries or sleeps — diagnose root cause first; retries are only a containment measure and must be labeled as such. Verify any framework timing/wait APIs against docs. Frequency claims need {{failure_history}} numbers, not vibes. The quarantined test must have an owner.
OUTPUT FORMAT: Markdown: (1) Quarantine ticket (test, owner, date, reason), (2) Flake classification with evidence, (3) Reproduction command and loop count, (4) Root-cause hypothesis ranked, (5) Fix sketch, (6) Re-entry criteria, (7) Prevention note (what pattern allowed this).
```

### PROMPT-08-07 — Coverage-Gap Analysis
**Use when:** coverage numbers exist but you need to know what actually matters that's untested.
**Output:** a gap report distinguishing meaningful vs cosmetic gaps, with prioritized work.
**Prompt:**
```text
ROLE: Test-strategy analyst reading coverage data critically.
CONTEXT: Coverage report: {{coverage_report}} (or summary: lines/branches/functions by module). Module map: {{module_map}}. Criticality ranking of modules: {{criticality}}.
TASK: Cross-reference coverage with {{criticality}}: list critical modules with low branch coverage, and within them the untested branches that guard important behavior (error paths, boundaries) vs boilerplate. Distinguish "untested but trivially correct" from "untested and load-bearing."
CONSTRAINTS: Coverage percentage alone is not a verdict — every flagged gap needs a why-it-matters note. Verify the coverage tool's branch semantics before interpreting numbers. Do not set blanket coverage gates; propose per-module targets justified by criticality. Gaps are evidenced from {{coverage_report}}, not guessed.
OUTPUT FORMAT: Markdown: (1) Coverage-by-criticality table, (2) Top gaps ranked (module, untested behavior, risk, suggested test), (3) Gaps explicitly not worth closing, (4) Proposed per-module targets, (5) Verification command to regenerate the report.
```

### PROMPT-08-08 — Contract-Test Generator (Consumer-Driven)
**Use when:** two services integrate via an API and you want consumer-driven contract tests.
**Output:** contract test specs for both consumer and provider with CI wiring notes.
**Prompt:**
```text
ROLE: Contract-testing engineer.
CONTEXT: Consumer: {{consumer}}. Provider API: {{provider_api}} (OpenAPI spec or endpoint list). Interaction to test: {{interaction}}. Contract framework: {{framework}}.
TASK: Write the consumer-side contract (request expectations + response matchers — flexible where the consumer doesn't care), the provider-verification setup (states/fixtures the provider needs), and the CI gate design (can the provider deploy if verification fails?).
CONSTRAINTS: Matchers must be as loose as the consumer tolerates (exact matching on fields the consumer ignores creates false failures). Verify {{framework}} syntax against current docs. Provider states must not require production data. State what happens to existing untested interactions — this suite covers {{interaction}} only.
OUTPUT FORMAT: Markdown: (1) Consumer contract code, (2) Provider verification config, (3) State/fixture definitions, (4) CI gate flow (Mermaid), (5) Runbook: adding the next interaction, (6) Limitations list.
```

### PROMPT-08-09 — Mutation-Testing Review
**Use when:** coverage is high but you doubt the tests can actually catch regressions.
**Output:** a mutation-testing assessment with surviving-mutant triage.
**Prompt:**
```text
ROLE: Test-effectiveness analyst using mutation testing.
CONTEXT: Module and tests: {{module_and_tests}}. Mutation tool for {{language}}: {{tool}}. Time budget: {{time_budget}}.
TASK: Plan a mutation run: which mutators to enable, scoped to {{module}} (full-codebase runs are slow — justify scope), expected runtime (ESTIMATE from mutation count), then triage surviving mutants into: equivalent (harmless, document), killable-by-better-assertion (improve test), killable-by-new-test (add test), or revealing-a-real-bug (fix code).
CONSTRAINTS: Verify {{tool}} flags and mutator set against current docs. Survived != bad test — equivalents exist; document rather than force-kill. Time estimates labeled ESTIMATE. Do not mutate generated/vendor code. Each killed mutant class should end as a guidance note for future test writing.
OUTPUT FORMAT: Markdown: (1) Run configuration, (2) Results summary (score, runtime, scope), (3) Survivor triage table (mutant, class, action), (4) Test improvements made, (5) Re-run command and cadence proposal.
```

### PROMPT-08-10 — Property-Based Test Design
**Use when:** testing functions with huge input spaces where example tests miss edge cases.
**Output:** property-based test design with invariants, generators, and shrink strategy notes.
**Prompt:**
```text
ROLE: Property-based testing designer.
CONTEXT: Function under test: {{function}} (signature + behavior spec). Language and PBT library: {{library}}. Known invariants: {{invariants}} if any.
TASK: Identify the true properties (invariants that must hold for ALL valid inputs — e.g., round-trip encode/decode, idempotence, ordering preservation, conservation of mass), design generators that produce valid and interesting inputs (including adversarial distributions), and specify how failures are reported (minimal counterexample via shrinking).
CONSTRAINTS: Properties must be derived from the function's contract — if the contract is undocumented, state "insufficient information" and list the questions to resolve before testing. Verify generator/shrink APIs against {{library}} docs. Include at least one "meta" check that the generator produces valid inputs. Note what PBT does NOT cover here (specific business examples still need unit tests).
OUTPUT FORMAT: Markdown: (1) Property list with rationale, (2) Generator design (sketch code), (3) Validity check for generators, (4) Example run command with seed for reproducibility, (5) Boundary: what remains example-tested, (6) Failure-triage workflow.
```

### PROMPT-08-11 — Test-Smell Detector (Over-Mocking)
**Use when:** tests pass but you suspect they mock so much they test nothing real.
**Output:** a test-smell audit with coupling metrics and refactor suggestions.
**Prompt:**
```text
ROLE: Test-code reviewer hunting mock abuse.
CONTEXT: Test files: {{test_files}}. Subject under test: {{subject}}. Mocking framework: {{framework}}.
TASK: Audit for smells: tests that assert on mock interactions instead of outcomes, mocks of the class under test's collaborators that replicate the real logic (tautology), setup longer than the test body, tests that break when internals (not interfaces) change, and over-specified argument matchers. Quantify: mock-to-assertion ratio as a rough coupling indicator.
CONSTRAINTS: Read the production code alongside tests — a mock may be justified by an external boundary; only flag mocks of logic the test should exercise. Verify {{framework}} idioms against docs before proposing alternatives. Refactor suggestions must preserve what the test actually verifies. Do not convert everything to integration tests — note the cost trade.
OUTPUT FORMAT: Markdown: (1) Smell inventory per file (smell, evidence line, severity), (2) Coupling metrics table, (3) Refactor suggestions (before/after sketch for the worst 3), (4) Tests to convert to integration/real-fake, (5) Conventions to adopt (with lint rule names if they exist).
```

### PROMPT-08-12 — UAT Script Writer from Acceptance Criteria
**Use when:** turning acceptance criteria into executable UAT scripts for business review.
**Output:** UAT scripts in plain language with steps, data, and pass/fail criteria.
**Prompt:**
```text
ROLE: QA analyst translating acceptance criteria into UAT.
CONTEXT: Feature: {{feature}}. Acceptance criteria: {{criteria}}. Test environment: {{environment}}. UAT audience (technical level): {{audience}}.
TASK: Write UAT scripts: one per criterion, each with precondition/test data, numbered steps in plain language matching what a user sees on screen, expected result per step, and an unambiguous pass/fail rule. Include at least one negative path and one boundary per criterion where meaningful. Flag criteria that are not testable as written.
CONSTRAINTS: Language matched to {{audience}} — no internals, APIs, or database terms. Every criterion must map to at least one script; list any criterion that cannot be exercised and why. Test data must be realistic but synthetic. Steps must be observable in the UI — if a criterion has no visible evidence, note the instrumentation needed.
OUTPUT FORMAT: Markdown: (1) Script table per criterion (ID, title, preconditions, steps, expected, pass/fail rule), (2) Test-data sheet, (3) Untestable-criteria list with questions, (4) Sign-off block, (5) Defect-reporting template for failures during UAT.
```

### PROMPT-08-13 — Visual-Regression Setup Plan
**Use when:** introducing screenshot-based regression testing to a UI codebase.
**Output:** a setup plan with baseline strategy, threshold policy, and flake controls.
**Prompt:**
```text
ROLE: Visual-testing engineer.
CONTEXT: Frontend stack: {{stack}}. Pages/components in scope: {{scope}}. Visual tool: {{tool}}. Rendering environments (CI vs local, OS/browser matrix): {{environments}}.
TASK: Design the setup: component/page capture strategy, baseline management (how baselines are created, reviewed, updated — including the human review step for intentional changes), diff threshold policy (pixel/percent, anti-aliasing handling), and flake controls (font rendering, animation freezing, network stubbing, deterministic seeds).
CONSTRAINTS: Verify {{tool}} capabilities against current docs — do not promise cross-OS stability the tool cannot give. Baseline updates require a reviewed PR, never auto-accept. Dynamic content (timestamps, avatars) must be masked/stubbed — list the mask strategy. CI runtime labeled ESTIMATE.
OUTPUT FORMAT: Markdown: (1) Architecture (where snapshots run, storage), (2) Capture strategy per scope item, (3) Baseline lifecycle flow (Mermaid), (4) Threshold and masking policy, (5) Flake playbook, (6) Rollout plan (pilot pages first), (7) Cost/runtime estimate table.
```

### PROMPT-08-14 — Load-Test Scenario Design
**Use when:** preparing a load test that produces decision-quality results instead of vanity numbers.
**Output:** scenario definitions with arrival models, SLO checks, and honest-results policy.
**Prompt:**
```text
ROLE: Performance-test designer.
CONTEXT: System under test: {{system}} (environment — must be production-like or labeled otherwise). User journeys and their real-world mix: {{journeys}}. SLOs: {{slos}} (p95 latency, error rate). Traffic shape: {{traffic_shape}} (daily curve, peak factor).
TASK: Design scenarios: open vs closed arrival model (justify), journey mix matching {{traffic_shape}}, load steps (ramp, steady, spike, soak) with durations, pass/fail gates tied to {{slos}}, and the data/state preparation needed for realism. Specify what is measured client-side vs server-side.
CONSTRAINTS: Results from a non-production-like environment must be labeled UNREPRESENTATIVE with a stated list of differences. Verify load-tool features (arrival models, checks) against the tool's docs. Include a soak test for leak detection. Mandate raw result publication (no cherry-picked charts) and a comparison baseline run.
OUTPUT FORMAT: Markdown: (1) Scenario table (name, model, mix, duration, gates), (2) Tool configuration sketch, (3) Data prep steps, (4) Metrics collection plan, (5) Results-reporting template, (6) Abort conditions during the run.
```

### PROMPT-08-15 — Security-Regression Checklist
**Use when:** adding security regression checks to a test suite after an incident or audit.
**Output:** a security regression test checklist mapped to findings.
**Prompt:**
```text
ROLE: Security-focused QA engineer.
CONTEXT: Past vulnerabilities/audit findings: {{findings}}. Application surface: {{surface}} (APIs, auth flows, upload, admin). Test stack: {{test_stack}}.
TASK: For each finding in {{findings}}, design a regression test that would have caught it and will catch its recurrence (e.g., auth bypass attempt, IDOR probe with two users, injection payloads, authorization matrix test). Place each in the right layer (unit for encoding/sanitization, integration for authz, E2E for flow abuse) and note which are safe to run in CI.
CONSTRAINTS: Tests must use synthetic attack data only — no real credentials or PII. Payloads must come from documented classes (OWASP cheat sheets) rather than invented. Verify any security-test library against docs. Tests touching rate-limiting or WAF behavior must be marked environment-dependent. Each test links to the finding ID it protects.
OUTPUT FORMAT: Markdown: (1) Finding-to-test mapping table (finding, test, layer, CI-safe), (2) Test code sketches, (3) CI placement plan, (4) Maintenance notes (payload freshness review), (5) Gaps: findings that cannot be regression-tested and the compensating control.
```

### PROMPT-08-16 — Snapshot-Test Review
**Use when:** deciding whether existing snapshot tests are net-positive or churn machines.
**Output:** a snapshot audit with keep/observe/replace decisions.
**Prompt:**
```text
ROLE: Test reviewer auditing snapshot tests.
CONTEXT: Snapshot test inventory: {{snapshot_tests}}. Snapshot review culture: {{review_practice}} (are diffs actually reviewed?). Framework: {{framework}}.
TASK: Classify each snapshot: contract snapshot (API response shape — keep, tighten with schema validation), UI snapshot (keep only with stable rendering controls), and churn snapshot (updates accepted blindly — replace with targeted assertions). For churn snapshots propose the specific assertions that capture intent. Measure update frequency if history is available.
CONSTRAINTS: Verify {{framework}} snapshot serialization options (sorted keys, normalizers) against docs. Replacement assertions must cover the original intent, not just the happy path. Obsolete snapshots (testing deleted features) must be deleted, not updated. Frequency claims need git history evidence or are labeled ESTIMATE.
OUTPUT FORMAT: Markdown: (1) Classification table (test, class, verdict, reason), (2) Replacement assertion sketches for churn cases, (3) Obsolete deletion list, (4) Policies to adopt (review rules, update commands), (5) Verification: command to run remaining snapshot suite.
```

### PROMPT-08-17 — Chaos/Failure-Injection Plan
**Use when:** planning controlled failure-injection experiments to validate resilience.
**Output:** an experiment plan with blast-radius controls and abort criteria.
**Prompt:**
```text
ROLE: Chaos-engineering practitioner.
CONTEXT: System: {{system}}. Hypotheses to test: {{hypotheses}} (e.g., "degraded DB does not cascade"). Environment available for experiments: {{environment}}. Current dashboards/alerts: {{observability}}.
TASK: Design experiments per hypothesis: fault to inject (process kill, latency injection, dependency refusal), smallest blast radius (one instance, synthetic traffic only), steady-state metric defining "healthy," abort criteria, and expected system behavior per {{hypotheses}}. Sequence experiments from safest to most aggressive.
CONSTRAINTS: Production experiments require explicit guardrails statement (traffic %, kill switches, time windows) — if {{environment}} is not isolated, list every guardrail. Verify fault-injection tool capabilities against docs. Every experiment must have a rollback and a named observer. No experiment without a dashboard link in {{observability}}.
OUTPUT FORMAT: Markdown: (1) Experiment table (hypothesis, fault, radius, steady state, abort), (2) Per-experiment procedure, (3) Guardrails section, (4) Results log template, (5) Fix-tracking for found weaknesses, (6) Maturity progression plan.
```

### PROMPT-08-18 — QA Risk-Based Test Prioritization
**Use when:** there is more to test than time allows and you need a defensible priority order.
**Output:** a risk-ranked test queue with explicit scoring and cut line.
**Prompt:**
```text
ROLE: Test-lead running risk-based prioritization.
CONTEXT: Scope to test: {{scope}} (features/change set). Business impact by area: {{impact}}. Technical risk signals: {{risk_signals}} (churn, complexity, past defects). Time budget: {{time_budget}}.
TASK: Score each item on likelihood-of-defect (from {{risk_signals}}, labeled with evidence) and impact-of-defect (from {{impact}}), produce a ranked queue, draw the cut line at {{time_budget}}, and define what happens below the line (risk acceptance, automated-only coverage, deferred). Flag any item that cannot be scored for missing evidence.
CONSTRAINTS: Scores are JUDGMENT unless tied to evidence in {{risk_signals}} or defect history — label them. Do not let recency bias (what we just built) outweigh impact. Everything below the cut line needs an explicit risk-acceptance note with an owner. Re-scoring triggers (new defect, scope change) must be listed.
OUTPUT FORMAT: Markdown: (1) Scoring rubric, (2) Ranked queue table (item, likelihood, impact, score, evidence), (3) Cut-line decision and rationale, (4) Below-the-line disposition list, (5) Re-prioritization triggers, (6) Retrospective hooks (did the ranking predict defects?).
```

### PROMPT-08-19 — Smoke-Suite Definition
**Use when:** defining the minimal post-deploy verification suite that must pass before traffic flows.
**Output:** a smoke-suite spec with checks, thresholds, and rollback triggers.
**Prompt:**
```text
ROLE: Release engineer defining deployment smoke tests.
CONTEXT: Application: {{app}}. Deployment process: {{deploy_process}}. Critical functionality: {{critical_functions}}. Monitoring: {{monitoring}}.
TASK: Define the smoke suite: synthetic checks (health endpoints, key user reads, one write path in a sandbox) and real-signal checks (error-rate, latency, saturation from {{monitoring}}) with thresholds and observation windows. Decide gate behavior: block traffic shift on failure, with automatic rollback criteria.
CONSTRAINTS: Smoke must run fast (state the time budget) and be side-effect-safe (sandboxed writes). Thresholds for real signals must reference a baseline or be labeled ESTIMATE with a first-run calibration plan. Verify any probing mechanism against docs. Every check needs a named owner and a runbook link for when it fails.
OUTPUT FORMAT: Markdown: (1) Synthetic check list (check, command/endpoint, pass criteria), (2) Signal-based checks with thresholds and windows, (3) Gate flow (Mermaid), (4) Rollback triggers, (5) Failure runbook pointers, (6) Calibration plan for new checks.
```

### PROMPT-08-20 — Characterization Test Writer for Legacy Code
**Use when:** wrapping untested legacy behavior in tests before changing it.
**Output:** characterization tests capturing current behavior, marked known-good vs suspicious.
**Prompt:**
```text
ROLE: Legacy-code rescuer writing characterization tests.
CONTEXT: Legacy code to characterize: {{code}} (path or snippet). Intended change: {{intended_change}}. Test framework: {{framework}}. Ability to run the code: {{runnable}} (yes/no/how).
TASK: Write tests that pin the CURRENT behavior — including bugs, which are pinned then flagged, not silently fixed. Cover the paths {{intended_change}} will touch. For each observed behavior classify: clearly-intended (matches names/docs), suspicious (looks wrong — flag for human decision, do not change), and environment-dependent.
CONSTRAINTS: Never "fix" behavior during characterization — differences between code and comments are reported, not resolved. If {{runnable}} is no, provide the harness needed to make it runnable and state what cannot be verified. Seams introduced must be minimal and behavior-preserving. Verify {{framework}} APIs used against docs.
OUTPUT FORMAT: Markdown: (1) Test code blocks, (2) Behavior inventory table (behavior, classification, evidence), (3) Suspicious-behavior flags requiring human decision, (4) Seams/refactors introduced (minimal), (5) Safe-change checklist for {{intended_change}}, (6) Verification command.
```
