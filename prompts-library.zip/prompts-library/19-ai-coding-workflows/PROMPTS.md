# 19 — AI Coding Workflows

Prompts for driving coding agents safely: plan-first bootstraps, verification loops, decomposition, and session hygiene. Placeholder convention: anything in `{{double_curly_braces}}` is user-supplied input — replace it before sending; for optional context, leave the braces with an empty value rather than deleting them.

### PROMPT-19-01 — Plan-First Session Bootstrap
**Use when:** starting any nontrivial coding session with an agent.
**Output:** a plan for approval before any file is changed.
**Prompt:**
```text
ROLE: You are a senior software engineer working in my repository.
CONTEXT: Task: {{task_description}}. Repository root: {{repo_path}}. Relevant docs: {{docs_like_AGENTS_md}}.
TASK: Solve the task, but you must plan first.
CONSTRAINTS:
- Before proposing anything, read {{docs_like_AGENTS_md}} if present, and list the files you will read to understand the change; wait for my confirmation of that list.
- Then propose a plan: files to change, approach, risks, and a verification command. Do not edit any file until I reply "OK" to the plan.
- In the plan, name the exact command or test that proves the change works; if I do not provide one, propose one from the repo's existing tooling and say why.
- Do not invent APIs, flags, or file contents: verify against the code and docs you read; where verification is impossible, mark the assumption explicitly.
- Work in small steps; after each green verification, report the diff summary and the next step.
OUTPUT FORMAT:
1. File-read list for confirmation.
2. Plan (after confirmation): changes | approach | risks | verification command.
3. Progress log per step: what changed, verification result.
```

### PROMPT-19-02 — Verify-Loop Driver
**Use when:** an agent keeps claiming done without proving it.
**Output:** implementation plus an explicit red-to-green verification transcript.
**Prompt:**
```text
ROLE: You are a disciplined engineer who proves claims with commands.
CONTEXT: Feature/fix: {{task_description}}. Verification command or test: {{verification_command}}. Environment: {{environment_notes}}.
TASK: Implement {{task_description}} and verify it.
CONSTRAINTS:
- First run {{verification_command}} on the current code and show the failing/red result; if it unexpectedly passes, stop and tell me the task may already be done before changing anything.
- Make the smallest change that could turn it green, then re-run {{verification_command}}.
- Iterate until the command exits green; paste the final command output as evidence.
- If a failure is unrelated to your change, say so explicitly and show the evidence instead of silently working around it.
- Do not weaken assertions, skip tests, or broaden tolerances to force green; if a check appears wrong, flag it to me.
- Do not invent command flags; if unsure of a flag, check the tool's help or docs first.
OUTPUT FORMAT:
1. Initial red run transcript.
2. Changes made, one line each.
3. Final green run transcript.
4. Anything left unverified and why.
```

### PROMPT-19-03 — TDD Driver for a Feature
**Use when:** building a feature test-first with an agent.
**Output:** failing tests first, then implementation, then refactor with green bar.
**Prompt:**
```text
ROLE: You are doing strict test-driven development.
CONTEXT: Feature: {{feature_description}}. Existing test framework and conventions: {{test_setup}}. Codebase areas involved: {{affected_areas}}.
TASK: Build the feature via red-green-refactor.
CONSTRAINTS:
- Step 1: read the relevant existing tests in {{affected_areas}} to match conventions; list them for me before writing anything.
- Step 2: write one failing test that names the smallest visible behavior of the feature; run it and show red.
- Step 3: write the minimum implementation to green; show the green run.
- Step 4: refactor if needed, keeping the bar green; show the run again after refactoring.
- Repeat per behavior; do not write multiple failing tests at once, and do not write implementation before the red run is shown.
- Do not change unrelated code or "fix" pre-existing failures without flagging them separately.
- Match existing framework usage exactly; no invented assertion APIs.
OUTPUT FORMAT:
1. Convention files read.
2. Per behavior: test added | red transcript | implementation | green transcript.
3. Refactor notes with post-refactor green evidence.
4. Coverage of the feature checklist: behavior | tested (yes/no).
```

### PROMPT-19-04 — Read-Before-Edit Guard
**Use when:** an agent edits files it has not read or invents file contents.
**Output:** a confirmed read list, then edits with file evidence cited.
**Prompt:**
```text
ROLE: You are an engineer who never edits what you have not read.
CONTEXT: Requested change: {{change_description}}. Files I believe are involved: {{suspected_files}}.
TASK: Prepare and execute the change.
CONSTRAINTS:**
- Output your intended read list first (all files you will open before editing), and wait for my OK.
- For every file you will modify, quote the relevant existing code you based the change on, with the file path.
- If a file you expected does not exist or differs from my description, stop and report the mismatch instead of improvising.
- Propose no new API, dependency, or config key unless you found precedent for it in the read files or official docs; otherwise mark it "needs verification".
- Every edit you make gets a one-line justification citing what you read.
OUTPUT FORMAT:
1. Read list (awaits my OK).
2. Per file: evidence quote | planned edit | justification.
3. Edits applied with citations.
4. Verification command and result.
```

### PROMPT-19-05 — Parallel-Work Decomposition
**Use when:** a large task should be split into independent subtasks for parallel agents.
**Output:** a decomposition spec with isolated write surfaces and a merge order.
**Prompt:**
```text
ROLE: You are a technical lead decomposing work for parallel execution.
CONTEXT: Task: {{task_description}}. Repository layout: {{repo_layout}}. Number of workers available: {{worker_count}}. Integration points: {{integration_points}}.
TASK: Decompose into subtasks that can run in parallel without conflicting.
CONSTRAINTS:**
- Assign each subtask: scope, files it may read, files it may write, its interface contract with other subtasks, and its own verification command.
- Write surfaces must be disjoint; if two subtasks need the same file, split by symbol or sequence them instead — state which you chose and why.
- Define the integration order and who resolves interface mismatches; specify the contract check between subtasks.
- Include a shared-context brief: the 10 lines every worker needs to avoid re-deriving conventions.
- Flag subtasks that cannot be parallelized and must run sequentially with a dependency reason.
OUTPUT FORMAT:
1. Subtask table: id | scope | read | write | contract | verify.
2. Interface contracts between subtasks.
3. Merge/integration order and contract-check steps.
4. Shared-context brief.
5. Sequential-only items with reasons.
```

### PROMPT-19-06 — Context-Budget Manager
**Use when:** a long session risks context overflow and needs loading discipline.
**Output:** a load/summarize/evict plan for the session.
**Prompt:**
```text
ROLE: You are managing your own context budget in this long session.
CONTEXT: Task: {{task_description}}. Known-large surfaces: {{large_surfaces}} (logs, lockfiles, generated code). Session goal: {{session_goal}}.
TASK: Run the session under a context budget: decide what to load, skim, or summarize, and checkpoint.
CONSTRAINTS:**
- Propose a load plan before reading: full-read files, skimmable files (with what to extract), and never-load files with the reason.
- Never paste large files wholesale into reasoning; extract signatures, interfaces, or the specific lines needed and cite paths.
- After each completed step, write a checkpoint summary: state, decisions, file paths touched, next action — so the session can be compacted without loss.
- When you notice repeated re-reads of the same file, propose summarizing it to a persistent note instead.
- If the task requires full knowledge of a large surface (e.g., a lockfile change), state the minimal verification instead of full ingestion.
OUTPUT FORMAT:
1. Load plan (full | skim | skip) with rationale.
2. Running checkpoint after each step.
3. Persistent notes to keep across compaction.
4. Early warning when budget is running low with a recommended compaction point.
```

### PROMPT-19-07 — Safe-Autonomy Policy Writer
**Use when:** defining what an agent may do alone vs must confirm.
**Output:** an autonomy policy with explicit confirmation gates.
**Prompt:**
```text
ROLE: You are writing an operating policy for an autonomous coding agent in this repository.
CONTEXT: Repository: {{repo_description}}. Risky operations present: {{risky_operations}} (migrations, deploys, secrets, force-push). Team comfort level: {{comfort_level}}.
TASK: Draft the autonomy policy.
CONSTRAINTS**
- Classify operations: always-allowed (read, test, edit within task scope), allowed-with-report (commits, dependency adds), requires-confirmation (destructive commands, secrets access, migrations, push/deploy), and never (force-push to main, secret exfiltration, deleting untracked user files).
- For every requires-confirmation item, define the confirmation format: what the agent must present (command, blast radius, rollback) before I answer.
- Include a dry-run rule: destructive commands must be shown with a dry-run or diff before execution.
- Define the escape hatch: any uncertainty defaults to confirmation, stated explicitly as the default.
- Keep it enforceable: each rule is checkable, not a value statement.
OUTPUT FORMAT:
1. Policy table: operation | tier | conditions.
2. Confirmation-gate format per risky operation.
3. Default-to-confirm clause.
4. Review cadence for the policy itself.
```

### PROMPT-19-08 — Conventional Commit Writer
**Use when:** writing commit messages from a staged diff.
**Output:** conventional-commit message(s) with body explaining why.
**Prompt:**
```text
ROLE: You are writing a commit message from a real diff.
CONTEXT: Staged diff: {{diff_or_summary}}. Repo commit conventions: {{convention}}. Related ticket: {{ticket_ref}}.
TASK: Produce the commit message.
CONSTRAINTS:**
- Derive type and scope from the actual diff; if the diff mixes concerns, propose splitting into multiple commits and show the split.
- Subject line: imperative mood, under 72 characters, no period; body explains why the change exists, not what it does (the diff shows what).
- Reference {{ticket_ref}} per repo convention; do not invent a convention — check recent commit history if not provided and say what you matched.
- Never include "Co-authored-by" or generated-attribution lines unless the repo already uses them.
- Flag anything in the diff that should not be committed (debug code, secrets, artifacts) before finalizing the message.
OUTPUT FORMAT:
1. Proposed message(s) in a code block.
2. If split: proposed grouping with per-commit rationale.
3. Flags about commit-worthy content.
4. The command to stage the split groups if applicable.
```

### PROMPT-19-09 — PR Description and Review Guide
**Use when:** opening a pull request that reviewers can actually review.
**Output:** a PR description with review guide and risk callouts.
**Prompt:**
```text
ROLE: You are the PR author preparing the description.
CONTEXT: Branch/diff summary: {{diff_summary}}. Task it solves: {{task_description}}. Test evidence: {{test_evidence}}. Risky areas: {{risky_areas}}. Reviewers: {{reviewers}}.
TASK: Write the PR description and review guide.
CONSTRAINTS:**
- Structure: what/why (link {{task_description}}), how (approach in 5 lines), evidence (tests run, pasted results), risks, and rollout notes.
- Include a review guide: suggested file order, which files to skim vs read carefully, and the 3 specific questions reviewers should answer.
- State what is deliberately NOT in this PR to prevent scope-creep review comments.
- List verification steps a reviewer can run in under 5 minutes.
- If {{diff_summary}} is insufficient to describe behavior changes accurately, say "insufficient information" and list what to check in the code rather than guessing.
OUTPUT FORMAT:
1. PR description in a code block.
2. Review guide section.
3. Out-of-scope list.
4. Reviewer verification steps.
```

### PROMPT-19-10 — Code Explainer for Onboarding
**Use when:** a new developer needs to understand a file or module.
**Output:** an explanation walkthrough with concepts, flow, and follow-up reading.
**Prompt:**
```text
ROLE: You are a senior engineer onboarding a new teammate.
CONTEXT: File/module: {{file_path}}. New dev's background: {{reader_background}}. What they need it for: {{their_goal}}.
TASK: Explain the file so they can safely modify it.
CONSTRAINTS**
- Base the explanation only on code you actually read in this session; cite file and line ranges for every claim; mark anything inferred as INFERRED.
- Structure: purpose (one paragraph), key concepts/dependencies, execution flow (entry to exit), state and side effects, and the extension points where changes are usually made.
- Include a "do not touch" section: fragile or load-bearing parts with evidence from the code.
- End with 3 concrete exercises (read X, trace Y, change Z with a test) matched to {{their_goal}}.
- If the file is too large to cover honestly, propose a reading sequence instead of a shallow summary.
OUTPUT FORMAT:
1. Walkthrough with cited line references.
2. Flow diagram (ASCII or numbered).
3. Do-not-touch list with evidence.
4. Exercises and follow-up reading order.
```

### PROMPT-19-11 — Slice-a-Large-Change Planner
**Use when:** a big change must ship in reviewable, revertable slices.
**Output:** a slicing plan where every slice is independently shippable.
**Prompt:**
```text
ROLE: You are a staff engineer slicing a large change into reviewable PRs.
CONTEXT: Goal: {{overall_goal}}. Codebase areas: {{affected_areas}}. Constraints: {{constraints}} (review size, deploy cadence, feature flags).
TASK: Produce a slice plan.
CONSTRAINTS**
- Order slices so each is: small (reviewable in under 30 minutes), independently shippable (no broken intermediate states), and revertable without breaking later slices.
- Prefer mechanical-first: refactors, renames, and moves land before behavior changes so diffs stay clean.
- Use feature flags or config to keep behavior unchanged until the final slices; name the flag strategy per slice.
- Every slice gets: files touched, verification, and the risk if it must be reverted.
- If a truly safe ordering does not exist, say so and propose the minimal-risk sequencing with the coupling called out.
OUTPUT FORMAT:
1. Slice table: order | content | files | verify | flag | revert risk.
2. Dependency diagram between slices.
3. Flag/config strategy.
4. Final activation slice with end-to-end verification.
```

### PROMPT-19-12 — Mistake-to-Constraint Encoder
**Use when:** a bug escaped and you want to encode the lesson as a lasting guard.
**Output:** a rule, test, or lint check proposal plus rollout steps.
**Prompt:**
```text
ROLE: You are a reliability engineer converting an incident into a permanent guard.
CONTEXT: Bug/incident: {{what_happened}}. Root cause: {{root_cause}}. Codebase: {{repo_context}}. Existing checks: {{existing_checks}}.
TASK: Propose the guard: a regression test, a lint rule, a type constraint, or a process check — whichever prevents recurrence cheapest.
CONSTRAINTS**
- Match the guard to the failure class: missing test coverage -> regression test; allowed-but-wrong pattern -> lint rule; type confusion -> type/model constraint; human process gap -> checklist/CI gate. Justify the chosen class against alternatives.
- The guard must fail on the original bug's diff; describe how you verified that (e.g., reverting the fix in a scratch branch and seeing red).
- Avoid guards so broad they create alert fatigue; state the false-positive surface and how to bound it.
- Add a rollout: shadow/warn mode first, then enforce, with an escape hatch documented.
OUTPUT FORMAT:
1. Chosen guard class with rejected alternatives.
2. The guard itself (test code, lint rule, or check definition) as a concrete draft.
3. Verification that it catches the original bug.
4. Rollout and escape-hatch plan.
```

### PROMPT-19-13 — Codebase Orientation Brief
**Use when:** an agent (or human) first enters an unfamiliar repo.
**Output:** a repo map: structure, entry points, conventions, and gotchas.
**Prompt:**
```text
ROLE: You are mapping an unfamiliar repository for a newcomer.
CONTEXT: Repository: {{repo_path_or_description}}. My goal in the repo: {{my_goal}}. Docs present: {{docs_found}}.
TASK: Produce an orientation brief.
CONSTRAINTS**
- Ground every claim in files you actually read; cite paths; mark inferences as INFERRED.
- Cover: purpose, top-level layout (one line per directory), how to run/build/test (exact commands, verified from config files), main entry points, data flow sketch, and conventions (naming, testing, error handling) evidenced from code.
- Include a gotchas section: surprising patterns, generated code, circular dependencies — with file evidence.
- Tailor a "start here for {{my_goal}}" path: 5-8 files in reading order.
- If you cannot verify the build/test commands, say "insufficient information" and show what config file to check instead of guessing.
OUTPUT FORMAT:
1. Repo map with cited claims.
2. Verified commands section (or verification gaps).
3. Conventions and gotchas.
4. Reading path for {{my_goal}}.
```

### PROMPT-19-14 — Subsystem Tutor
**Use when:** learning a subsystem interactively with Socratic depth.
**Output:** a teaching plan with progressive questions and check answers.
**Prompt:**
```text
ROLE: You are a patient senior engineer tutoring me on a subsystem.
CONTEXT: Subsystem: {{subsystem_description}}. My current understanding: {{my_level}}. Time budget: {{time_budget}}.
TASK: Teach me the subsystem interactively.
CONSTRAINTS**
- Start by asking me 2-3 diagnostic questions to calibrate {{my_level}}; do not lecture above or below it.
- Teach in rounds: explain one concept at a time, then ask me a check question before proceeding; wait for my answer and correct misconceptions explicitly.
- Use the actual code as material: cite file and line for each concept; have me trace one real function end to end.
- Build a running mental model: after each round, update a one-paragraph "model so far" and restate it.
- If my answer reveals a gap, go back rather than push forward; name the gap precisely.
OUTPUT FORMAT:
1. Calibration questions (first message only).
2. Round structure: concept | code citation | check question | my answer | your correction.
3. Running model restatement per round.
4. Final self-test: 5 questions I should now be able to answer, with answers hidden until I respond.
```

### PROMPT-19-15 — Shell-Command Explainer
**Use when:** understanding a command before deciding to run it.
**Output:** a part-by-part explanation with risk assessment, no execution.
**Prompt:**
```text
ROLE: You are a cautious sysadmin explaining a command without running anything.
CONTEXT: Command: {{command}}. Where I found it: {{source_context}}. My environment: {{environment}}.
TASK: Explain the command and assess whether I should run it.
CONSTRAINTS**
- Break the command into parts (pipelines, flags, redirections, substitutions) and explain each with what it reads, writes, and deletes.
- Assess risks explicitly: destructive operations, network effects, permission changes, silent failure modes (e.g., rm with unquoted variables, curl | sh).
- Check flags against the tool's documented behavior for {{environment}}; if unsure of a flag, say so and give the help command to verify — do not invent flag semantics.
- Give a safer equivalent where one exists (dry-run flags, quoting, working-directory scoping).
- Do not execute, modify, or simulate side effects; explanation only.
OUTPUT FORMAT:
1. Annotated command breakdown.
2. Risk table: part | risk | severity.
3. Safer-alternative command with explanation of the difference.
4. Verify-first commands (help/man/dry-run) I can run myself.
```

### PROMPT-19-16 — Rubber-Duck Debugger
**Use when:** stuck on a bug and need structured questioning instead of answers.
**Output:** diagnostic questions in order, with hypotheses and next checks.
**Prompt:**
```text
ROLE: You are a debugging partner who asks before telling.
CONTEXT: Bug symptom: {{symptom}}. Expected vs actual behavior: {{expected_vs_actual}}. Environment: {{environment}}. What I have already tried: {{tried_so_far}}.
TASK: Debug via structured questioning.
CONSTRAINTS**
- Ask questions one at a time, ordered from cheap to expensive checks; before each question, state the hypothesis it tests.
- Never propose a fix before the evidence supports it; when I answer, update the hypothesis list explicitly (confirmed / ruled out / open).
- Keep an evidence log: each claim about the system must trace to something observed, not assumed; challenge my assumptions kindly by asking how I verified them.
- If two questions could discriminate between hypotheses, prefer the one that splits the space most evenly (falsification-oriented).
- When a root cause is identified, propose the minimal fix and the regression test together.
OUTPUT FORMAT:
1. Question 1 with its hypothesis.
2. Running hypothesis table after each of my answers.
3. Evidence log.
4. Root cause (when found) | minimal fix | regression test.
```

### PROMPT-19-17 — Change-Impact Analysis
**Use when:** before editing, mapping what the change could break.
**Output:** blast-radius report with call paths and affected tests.
**Prompt:**
```text
ROLE: You are doing pre-edit impact analysis.
CONTEXT: Proposed change: {{proposed_change}}. Entry point files: {{files_to_change}}. Codebase: {{repo_context}}.
TASK: Map the blast radius before I approve the edit.
CONSTRAINTS**
- Trace call paths from {{files_to_change}} to consumers: direct callers, interface implementations, event/callback subscribers, serialized formats, and config consumers.
- For each affected area, cite the connecting evidence (file and line); mark anything you could not trace as UNTRACED with how to trace it.
- Identify test coverage per affected area: which tests exercise it, and the gap list where no test exists.
- Classify each impact: behavior change, compile/type break, silent semantic change (serialization, ordering, defaults), or none.
- Give a recommended verification set: the minimal commands/tests that cover the traced paths.
OUTPUT FORMAT:
1. Impact table: area | connection evidence | impact class | tests covering it.
2. UNTRACED list with tracing instructions.
3. Silent-break risk section.
4. Recommended verification commands.
```

### PROMPT-19-18 — Refactor Green-Bar Protocol
**Use when:** restructuring code while behavior must not change.
**Output:** a refactor sequence with continuous verification checkpoints.
**Prompt:**
```text
ROLE: You are refactoring under a strict no-behavior-change protocol.
CONTEXT: Refactor goal: {{refactor_goal}}. Code area: {{affected_code}}. Verification baseline: {{verification_command}}.
TASK: Execute the refactor stepwise with a green bar at every step.
CONSTRAINTS**
- Step 0: capture the baseline — run {{verification_command}} and paste the result; if it is not green before you touch anything, stop and report.
- Sequence the refactor as small mechanical steps (move, rename, extract, inline); each step must be compilable and verified before the next.
- No behavior changes ride along: if you spot an unrelated bug, note it in a findings list instead of fixing it.
- After each step, run {{verification_command}} and paste the result; if a step goes red, revert that step and report rather than patching forward.
- At the end, summarize the net diff and confirm the final green run matches the baseline outcome.
OUTPUT FORMAT:
1. Baseline run transcript.
2. Step table: step | change | verification result.
3. Findings list (bugs noticed but not fixed).
4. Net-diff summary with final green evidence.
```

### PROMPT-19-19 — Session Handoff Note
**Use when:** ending a session so another agent or developer can resume without re-discovery.
**Output:** a handoff note with state, decisions, and next actions.
**Prompt:**
```text
ROLE: You are writing a handoff note at the end of a work session.
CONTEXT: Task: {{task_description}}. Work done this session: {{work_done}}. Current state: {{current_state}}. Blockers or unknowns: {{blockers}}. Next planned steps: {{next_steps}}.
TASK: Produce the handoff.
CONSTRAINTS**
- Assume the reader has zero session context: they see only this note plus the repo.
- Include: goal (one line), what changed (files, with one-line rationale each), verification state (commands run, green/red, pasted last results), decisions made and why, rejected approaches and why, and the exact next action with the command or edit to start from.
- Link every claim to evidence: file paths, commit hashes if any, command outputs.
- List explicitly what is NOT done so the reader does not assume completion.
- Keep it scannable: short sections, tables where suitable, under one page if possible.
OUTPUT FORMAT:
1. Goal and status header.
2. Changes table: file | change | why.
3. Verification transcript summary.
4. Decisions and rejected alternatives.
5. Next action: the literal first step for the reader.
```

### PROMPT-19-20 — Evidence-First Bug Hunt
**Use when:** "find the bug" requests that tempt an agent to guess-and-patch.
**Output:** a ranked list of hypotheses, each with a discriminating check, then the fix with proof.
**Prompt:**
```text
ROLE: You are hunting a bug using evidence only.
CONTEXT: Symptom: {{symptom}}. Reproduction: {{repro_steps}}. Codebase area: {{suspected_area}}. Logs/errors available: {{logs_or_errors}}.
TASK: Find the root cause; do not guess-and-patch.
CONSTRAINTS**
- Step 1: reproduce or locate the failure evidence; if you cannot, say "insufficient information" and list exactly what to collect.
- Step 2: list at least 3 distinct hypotheses ranked by prior likelihood, each with a specific check that would confirm or kill it; run the cheapest check first.
- Step 3: only after a hypothesis is confirmed by evidence, propose the minimal fix; the fix must reference the failing evidence.
- Step 4: verify with the reproduction and add a regression test that fails without the fix.
- Never patch symptoms (e.g., rescuing nulls at the crash site) without naming the upstream cause; if you must apply a defensive guard, mark it as a guard, not the fix.
- Cite file and line for every claim about the code.
OUTPUT FORMAT:
1. Reproduction/evidence summary.
2. Hypothesis table with check results.
3. Root cause with citations.
4. Minimal fix with regression test.
5. Verification transcript.
```
