# 10 — Performance

Profiling, latency analysis, caching, runtime tuning, and honest benchmarking. Covers backend and frontend performance, capacity, and performance regression prevention.
Placeholder convention: `{{double_braces}}` mark user-supplied input (system details, metrics, traces, budgets). Replace every placeholder before sending; a prompt with unfilled placeholders should be treated as incomplete.

---

### PROMPT-10-01 — Profiling Plan (CPU/Memory)
**Use when:** a service is slow or resource-hungry and you need a measurement-first profiling plan.
**Output:** a profiling plan with tools, capture commands, and analysis steps.
**Prompt:**
```text
ROLE: Performance engineer designing a profiling session.
CONTEXT: Service: {{service}} (language, runtime version). Symptoms: {{symptoms}} (high CPU, growing memory, slow requests — with any metrics). Environment: {{environment}} (prod with safeguards, staging, local).
TASK: Design the profiling plan: choose tools for CPU (sampling profiler) and memory (allocation tracking, heap snapshots) appropriate to the runtime — verify tool flags against current docs. Define capture method (on-demand vs continuous, overhead limits, {{environment}} safeguards), duration, load conditions during capture, and the analysis workflow (flamegraph reading, allocation-site ranking).
CONSTRAINTS: Measurement before hypothesis — the plan must not presume the bottleneck. Production capture needs explicit overhead and data-sensitivity notes (profiles may contain data). Tool commands must be copy-pasteable with versions matching {{environment}}. No optimization recommendations until data exists; the plan ends at analysis, findings come after.
OUTPUT FORMAT: Markdown: (1) Hypothesis table (symptom, suspected causes, how profiling confirms/refutes), (2) Tool selection with verified commands, (3) Capture protocol (when, how long, under what load), (4) Safeguards for {{environment}}, (5) Analysis procedure, (6) Decision points (what result leads to what next step).
```

### PROMPT-10-02 — Slow-Request RCA from Traces
**Use when:** a trace shows a slow request and you need a root-cause walkthrough.
**Output:** a span-by-span analysis with the critical path identified.
**Prompt:**
```text
ROLE: Distributed-tracing analyst.
CONTEXT: Trace(s): {{trace}} (span tree with durations, or exported JSON). Service map: {{service_map}}. Latency SLO: {{slo}}.
TASK: Walk the span tree: identify the critical path (longest dependency chain), decompose total latency per span vs self-time, flag anomalies (serial fan-out that could be parallel, retry storms visible as repeated spans, queueing gaps between spans), and attribute the SLO violation to its dominant contributor. Distinguish service time from network/queue time using span timestamps.
CONSTRAINTS: Claims must reference specific span IDs/durations from {{trace}} — no generic advice. Missing instrumentation (untraced gaps) must be flagged as measurement debt, not glossed. Recommendations wait until the dominant contributor is named. If {{trace}} lacks enough spans, say "insufficient information" and list the instrumentation to add.
OUTPUT FORMAT: Markdown: (1) Span-tree summary with critical path, (2) Latency decomposition table (span, total, self, % of budget), (3) Anomalies found, (4) Root-cause statement with evidence, (5) Fix hypotheses ranked (to validate with measurements), (6) Instrumentation gaps.
```

### PROMPT-10-03 — Caching-Layer Design (L1/L2/CDN)
**Use when:** adding or restructuring caching across multiple layers.
**Output:** a cache-tier design with consistency and failure behavior.
**Prompt:**
```text
ROLE: Caching architect.
CONTEXT: Data and access patterns: {{patterns}} (read-heavy keys, hot keys, sizes). Latency requirements: {{latency}}. Existing infrastructure: {{infrastructure}}. Consistency needs: {{consistency}}.
TASK: Design the tiering: in-process L1 (size limits, invalidation on deploy), shared L2 (Redis/memcached — eviction policy, TTL strategy), CDN for static/edge-cacheable responses (cache keys, vary headers, purge API). Specify stampede protection (request coalescing/locks), hot-key handling, and failure behavior per tier (L2 down → L1-only degradation story).
CONSTRAINTS: Each tier must state what it adds over the previous (else remove it). Verify library features (coalescing, etc.) against docs. TTL and size numbers are ESTIMATE with calibration plan. Consistency limits per {{consistency}} stated explicitly. Include observability (hit-rate per tier) in the design.
OUTPUT FORMAT: Markdown: (1) Tier diagram (Mermaid), (2) Per-tier design table (contents, keys, TTL, eviction), (3) Stampede/hot-key defenses, (4) Failure-mode table, (5) Hit-rate metrics plan, (6) Rollout order.
```

### PROMPT-10-04 — DB Performance Top-10 Review
**Use when:** reviewing a database's overall health and finding the worst offenders.
**Output:** a ranked top-10 problem list with fixes and measurement plan.
**Prompt:**
```text
ROLE: Database performance reviewer.
CONTEXT: Database engine and version: {{engine}}. Performance data: {{data}} (slow query log, pg_stat_statements / equivalent, table sizes, index usage stats). Application query patterns: {{patterns}}.
TASK: Rank the top 10 performance problems by total impact (frequency x per-call cost, not just slowest single query). Categorize each: missing index, bad plan (stale stats), N+1 pattern, lock contention, write amplification, bloated tables/indexes, connection churn. For each: fix, effort, and expected gain (ESTIMATE with reasoning).
CONSTRAINTS: Rankings computed from {{data}}, labeled MEASURED; projections labeled ESTIMATE. Verify each recommended fix against {{engine}} docs (e.g., concurrent index creation). Include stats-freshness and vacuum/analyze-equivalent checks before blaming queries. No fix without a before/after measurement command.
OUTPUT FORMAT: Markdown: (1) Top-10 table (rank, problem, evidence, impact, fix, effort), (2) Detailed notes for top 3, (3) Maintenance items (stats, vacuum), (4) Measurement commands for before/after, (5) Review cadence.
```

### PROMPT-10-05 — Frontend Performance Budget
**Use when:** setting or enforcing size/speed budgets for a web frontend.
**Output:** a budget table with CI enforcement plan and current-gap analysis.
**Prompt:**
```text
ROLE: Frontend performance engineer.
CONTEXT: App: {{app}} (framework, bundler). Current build stats: {{build_stats}} (bundle sizes, chunk map). Target users/devices: {{users}}. Business-critical pages: {{pages}}.
TASK: Set budgets: JS/CSS per route (with rationale tied to {{users}} device profile), Core Web Vitals targets per {{pages}}, image/asset limits, and third-party script budget. Define enforcement (build-time size checks with exact tool/config names verified against bundler docs) and a regression process (budget breach = blocked merge, with override policy).
CONSTRAINTS: Budgets derived from device/network profile of {{users}} or labeled JUDGMENT. Every budget states what happens on breach. Verify tooling (size-limit, lighthouse CI) config against current docs. Include a current-vs-budget gap table from {{build_stats}}. Distinguish blocking budgets from advisory warnings.
OUTPUT FORMAT: Markdown: (1) Budget table (resource, limit, rationale, enforcement), (2) Current gap analysis, (3) CI enforcement config sketch, (4) Breach/override process, (5) Reduction backlog ordered by impact/effort, (6) Review cadence as app grows.
```

### PROMPT-10-06 — Bundle-Splitting Plan
**Use when:** the main bundle is too large and needs code-splitting strategy.
**Output:** a splitting plan with chunk architecture and measurement.
**Prompt:**
```text
ROLE: Build-performance engineer.
CONTEXT: App: {{app}} (framework, bundler, router). Bundle analysis: {{bundle_analysis}} (webpack-bundle-analyzer or equivalent output). Largest dependencies: {{largest_deps}}.
TASK: Design the split: route-level splitting, heavy-component lazy loading (identify candidates from {{bundle_analysis}} — charts, editors, viewers), vendor chunk strategy (long-term caching vs waterfall risk), and preload/prefetch plan for likely-next routes. For each large dependency decide: lazy-load, replace, or accept with justification.
CONSTRAINTS: Verify lazy-loading APIs against the framework/bundler version docs (suspense boundaries, dynamic imports). Waterfall risk: every split must state its added request chain and mitigation (preloading). Shared-chunk configuration must not duplicate modules across chunks. Gains estimated (ESTIMATE) with before/after measurement commands.
OUTPUT FORMAT: Markdown: (1) Target chunk architecture diagram, (2) Split decision table (module, strategy, rationale), (3) Preload/prefetch plan, (4) Config changes sketch, (5) Measurement commands, (6) Watch-outs (waterfall, duplication).
```

### PROMPT-10-07 — Memory-Leak Diagnosis Steps
**Use when:** a process's memory grows unboundedly and you need a systematic diagnosis.
**Output:** a leak-diagnosis procedure with capture commands and classification tree.
**Prompt:**
```text
ROLE: Runtime-memory diagnostician.
CONTEXT: Process: {{process}} (language/runtime). Growth pattern: {{pattern}} (leak vs plateau, rate, when — under load? idle?). Heap-dump access: {{access}} (can you capture in the environment?).
TASK: Build the procedure: confirm leak vs expected caching (growth rate under steady load, GC behavior), capture heap snapshots / allocation profiles at two points (verify tool commands against runtime docs), diff-dominant retained objects, classify (unbounded cache, forgotten listeners/subscriptions, growing queues, native buffers), and map to code via allocation stack traces. Include a "likely benign" exit (plateau = cache, tune instead).
CONSTRAINTS: Do not claim "leak" without excluding cache growth — the classification tree forces the check first. Snapshot capture in production needs overhead and PII notes. Verify profiler flags against runtime version docs. Fixes must address the retaining path, not just clear symptoms.
OUTPUT FORMAT: Markdown: (1) Classification decision tree, (2) Capture commands and safeguards, (3) Diff-analysis procedure, (4) Common retaining-path patterns with fixes, (5) Benign-plateau tuning options, (6) Verification (growth curve after fix).
```

### PROMPT-10-08 — Latency-Budget Analysis (p50/p95/p99)
**Use when:** defining or auditing latency budgets across a request path.
**Output:** a per-hop budget decomposition with current-vs-budget table.
**Prompt:**
```text
ROLE: Latency-budget analyst.
CONTEXT: Request path: {{path}} (hops: LB, service, DB, downstream). End-to-end SLO: {{slo}}. Current latency data: {{measurements}} (percentiles per hop if available).
TASK: Decompose the SLO into per-hop budgets (front fraction method: budget shrinks toward downstream since multiple hops compose), compare with {{measurements}} per percentile (p50/p95/p99 behave differently — a p99 problem is tail contention, not average slowness), identify which hop consumes disproportionate tail budget, and specify tail-latency controls (timeouts, hedged requests, queue caps) per hop.
CONSTRAINTS: Budget arithmetic shown (how fractions compose to the SLO). Verify percentiles are computed correctly (histogram-based, not averages of averages — note the measurement source). Missing per-hop data is a blocking gap, stated as such. Timeout values must relate to the budget, not be arbitrary.
OUTPUT FORMAT: Markdown: (1) Budget decomposition table (hop, budget p50/p95/p99), (2) Current-vs-budget table, (3) Tail analysis per hop, (4) Controls per hop, (5) Measurement gaps to close, (6) Review triggers.
```

### PROMPT-10-09 — Connection/Queue Saturation Analysis
**Use when:** services degrade under load and saturation points are suspected.
**Output:** a saturation map with limits, monitoring, and shedding design.
**Prompt:**
```text
ROLE: Capacity-and-saturation analyst.
CONTEXT: System: {{system}}. Queue/connection topology: {{topology}} (thread pools, DB pools, broker queues). Symptoms under load: {{symptoms}} (latency climb, errors, timeouts).
TASK: Map every queueing point: its capacity (pool sizes, queue lengths, broker retention), arrival rate vs drain rate math at peak, observed saturation signals (queue depth growth, wait-time percentiles), and the cascade order when one saturates (which downstream fills next). Design backpressure/shedding per point and the observability that shows saturation building (not just failing).
CONSTRAINTS: Pool sizes and queue limits must come from actual config or be labeled UNKNOWN with the lookup command. Little's-law reasoning shown for rate-vs-capacity. Verify broker/client library backpressure features against docs. Monitoring metrics must lead failure (queue-depth alert before timeout alert).
OUTPUT FORMAT: Markdown: (1) Saturation map (Mermaid with capacities), (2) Queueing analysis table (point, capacity, peak rate, headroom), (3) Cascade order, (4) Backpressure/shedding design, (5) Lead-indicator metrics, (6) Load-test validation plan.
```

### PROMPT-10-10 — N+1 / Fixture-Heavy Test Slowdown
**Use when:** the test suite is slow and you need to find whether test-code patterns are the cause.
**Output:** a suite-speed diagnosis with ranked fixes.
**Prompt:**
```text
ROLE: Test-performance analyst.
CONTEXT: Test suite: {{suite}} (framework, total runtime, parallelization). Timing data: {{timing}} (slowest files/tests if available). Setup patterns: {{patterns}} (fixtures, DB seeding per test).
TASK: Diagnose: per-test DB setup costs (transaction rollback vs truncate vs reseed), redundant fixture building, real network/sleep calls in tests, unbounded parallelization contention, and heavy imports. Rank fixes by estimated speedup (ESTIMATE with reasoning): shared read-only fixtures, setup hoisting, replacing real waits with faked time, splitting the parallel grid by resource type.
CONSTRAINTS: Verify framework fixture lifecycle features against docs before proposing changes (scoping changes can break test isolation — isolation risk noted per fix). Speedup numbers are ESTIMATE; require before/after timing runs. Do not propose deleting tests to go faster without marking the coverage consequence.
OUTPUT FORMAT: Markdown: (1) Runtime breakdown table (if {{timing}} available), (2) Pattern findings with evidence, (3) Ranked fixes (change, risk-to-isolation, est. gain), (4) Measurement commands for before/after, (5) CI runtime budget proposal.
```

### PROMPT-10-11 — Async/Parallelization Review
**Use when:** reviewing code for unnecessary serialization of independent operations.
**Output:** a concurrency-opportunity map with safety analysis.
**Prompt:**
```text
ROLE: Concurrency reviewer.
CONTEXT: Code under review: {{code}}. Runtime: {{runtime}}. Known concurrency constraints: {{constraints}} (thread-safety requirements, ordering needs).
TASK: Identify independent operations executed sequentially: independent I/O calls, batch-able operations, pipeline-able stages, parallelizable fan-out. For each candidate: parallelization pattern for {{runtime}} (verified against docs), ordering/cancellation semantics, exception-aggregation behavior, and resource-limit guard (semaphore/cap on concurrency).
CONSTRAINTS: Parallelization must not violate ordering stated in {{constraints}} — when in doubt, flag for human decision. Verify async APIs (structured concurrency, gather/WhenAll equivalents) against {{runtime}} version docs. Each change needs the failure-semantics answer: what happens to siblings when one fails. No unbounded concurrency (state the cap).
OUTPUT FORMAT: Markdown: (1) Opportunity map (location, operations, serialization cost), (2) Pattern proposal per location (code sketch), (3) Safety analysis (ordering, errors, limits), (4) Expected gain (ESTIMATE with basis), (5) Rejected candidates and why.
```

### PROMPT-10-12 — GC/Pause Analysis (or Equivalent Runtime)
**Use when:** runtime pauses (GC or other stop-the-world events) hurt latency.
**Output:** a pause-analysis procedure with tuning options ranked by risk.
**Prompt:**
```text
ROLE: Runtime-tuning engineer.
CONTEXT: Runtime: {{runtime}} (language, version, flags). Pause symptoms: {{symptoms}} (pause frequency/duration from logs or metrics). Heap profile: {{heap_profile}} if available.
TASK: Diagnose pause sources: allocation rate analysis, young-gen sizing, promotion rate, collector choice (verify available collectors and flags against {{runtime}} version docs), allocation-site hotspots. Rank tuning options by risk (flag changes are safer than code changes; larger heaps trade memory for pause frequency). Include a "allocation diet" path (reduce churn at hot sites) with code-level suggestions.
CONSTRAINTS: Every tuning flag verified against {{runtime}} {{version}} docs — flags differ across versions. State the rollback for every flag change. Pause targets must reference the latency SLO, not be arbitrary. Label measured pauses vs estimates. Do not recommend exotic flags (off-heap, experimental collectors) without stability caveats.
OUTPUT FORMAT: Markdown: (1) Pause evidence summary, (2) Diagnosis procedure with commands, (3) Tuning option table (flag/change, expected effect, risk, rollback), (4) Allocation-diet suggestions, (5) Verification plan, (6) Monitoring to add.
```

### PROMPT-10-13 — Cold-Start Optimization (Serverless)
**Use when:** serverless functions have painful cold starts and you need a reduction plan.
**Output:** a cold-start budget breakdown with optimization ranked by effort/impact.
**Prompt:**
```text
ROLE: Serverless performance engineer.
CONTEXT: Functions: {{functions}} (runtime, memory config, package size). Cold-start data: {{measurements}} (init duration, init type breakdown if available). Platform: {{platform}}.
TASK: Decompose cold start: runtime init, dependency load (import time), config/secret fetch, connection setup. For each: optimizations verified against {{platform}} docs — package-size reduction (tree-shaking, excluding SDK bloat), lazy vs eager initialization trade (first-request hit vs warm-start speed), provisioned-concurrency economics, connection reuse across invocations, and snapshot/restore features where available.
CONSTRAINTS: Verify every platform feature (provisioned concurrency, lazy imports, runtime snapshots) against current {{platform}} docs. Memory-size vs CPU tradeoffs stated with the billing implication. Lazy-initialization proposals must state the p99 penalty on the first real request. Gains labeled ESTIMATE with measurement method (platform init-duration metric).
OUTPUT FORMAT: Markdown: (1) Cold-start budget breakdown table, (2) Optimization options ranked (impact, effort, risk), (3) Per-function recommendations, (4) Cost implications, (5) Measurement and rollback plan.
```

### PROMPT-10-14 — Image/Asset Optimization Plan
**Use when:** page weight is dominated by images and assets.
**Output:** an asset-optimization plan with format strategy and measurement.
**Prompt:**
```text
ROLE: Web-asset performance engineer.
CONTEXT: Site/app: {{app}}. Asset inventory: {{inventory}} (image counts, sizes, formats, CDN). Critical pages: {{pages}}.
TASK: Audit asset delivery: format strategy (modern formats with fallback strategy verified against target browsers of {{users}}), responsive srcset/sizes correctness, compression levels, lazy-loading below the fold (with LCP caveat — hero images must not lazy-load), font loading strategy, and CDN caching headers per asset type. Build the before/after weight table for {{pages}}.
CONSTRAINTS: Format/browser claims verified against current support data. Lazy-loading recommendations must exclude LCP candidates. Compression is lossless or visually-lossless by default — lossy changes need a quality note. Cache-header recommendations per asset fingerprinting status. Savings labeled ESTIMATE until measured.
OUTPUT FORMAT: Markdown: (1) Inventory findings table, (2) Format/delivery recommendations per asset class, (3) Before/after weight table, (4) Implementation checklist, (5) Measurement commands (Lighthouse, build stats), (6) Monitoring plan.
```

### PROMPT-10-15 — Database Lock-Contention Review
**Use when:** database throughput collapses under concurrent writes and locks are suspected.
**Output:** a contention analysis with lock-reduction plan.
**Prompt:**
```text
ROLE: Database concurrency performance engineer.
CONTEXT: Database: {{engine}}. Contention symptoms: {{symptoms}} (wait events, lock metrics, slow writes under concurrency). Hot tables/queries: {{hotspots}}.
TASK: Identify contention points: row-lock hotspots (hot counters, queue tables polled with UPDATE...SKIP TAKE patterns), lock escalation thresholds, gap/next-key lock ranges on indexes, long transactions extending lock holds. Quantify with engine lock metrics (verify metric names against {{engine}} docs). Propose reductions: smaller transaction scopes, counter sharding, append-only patterns, isolation-level downgrades where safe.
CONSTRAINTS: Isolation-level changes must name what anomaly becomes possible — no free downgrades. Verify engine-specific patterns (skip-locked queues, sharded counters) against {{engine}} docs. Fix proposals include the concurrency test that proves the gain. Metrics from {{symptoms}} labeled MEASURED; others ESTIMATE.
OUTPUT FORMAT: Markdown: (1) Contention map (resource, waiters, hold time), (2) Root-cause analysis, (3) Reduction plan ranked (change, anomaly trade-off, effort), (4) Verification load test, (5) Monitoring for recurrence.
```

### PROMPT-10-16 — Cache-Stampede Protection
**Use when:** cache misses cause thundering-herd collapses at the database.
**Output:** a stampede-defense design with failure semantics.
**Prompt:**
```text
ROLE: Caching reliability engineer.
CONTEXT: Cache usage: {{cache_usage}} (hot keys, miss cost, TTL uniformity). Current miss behavior: {{miss_behavior}} (how many concurrent misses on one key have been observed, if any). Stack: {{stack}}.
TASK: Diagnose stampede risk (uniform TTLs expiring together, hot keys, miss cost) and design defenses: request coalescing/single-flight (verify support in the cache client against docs), jittered TTLs, stale-while-revalidate and stale-if-error (with staleness budget), per-key locks with timeout. Specify behavior when the lock holder fails (stale serve vs error vs dogpile).
CONSTRAINTS: Every mechanism verified against {{stack}} docs — client support varies widely. Jitter/TTL numbers are ESTIMATE with a formula (e.g., ±10% of TTL). Staleness budgets stated in user-visible terms. Defense-in-depth order: coalescing first (cheapest), then jitter, then stale-serving. Include the load-test proving the defense.
OUTPUT FORMAT: Markdown: (1) Risk assessment, (2) Defense design per mechanism (config sketch), (3) Failure semantics table, (4) Observability (miss-storm detection), (5) Load-test proof plan, (6) Rollout order.
```

### PROMPT-10-17 — Backpressure Design
**Use when:** a fast producer can overwhelm a slow consumer and you need flow control.
**Output:** a backpressure design with bounds, signals, and overflow policy.
**Prompt:**
```text
ROLE: Flow-control systems designer.
CONTEXT: Pipeline: {{pipeline}} (producers, queues, consumers, rates). Consumer capacity (MEASURED or ESTIMATE): {{capacity}}. Overflow tolerance: {{tolerance}} (dropped, deferred, or never).
TASK: Design backpressure: bounded queues everywhere (verify bounded-queue support in the client/broker against docs), pressure-propagation mechanism (blocking, credits, polling lag), consumer-scale signal (lag-based autoscaling with the metric name verified), and overflow policy per stage per {{tolerance}} (drop with metric, dead-letter, shed by priority). Include the slow-consumer test scenario.
CONSTRAINTS: Unbounded queues/buffers are forbidden in the design — every stage has a number and a full behavior. Verify broker/client flow-control features against docs. Autoscaling claims need the metric and platform support verified. Overflow policy explicitly states what data loss (if any) is acceptable per {{tolerance}}.
OUTPUT FORMAT: Markdown: (1) Pipeline diagram with bounds (Mermaid), (2) Backpressure mechanism per boundary, (3) Overflow policy table, (4) Autoscaling design, (5) Observability (lag, drop rates, full-queue alerts), (6) Slow-consumer test plan.
```

### PROMPT-10-18 — Benchmark Harness Builder (Honest, No Cherry-Picking)
**Use when:** building a benchmark that produces trustworthy, reproducible numbers.
**Output:** a benchmark harness design with rigor checklist and reporting template.
**Prompt:**
```text
ROLE: Benchmark-methodology engineer.
CONTEXT: What is being benchmarked: {{subject}} (function, service, query). Environment: {{environment}}. Decisions the benchmark informs: {{decisions}}.
TASK: Build the harness: warmup protocol, iteration counts with statistical treatment (median + spread, not best-of), environment controls (pin versions, isolate from noisy neighbors, record machine specs), data representativeness (realistic distributions, not uniform convenience data), and a results schema (config hash, raw samples, summary stats, environment fingerprint) that allows exact reproduction.
CONSTRAINTS: Best-of-N and single-run results are forbidden in the report. JIT/GC/cache warm-up must be handled and stated. Verify timing APIs against the language docs (clock choices matter). Subject claims about competitors/alternatives require the same harness. The report must include failure runs, not just successes.
OUTPUT FORMAT: Markdown: (1) Harness design (code sketch), (2) Rigor checklist, (3) Data-generation spec, (4) Results schema (JSON), (5) Reporting template with raw-sample appendix, (6) Reproduction instructions.
```

### PROMPT-10-19 — Performance-Regression CI Gate
**Use when:** adding automated performance regression detection to CI.
**Output:** a gate design with thresholds, noise handling, and triage process.
**Prompt:**
```text
ROLE: CI performance-gate designer.
CONTEXT: Pipeline: {{pipeline}}. Benchmarks available: {{benchmarks}} (from a harness). Historical variance: {{variance}} if known. Runtime budget in CI: {{budget}}.
TASK: Design the gate: which benchmarks run per-PR vs nightly (bounded by {{budget}}), statistical comparison vs a stored baseline (distribution-aware — median and IQR, not single-point), noise handling (retry policy, environment pinning, threshold + variance gate), and the triage process for failures (reproduce locally, profile, baseline-refresh rules so baselines don't ratchet).
CONSTRAINTS: Thresholds relative to variance (e.g., >2x IQR regression), not arbitrary percentages — if {{variance}} is unknown, a calibration period is the first deliverable. Verify comparison tooling against docs. Baseline refresh requires human review. Gate must distinguish infrastructure noise (retry) from real regression (block).
OUTPUT FORMAT: Markdown: (1) Gate architecture diagram, (2) Per-benchmark CI placement table, (3) Statistical comparison spec, (4) Noise-handling policy, (5) Triage runbook, (6) Calibration plan, (7) Rollout (advisory mode first).
```

### PROMPT-10-20 — Capacity Headroom Report
**Use when:** reporting how much growth the current system can absorb before action is needed.
**Output:** a headroom report with confidence levels and action triggers.
**Prompt:**
```text
ROLE: Capacity analyst producing a headroom report.
CONTEXT: System: {{system}}. Current metrics: {{metrics}} (utilization per resource — MEASURED preferred). Growth forecast: {{forecast}} (rate, source confidence). Bottleneck analysis: {{bottlenecks}} if it exists.
TASK: Compute headroom per resource: current utilization, safe ceiling (with stated safety margin), headroom = ceiling - current, time-to-ceiling at {{forecast}} growth (show arithmetic). Assign confidence per line (MEASURED inputs vs ESTIMATE forecast). Produce the action table: what to do at 60/80/100% ceiling with lead times.
CONSTRAINTS: Every number shows its derivation; forecast confidence is stated, not implied. Non-linear cliffs (connection limits, partition counts, license limits) must be listed as discrete events in the timeline, not smoothed. Recommendations include procurement/implementation lead time. If {{metrics}} is missing for a resource, that resource is reported as UNKNOWN, not assumed healthy.
OUTPUT FORMAT: Markdown: (1) Executive summary (3 lines), (2) Headroom table per resource (current, ceiling, margin, headroom, time-to-ceiling, confidence), (3) Cliff events timeline, (4) Action triggers table (threshold, action, lead time, owner), (5) Data-quality notes, (6) Re-report cadence.
```
