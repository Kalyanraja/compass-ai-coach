# 05 — API Design

Prompts for designing, documenting, securing, and evolving HTTP/GraphQL APIs: resource modeling, error standards, versioning, webhooks, and developer experience.
Replace every `{{placeholder}}` with your API specifics (base URL, spec files, code paths). Coding prompts use a plan→approve→edit→verify loop; spec claims must be checked against real code or docs.

### PROMPT-05-01 — REST Resource Design Review
**Use when:** an API surface exists (or is drafted) and needs a resource-modeling review.
**Output:** a findings report against REST conventions with a redesigned model.
**Prompt:**
```text
You are an API architect reviewing REST resource design.
CONTEXT: API: {{description_or_openapi_path}}. Consumers: {{internal_public_partners}}. Domain: {{business_domain}}. Existing conventions (if any): {{style_guide_or_nothing}}.
TASK: Review against a stated standard set: nouns-not-verbs in paths, correct pluralization, proper nesting depth (max 2 levels, sub-resources justified), HTTP method semantics (PATCH vs PUT, 204 vs 200, 201 + Location), idempotent GETs, filtering/sorting/pagination params on collections, and consistent naming (kebab-case, casing of fields). For every deviation: quote the actual endpoint, explain the problem, and show the proposed shape.
RULES: Read the actual spec/code before citing endpoints — no findings without a quoted path. Where REST purity conflicts with practical consumer needs, propose the pragmatic option and flag the trade-off rather than silently choosing.
Do not redesign unrelated working endpoints. Do not propose breaking changes without a migration note.
OUTPUT: markdown findings table (endpoint | rule | severity | issue | proposed shape), then a redesigned path tree for the affected resources and a migration note for breaking deltas.
```

### PROMPT-05-02 — Error-Response Standard (RFC 7807)
**Use when:** API errors are inconsistent and need a standard problem-details shape.
**Output:** an error standard doc plus implementation of the agreed handler.
**Prompt:**
```text
You are an API engineer standardizing errors on RFC 7807 (problem details).
CONTEXT: Stack: {{language_framework}}. Existing error responses: {{samples_or_code_path}}. Error catalog known: {{domain_errors_or_none}}. Consumers: {{who_parses_errors_and_how}}.
TASK: Define: the problem+json envelope (type, title, status, detail, instance, plus agreed extension fields like error_code/trace_id), the error-code taxonomy (format `{{domain}}.{{resource}}.{{reason}}`, registry table with each code's HTTP status and retryability), guidance on when to add extension fields, and security rules (never leak internals/stack traces; consistent 401/403/404 timing). Then implement the shared error handler/mapper per the plan.
RULES: Verify the framework's actual error-handling hooks before implementing (read the codebase). Validation errors get a standard shape for field-level failures. Every status code choice justified against a one-line rule (404 for unknown resource, 409 for state conflict, 422 for semantic validation...).
Do not break existing error parsing without a version note. Do not expose internal exception messages in `detail`.
OUTPUT: standard doc (envelope JSON, code registry table, status decision rules), diff of the handler, and example responses for 4 canonical failures.
```

### PROMPT-05-03 — Pagination Strategy
**Use when:** a collection endpoint needs pagination designed for the right access pattern.
**Output:** a pagination design doc with contract examples.
**Prompt:**
```text
You are an API designer choosing and specifying pagination.
CONTEXT: Endpoint(s): {{resources}}. Access patterns: {{jump_to_page_infinite_scroll_sync_export}}. Data characteristics: {{volume_growth_mutation_rate}}. Consumer type: {{web_mobile_partner}}.
TASK: Decide between offset/limit (justify: simple, needed for jump-to-page; fails at depth), cursor-based (justify: stable under writes, required for infinite scroll), or keyset — and specify the full contract: request params, response envelope (items + next_cursor/prev_cursor or page/total), total-count policy (expensive counts? omit or behind param?), cursor encoding (opaque vs documented, verification of tamper-safety), consistency semantics (what a cursor means after writes), and maximum page sizes.
RULES: The decision table must score the actual access patterns given, not generic pros/cons. Cursor stability under concurrent writes must be addressed explicitly (label the guarantee level). If total counts are skipped, state what UI patterns that breaks.
Do not add both offset and cursor to the same endpoint without justification. No unbounded defaults.
OUTPUT: decision table, full contract spec with JSON examples (first page, last page, cursor-expired case), and implementation notes (index requirements for the chosen sort key).
```

### PROMPT-05-04 — OpenAPI Spec Generator from Code
**Use when:** code exists but the OpenAPI spec is missing or stale.
**Output:** a plan, then a spec derived from the actual code.
**Prompt:**
```text
You are an API tooling engineer generating an accurate OpenAPI 3.x spec from code.
CONTEXT: Repo: {{repo_path}}. Framework: {{fastapi_express_spring_etc}}. Existing spec (if any): {{path_or_none}}. Routes source: {{controllers_routers_location}}.
TASK: Step 1 — read the route definitions, request/response models, validation schemas, auth middleware, and status codes actually implemented; list routes and models you found with file references. WAIT for approval of coverage. Step 2 — write the OpenAPI spec (or update the existing one) matching reality: every path, method, parameter, request body schema, response schema per status code, security scheme, and server URLs.
RULES: The spec must describe the code, not an idealized version — anything aspirational goes under a separate `x-planned` extension or is excluded. Schema property types constrained by validators must be captured (format, min/max, required). Verify the framework's spec-generation tooling first — if it can emit a base spec, hand-refine that instead of writing from scratch.
Do not document endpoints that don't exist. Do not loosen schema constraints to make examples pass.
OUTPUT: coverage list, then the spec file diff, plus a validation command ({{lint_or_validate_command}}) run result.
```

### PROMPT-05-05 — OpenAPI-First Code Scaffold
**Use when:** an OpenAPI spec is authoritative and server code must be scaffolded from it.
**Output:** a plan, then generated stubs wired to the spec.
**Prompt:**
```text
You are a backend engineer scaffolding server code from an authoritative OpenAPI spec.
CONTEXT: Spec: {{openapi_path}}. Target stack: {{framework_and_language}}. Existing codebase: {{greenfield_or_repo_path}}. Stub policy: {{throw_not_implemented_or_mock_data}}.
TASK: Step 1 — validate the spec (structure, $refs resolve, no contradictory schemas) and report issues before generating anything. WAIT for approval after presenting the generation plan (tool or manual, file layout, type generation, validation middleware). Step 2 — scaffold: route handlers matching every operation (typed request/response models generated from schemas), request validation middleware that rejects spec-violating payloads with RFC 7807 errors, auth hooks per the spec's security schemes, and 501/mocked responses per stub policy.
RULES: Generated types/handlers must be regenerable from the spec — no hand-edits inside generated files. Verify the generator/middleware library's actual version and config against its docs. Validation behavior must reject unknown fields only if the spec says additionalProperties: false.
Do not modify the spec to fit code; fix the code. No new dependencies without approval.
OUTPUT: spec validation findings, plan, scaffolded file tree + key diffs, and verification via {{test_command}}.
```

### PROMPT-05-06 — Versioning Policy
**Use when:** the API must evolve without breaking consumers and needs a versioning decision.
**Output:** a versioning policy document with decision and migration mechanics.
**Prompt:**
```text
You are an API governance lead defining the versioning policy.
CONTEXT: API: {{scope}}. Consumers: {{count_and_types_mobile_partners_internal}}. Breaking-change tolerance: {{can_force_upgrade?}}. Current state: {{versioned_already_or_v1_forever}}. Release cadence: {{frequency}}.
TASK: Decide and document: versioning mechanism (URL path /v1 vs header-based — with the trade-off table: CDN caching, browser-friendliness, gateway complexity), what counts as breaking (response field removal/type change, behavior change, error-code change — vs safe additive changes), the deprecation mechanics (sunset headers per RFC 8594 or metadata field, notice periods by consumer criticality), and how long versions are supported (N-1 policy? date-based?).
RULES: The decision table must use this API's actual consumer constraints (mobile apps can't force-upgrade → long support tails) rather than generic advice. Every policy claim about headers/standards must cite the RFC or be marked NEEDS VERIFICATION.
Do not version what additive evolution handles. Do not promise unlimited old-version support without cost acknowledgment.
OUTPUT: markdown policy (mechanism + trade-off table, breaking/safe change lists with examples, deprecation timeline mechanics, support policy), plus a consumer-communication template.
```

### PROMPT-05-07 — Idempotency-Key Design
**Use when:** mutating endpoints can be retried and must not double-apply.
**Output:** an idempotency design plus implemented middleware/handler.
**Prompt:**
```text
You are a backend engineer implementing idempotency keys.
CONTEXT: Stack: {{language_framework}}. Endpoints in scope: {{payment_like_mutations}}. Client retry behavior: {{who_retries_network_or_user}}. Storage available: {{redis_db_none}}. Key source: {{client_generated_header}}.
TASK: Design the mechanism: key format/uniqueness contract, the idempotency record lifecycle (in-progress lock → stored response, TTL), replay semantics (same key + same payload → return stored response; same key + different payload → 409), concurrent-request locking, and which endpoints are in scope (safe retries only — define the exclusion rule for non-idempotent-by-nature ops). Implement the middleware and wire it to the chosen endpoints.
RULES: Verify the storage layer's atomic primitives (SET NX, transactions) actually used against its docs — no invented flags. The in-progress state must eventually expire (deadlock prevention) — specify the TTL and lock-release path. Verification must include a concurrency test (parallel same-key requests → exactly one execution).
Do not make GET/DELETE idempotency-keyed (they already are). Do not store response payloads containing secrets.
OUTPUT: design doc (state machine ASCII, TTL table), diff, and test results proving single-execution under retries and concurrency.
```

### PROMPT-05-08 — Rate-Limiting Design
**Use when:** an API needs rate limiting designed and implemented correctly.
**Output:** a rate-limit design with implemented enforcement.
**Prompt:**
```text
You are an API platform engineer designing rate limiting.
CONTEXT: Stack: {{gateway_or_app_level}}. Storage: {{redis_in_memory_none}}. Consumer classes: {{anon_authenticated_premium_partner}}. Abuse patterns of concern: {{scraping_burst_costly_endpoints}}. Client ecosystem: {{can_clients_handle_429_and_retry_after?}}.
TASK: Design: algorithm choice per class (fixed window vs sliding window vs token bucket — decision table against the stated abuse patterns), limit dimensions (per-key/IP/account/endpoint-cost), headers contract (RateLimit-* draft/standard fields, Retry-After on 429 — verify current header conventions), quota policy numbers (labeled ESTIMATE with basis, or from real traffic data), and behavior on limiter failure (fail-open vs fail-closed decision with reasoning). Implement the chosen design.
RULES: The enforcement must be atomic (verify the Redis Lua/transaction pattern actually used). Header semantics verified against the current RateLimit field RFC status — mark anything draft as such. Cost-based limits must define the cost table explicitly.
Do not return 200 with an error body when limiting — proper 429. Do not let one hot key starve the shared limiter without a decision on that.
OUTPUT: design table (class | algorithm | limits | headers), diff, and load-test or unit verification results.
```

### PROMPT-05-09 — Webhook Design (Signing, Retries)
**Use when:** the API emits webhooks and the delivery contract must be production-grade.
**Output:** a webhook system design plus implemented signature/retrieval endpoints.
**Prompt:**
```text
You are a platform engineer designing a webhook delivery system.
CONTEXT: Stack: {{language_framework}}. Events: {{event_catalog}}. Receiver ecosystem: {{customer_endpoints_quality_expectations}}. Delivery infra: {{queue_workers_available}}. Secret management: {{how_signing_secrets_are_stored_rotated}}.
TASK: Design: payload envelope (event id, type, occurred_at, data), signature scheme (HMAC-SHA256 over timestamp+body, timestamp tolerance window against replay, secret rotation with dual-signing grace period — verify the exact construction), the consumer verification snippet (per {{consumer_languages}}), delivery semantics (at-least-once with idempotency on event id, retry schedule with backoff + jitter, dead-letter after N attempts, manual redelivery endpoint), and endpoint registration/management API.
RULES: At-least-once must be stated honestly with consumer idempotency as the requirement. Signature construction verified against current best practice (raw body signing, not re-serialized JSON). Retry schedule numbers labeled CHOSEN VALUES with rationale (not magic defaults presented as standards).
Do not sign only the payload without the timestamp. Do not promise exactly-once. No new dependencies without approval.
OUTPUT: design doc (envelope JSON, signature spec with verification snippet, retry state machine), API for endpoint management, diff of sender/verification code, test results.
```

### PROMPT-05-10 — GraphQL Schema Review (N+1, Pagination)
**Use when:** a GraphQL schema needs review for performance and conventions.
**Output:** a schema findings report with fixes.
**Prompt:**
```text
You are a GraphQL architect reviewing a schema for production readiness.
CONTEXT: Schema: {{sdl_or_code_path}}. Data layer: {{dataloader_or_none}}. Client usage: {{queries_seen_or_unknown}}. Scale concerns: {{deep_nesting_list_fields}}.
TASK: Review: schema design conventions (nullability discipline — nullable vs non-null and the migration implications, input types for mutations, union/error patterns vs throwing), the N+1 surface (list fields resolving per-item DB calls — check resolvers for DataLoader or batching, verify what's actually implemented), pagination of every list field (Relay connections vs offset — must be consistent; unbounded lists flagged), query-cost exposure (depth/complexity limits present?), and mutation design (single-field mutations, returning updated objects).
RULES: Read the actual resolvers before claiming N+1 — cite file and resolver. Convention findings quote the SDL. Every performance finding labeled with its trigger (which query shape). Where client usage is unknown, mark impact as NEEDS USAGE DATA instead of guessing.
Do not add DataLoader blindly if a batching layer exists. Do not change nullability in ways that silently break clients without a deprecation path.
OUTPUT: findings table (area | location | issue | severity | fix), fixed SDL/resolver diffs, and verification via {{test_command}}.
```

### PROMPT-05-11 — API Naming/Conventions Lint
**Use when:** an OpenAPI spec or codebase drifts from naming conventions.
**Output:** a lint findings report with auto-fix where safe.
**Prompt:**
```text
You are an API standards enforcer linting against a conventions doc.
CONTEXT: Target: {{openapi_spec_or_codebase_path}}. Conventions: {{paste_rules_or_default_casing_pluralization_kebab}}. Severity policy: {{error_vs_warn_per_rule_class}}.
TASK: Check every name in scope: path segments (kebab-case, plural nouns, no verbs), query params (snake vs camel — must match the declared convention consistently), field names (casing consistency, no abbreviations from the ban-list, no reserved-word collisions), enum values (SCREAMING_SNAKE vs kebab per convention), and operation IDs (verb-noun, unique). Report each violation with location, rule, and suggested rename; auto-fix mechanical renames in a way that's reviewable (no semantic changes).
RULES: The convention source is authoritative — where the target predates a rule, mark LEGACY (grandfather with date) instead of rewriting history. Renames that break wire compatibility must be flagged BREAKING, never silently fixed.
Do not invent new conventions mid-lint. Do not rename domain terms that appear in external docs without flagging the coordination cost.
OUTPUT: findings table (location | current | rule | severity | suggested), diff of safe fixes, and a remaining-manual-decisions list.
```

### PROMPT-05-12 — Breaking-Change Detector (Diff Two Specs)
**Use when:** comparing an old and new OpenAPI spec to classify every change.
**Output:** a change-classification report with risk levels.
**Prompt:**
```text
You are an API compatibility checker diffing two OpenAPI specs.
CONTEXT: Old spec: {{path_or_version}}. New spec: {{path_or_version}}. Consumer sensitivity: {{strict_generated_clients_lenient_frontend}}.
TASK: Produce a semantic diff, not a textual one — classify every change: BREAKING (removed/renamed endpoint, removed field, tightened validation, changed field type/format, new required field, removed enum value, auth changes), RISK-ASSUMED (added enum value, new optional field — fine unless strict validators), or SAFE (new endpoints, new optional params, docs-only). For each: quote old vs new schema fragment, affected consumers (generated SDKs, strict validators, loose JS clients), and recommended handling (version bump, deprecation period, changelog entry).
RULES: Classification must consider realistic client behavior — a new required request field is breaking; a new response field is flagged for strict-schema clients. Where behavior can't be determined from the spec (e.g., default value changes in code), list it as NEEDS CODE VERIFICATION with the exact place to check.
Do not mark additions breaking without the strict-client caveat. Do not miss `additionalProperties: false` tightening.
OUTPUT: markdown table (change | old | new | class | affected consumers | action), summary counts, and a release-note draft paragraph.
```

### PROMPT-05-13 — SDK Generation Review
**Use when:** an SDK is generated from an OpenAPI spec and needs quality review before shipping.
**Output:** a review report with fixes to generator config or spec.
**Prompt:**
```text
You are an SDK-quality reviewer for a generated client.
CONTEXT: Spec: {{openapi_path}}. Generator: {{openapi_generator_fern_stainless_etc}}. Generated SDK: {{repo_or_path}}. Target languages: {{langs}}. Hand-edits so far: {{none_or_list}}.
TASK: Review the generated output: naming idiomaticity for the target language (verify against that language's conventions, not the generator's defaults), error types (does the SDK surface typed errors or raw HTTP?), pagination ergonomics (auto-pagination helpers for cursor APIs?), retry/idempotency-key plumbing (can callers pass idempotency keys?), auth ergonomics, and consistency with the spec (regeneration drift — diff against a fresh generate run if tooling available).
RULES: If the fix belongs in the generator config/templates vs the spec vs hand-edits, say which layer — hand-edits to generated code get overwritten. Verify generator capabilities from its actual docs/version before recommending config keys. Every finding: file, issue, layer, fix.
Do not hand-edit generated files. Do not add features the spec can't express without noting the spec needs to change.
OUTPUT: findings table (area | issue | layer | fix), config/spec diffs, and a regeneration + verification run result.
```

### PROMPT-05-14 — Auth Design (OAuth2/OIDC Flows)
**Use when:** choosing and specifying the auth flow for an API or client integration.
**Output:** a flow decision doc with implementation checklist.
**Prompt:**
```text
You are an identity engineer designing the auth architecture.
CONTEXT: System: {{api_app_resource_server}}. Client types: {{spa_mobile_server_m2m}}. Identity provider: {{auth0_keycloak_cognito_custom}}. Sensitivity: {{data_classification}}. Existing auth: {{sessions_jwt_none}}.
TASK: Select flows per client type with the official-criteria decision table: authorization code + PKCE (SPA/mobile — verify PKCE as current required practice for public clients), client credentials (M2M), BFF pattern consideration for SPAs (token storage problem — verify the current recommendation), token format (JWT access tokens vs opaque + introspection, stateless vs revocation trade-off), refresh strategy, and scopes/claims design. Then produce the implementation checklist per selected flow (endpoints, redirect URI rules, state/nonce handling, token storage rules per client type).
RULES: Verify current specs/ Best Current Practice (OAuth 2.0 Security BCP, OIDC core) for every claim — cite the BCP/spec section or mark NEEDS VERIFICATION. Storage rules must follow platform guidance (no tokens in localStorage for SPAs per BCP — flag if current codebase does this).
Do not design the implicit/password grants. Do not roll custom token formats. No new dependencies without approval.
OUTPUT: decision table per client type, flow sequence descriptions, security checklist, and integration-question list for the IdP config.
```

### PROMPT-05-15 — API Security Review Checklist
**Use when:** an API needs a pre-release security pass across the OWASP API Top 10.
**Output:** a severity-ranked findings report with fixes.
**Prompt:**
```text
You are an API security engineer running a structured review.
CONTEXT: API: {{spec_code_base_url}}. Stack: {{language_framework}}. Auth in place: {{mechanism}}. Exposure: {{public_internal}}. Sensitive operations: {{payments_pii_admin}}.
TASK: Review against OWASP API Top 10 (current edition): BOLA (object-level authorization — every /resource/{id} handler checks ownership; quote the actual access-check code), broken authentication (token validation, expiry, algorithm confusion), excessive data exposure (responses returning more fields than needed — compare schema vs queries), unrestricted resource consumption (no limits on payload sizes, batch endpoints, expensive queries), SSRF (any user-supplied URLs fetched), unsafe consumption of external APIs, and misconfigured security headers/CORS. For each: evidence from the actual code, severity, fix.
RULES: Read the real handler/middleware code before claiming a control exists or is missing — cite file and function. Anything not verifiable from provided material goes to a manual-verification list with the exact test (e.g., replay a token against another user's resource ID).
Do not report theoretical issues as confirmed without the test. Do not "fix" by disabling features.
OUTPUT: findings table (OWASP category | location | evidence | severity | fix), manual-test backlog, and an overall ship/no-ship recommendation.
```

### PROMPT-05-16 — Deprecation/Migration Plan
**Use when:** an API version, endpoint, or field must be retired gracefully.
**Output:** a deprecation plan with comms and enforcement stages.
**Prompt:**
```text
You are an API lifecycle manager planning a graceful deprecation.
CONTEXT: Being deprecated: {{endpoint_field_version}}. Usage data: {{traffic_per_consumer_or_unknown}}. Replacement: {{new_thing}}. Consumer types: {{mobile_partners_internal}}. Enforcement power: {{can_block?}}.
TASK: Produce: the deprecation announcement (what/why/deadline/replacement + migration guide outline), usage-monitoring plan (how we know who's still calling — verify the observability exists; if usage data is unknown, state "insufficient information" and how to get it), staged enforcement (warning header/response field → error with opt-in override → hard removal, with durations justified per consumer type — mobile apps need long tails), and the migration guide structure for the replacement.
RULES: Timeline must be justified by usage data or stated as a policy choice, not invented. Sunset headers (RFC 8594) only if verified supported by the infra. Every stage needs a measurable exit criterion (remaining call count threshold).
Do not set a hard date without announcing it in responses/headers first. Do not deprecate without a documented replacement path.
OUTPUT: markdown plan (stages with dates/criteria table), comms templates (announcement + warning-state notice), migration guide outline.
```

### PROMPT-05-17 — Mock Server from Spec
**Use when:** frontend/consumer development needs a mock server running from the OpenAPI spec.
**Output:** a running mock setup with realistic data rules.
**Prompt:**
```text
You are a tooling engineer standing up a spec-driven mock server.
CONTEXT: Spec: {{openapi_path}}. Preferred tool: {{prism_mockserver_wiremock_custom}}. Consumer needs: {{frontend_development_contract_tests}}. Dynamic behavior needed: {{stateful_scenarios_error_injection}}.
TASK: Set up the mock per the chosen tool (verify its actual config format from current docs): all endpoints responding per spec schemas, example prioritization (examples from spec first, then schema-generated), stateful behavior if required (create→get consistency — specify the mechanism: in-memory store vs canned scenarios), error-path simulation (how to trigger 4xx/5xx per endpoint), and latency simulation config. Include the run commands and a smoke-test script hitting N endpoints.
RULES: Generated data must respect schema constraints (formats, enums, required) — verify with schema validation, not eyeballing. If the tool can't do statefulness, say so and provide the minimal custom layer instead of over-claiming.
Do not mock endpoints missing from the spec without flagging them as divergences. No new dependencies without approval.
OUTPUT: config files, run instructions, the state/error-simulation rules, and smoke-test output.
```

### PROMPT-05-18 — Contract Test Generator
**Use when:** provider/consumer contract tests must be generated from the OpenAPI spec.
**Output:** a contract-test suite with provider verification wiring.
**Prompt:**
```text
You are a testing engineer building contract tests from an OpenAPI spec.
CONTEXT: Spec: {{openapi_path}}. Provider stack: {{framework}}. Test framework: {{jest_pytest_pact}}. Environments: {{ci_local}}. Provider state: {{real_service_or_test_instance}}.
TASK: Generate: consumer-side contract tests (one per operation, asserting request shapes and response status + schema compliance), provider-side verification (every operation exercised and response validated against the spec — via the framework's validation middleware or explicit schema assertions, whichever the stack actually supports), and the CI wiring sketch (contract check as a gate). Each test maps to a spec operationId.
RULES: Tests must fail on spec violations, not just 2xx (negative cases: wrong types, missing required fields, invalid enums). Verify the chosen contract tooling's real API from its installed version/docs — no invented config keys. If the provider uses a validation middleware, contract verification may be redundant — state that and pick the cheaper correct path.
Do not write tests that assert implementation internals. Do not skip error-status operations.
OUTPUT: test file tree, sample test for one happy + one error operation, the operationId→test mapping table, and {{test_command}} results.
```

### PROMPT-05-19 — Performance Budget for Endpoints
**Use when:** defining and enforcing latency budgets per endpoint class.
**Output:** a budget table plus measurement/enforcement plan.
**Prompt:**
```text
You are an SRE defining API performance budgets.
CONTEXT: API: {{scope}}. Current telemetry: {{p50_p95_traces_or_none}}. Endpoint classes: {{list_with_criticality}}. Infra: {{compute_db_caching_state}}. Consumers: {{sync_mobile_ui_blocking}}.
TASK: Define per endpoint class: p50/p95/p99 targets (labeled ESTIMATE with the basis — e.g., derived from DB query plans — or TBD pending measurement, with the measurement method), the error-budget/alert policy (SLO burn rules), the load assumptions (RPS at peak — from data or stated assumption), and headroom rules (budget must include cold-start/cache-miss worst case). Then specify enforcement: where timing is measured (middleware/trace spans), and what happens on breach (alert → block release?).
RULES: No budget number without a stated derivation or an explicit "initial guess, recalibrate after 2 weeks of data". N+1 endpoints get a query-count budget alongside latency. Measurement definitions must be precise (server-side receipt→response vs including network).
Do not set uniform budgets ignoring class criticality. Do not promise p99 targets on shared noisy infra without stating the assumption.
OUTPUT: markdown budget table (endpoint class | p50 | p95 | p99 | derivation | alert policy), measurement wiring spec, and a recalibration plan.
```

### PROMPT-05-20 — Developer-Portal Documentation Set
**Use when:** an API needs its complete public documentation set written.
**Output:** the full doc structure with key pages drafted.
**Prompt:**
```text
You are a developer-experience writer producing the API documentation set.
CONTEXT: API: {{name_base_url_spec}}. Audience: {{integrator_skill_level}}. Auth method: {{mechanism}}. Unique/dangerous parts: {{webhooks_rate_limits_idempotency}}. Existing docs (if any): {{current_state}}.
TASK: Produce the set: getting-started (base URL, auth setup with copy-paste request, first call in 5 minutes), guides (authentication deep-dive, pagination walkthrough, error handling with the retry table, idempotency usage, rate limits and backoff), the API reference structure (per-resource pages generated/templated from the spec — do not hand-duplicate the spec, link it), changelog policy page, and a feedback channel. Draft the getting-started and error-handling guides fully; outline the rest.
RULES: Every code sample must be runnable as written — verify endpoint paths, header names, and payload fields against the actual spec, and mark any sample you cannot verify as NEEDS VERIFICATION. Errors guide must map each error code to cause → fix (from the real error catalog). No aspirational features documented as shipped.
Do not write marketing prose. Do not document endpoints absent from the spec.
OUTPUT: markdown doc tree, the two fully-drafted guides, outline for the rest, and a docs-vs-spec consistency checklist with status per item.
```
