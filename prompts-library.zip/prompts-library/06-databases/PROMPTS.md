# 06 — Databases

Schema design, query performance, migrations, and data operations. Covers relational and NoSQL stores, ORM pitfalls, and operational data concerns.
Placeholder convention: `{{double_braces}}` mark user-supplied input (table names, query text, schemas, thresholds). Replace every placeholder before sending; a prompt with unfilled placeholders should be treated as incomplete.

---

### PROMPT-06-01 — Schema Design Review (Normalization vs Denormalization)
**Use when:** you have a proposed schema and want a design review before building on it.
**Output:** a structured review with normalization verdict, denormalization candidates, and an entity-relationship summary.
**Prompt:**
```text
ROLE: Senior database architect reviewing a schema proposal.
CONTEXT: Application: {{app_description}}. Proposed schema (DDL or table list): {{schema}}. Expected access patterns: {{read_write_patterns}}. Data volume estimates (label as ESTIMATE if not measured): {{volumes}}.
TASK: Review the schema for normalization issues (update/insert/delete anomalies), missing constraints (PKs, FKs, uniqueness, NOT NULL), and places where deliberate denormalization is justified by a named read pattern.
CONSTRAINTS: Do not invent columns or tables not implied by the access patterns. Distinguish measured facts from estimates. If the workload is unclear, ask or state "insufficient information" for that judgment. Do not redesign the whole schema unless the proposal is unfixable; prefer minimal corrections.
OUTPUT FORMAT: Markdown with sections: (1) Verdict (approve / approve-with-changes / rework), (2) Anomalies & constraint gaps as a numbered list, (3) Denormalization candidates table (pattern, benefit, cost, recommendation), (4) Revised DDL or ALTER list, (5) Open questions.
```

### PROMPT-06-02 — Index Design from a Slow Query
**Use when:** a specific query is slow and you need an index proposal grounded in its execution plan.
**Output:** an explain-plan analysis and a minimal index recommendation.
**Prompt:**
```text
ROLE: Database performance engineer.
CONTEXT: Table definition(s): {{table_ddl}}. Slow query: {{query_sql}}. Current indexes: {{existing_indexes}}. Database engine and version: {{engine}}. Row counts (ESTIMATE if unmeasured): {{row_counts}}.
TASK: First, request or infer the query's execution plan and walk through it line by line (Seq Scan vs Index Scan, join order, rows estimated vs actual). Then propose the minimal set of new indexes, stating for each which plan step it eliminates.
CONSTRAINTS: Do not propose indexes you cannot justify with a plan step. State write-amplification cost of each new index. If no plan is available, say so and give a provisional analysis marked PROVISIONAL. No invented engine flags; cite only options verified for {{engine}} {{version}}.
OUTPUT FORMAT: Markdown: (1) Plan walkthrough, (2) Root-cause statement, (3) Proposed indexes (DDL, each with justification + write cost), (4) Verification steps with exact EXPLAIN command, (5) Indexes considered and rejected.
```

### PROMPT-06-03 — Migration Safety Review (Expand-Contract)
**Use when:** reviewing a production schema/data migration for zero-downtime safety.
**Output:** a safety verdict with phase breakdown and rollback notes.
**Prompt:**
```text
ROLE: SRE specializing in zero-downtime database migrations.
CONTEXT: Migration to review: {{migration_sql_or_description}}. Application deploy process: {{deploy_process}}. Table size and traffic profile: {{table_profile}}. Database engine: {{engine}}.
TASK: Classify each statement as EXPAND (additive, safe), CONTRACT (destructive), or TRANSFORM (rewrite). Reorder or split into an expand-then-contract sequence. Flag lock-taking statements (ALTER TABLE variants, index builds) and long-transaction risks.
CONSTRAINTS: No destructive step may run in the same release as code that stops using the old shape. State a rollback path for every phase. If table size makes a rewrite unsafe, propose an online alternative (backfill in batches, shadow writes). Say "insufficient information" if deploy/rollback mechanics are unknown.
OUTPUT FORMAT: Markdown: (1) Verdict (safe as written / needs splitting / unsafe), (2) Phase plan table (phase, statements, deploy gate, rollback), (3) Lock and risk flags, (4) Checklist to run before each phase.
```

### PROMPT-06-04 — N+1 Query Detection
**Use when:** suspecting or confirming N+1 query patterns in application code or ORM usage.
**Output:** a detection report with offending call sites and fix strategies.
**Prompt:**
```text
ROLE: ORM and query-pattern auditor.
CONTEXT: Code under review: {{file_or_snippet}}. ORM and version: {{orm}}. A query log or trace excerpt if available: {{query_log}}. Expected request shape: {{request_flow}}.
TASK: Identify loops or lazy-loading triggers that issue one query per element. For each, name the exact call site, the repeated query shape, and the fix (eager loading, batching, DataLoader-style, or query rewrite) with a code sketch.
CONSTRAINTS: Read the actual code before proposing changes; do not guess ORM API names — verify against {{orm}} version docs before writing the fix sketch. Mark any finding as CONFIRMED (seen in log/code) or SUSPECTED (pattern only). Do not refactor unrelated code.
OUTPUT FORMAT: Markdown: (1) Summary count table (site, severity, confidence), (2) Per-finding detail with code sketch, (3) Suggested verification (query-count assertion or log check) with the exact command/test to run, (4) Items needing more information.
```

### PROMPT-06-05 — Transaction Boundary Review
**Use when:** reviewing whether transactions are correctly scoped (too big, too small, or missing).
**Output:** a boundary map with isolation risks and concrete fixes.
**Prompt:**
```text
ROLE: Transaction-semantics reviewer.
CONTEXT: Code under review: {{file_or_snippet}}. Database engine and default isolation level: {{engine_isolation}}. Any known concurrency bugs: {{known_issues}}.
TASK: Map every transaction: what it reads, what it writes, how long it may hold locks, and what happens on partial failure. Flag: transactions spanning external calls (HTTP, queue publish), missing rollback handling, long-running transactions, and read-then-act races (lost update, phantom reads) at the current isolation level.
CONSTRAINTS: Verify engine behavior claims against {{engine}} documentation for the stated version; label uncertain semantics as UNVERIFIED. Propose the smallest boundary change that fixes each issue. Do not change business logic.
OUTPUT FORMAT: Markdown: (1) Transaction map table (boundary, reads, writes, duration risk), (2) Findings numbered by severity, (3) Fix sketch per finding, (4) Open questions on intended invariants.
```

### PROMPT-06-06 — Query Optimization Explain-Plan Walkthrough
**Use when:** you have a query and its plan but want a guided, step-by-step interpretation.
**Output:** a plain-language plan walkthrough with ranked optimization options.
**Prompt:**
```text
ROLE: Database performance tutor explaining a plan to an engineer.
CONTEXT: Query: {{query_sql}}. Execution plan (EXPLAIN or EXPLAIN ANALYZE output): {{plan_output}}. Engine and version: {{engine}}. Table sizes and existing indexes: {{stats}}.
TASK: Walk the plan tree top-down (or as the engine reports it), defining every operator encountered, and compare estimated vs actual rows at each step. Identify the step responsible for the majority of execution time and rank optimization options by expected impact.
CONSTRAINTS: Label each diagnosis as FACT (visible in plan), INFERENCE (reasonable reading), or UNKNOWN (needs more data such as ANALYZE stats). Do not recommend options the engine does not support without labeling them as requiring verification. No fabricated timings.
OUTPUT FORMAT: Markdown: (1) Operator-by-operator walkthrough, (2) Time-concentration summary, (3) Ranked options (change, cost, expected gain as estimate), (4) Exact commands to measure before/after, (5) What data would sharpen the analysis.
```

### PROMPT-06-07 — Time-Series Schema Design
**Use when:** designing storage for metrics, events, or sensor data with time-based queries.
**Output:** a schema plus partitioning and retention design.
**Prompt:**
```text
ROLE: Time-series data architect.
CONTEXT: Data description: {{data_description}}. Write rate and retention needs (ESTIMATE if projected): {{volume_retention}}. Query patterns: {{query_patterns}} (e.g., latest value per device, hourly aggregates, raw-point drill-down). Engine options available: {{engines}}.
TASK: Propose a schema (timestamp handling, tags vs fields, primary/sort key), a partitioning/hypertable strategy, and an aggregation/downsampling tier. Justify engine choice against the query patterns.
CONSTRAINTS: Do not design for scale not supported by {{volume_retention}}; state assumptions explicitly. Verify engine-specific features against current docs before naming them. Include cardinality risk analysis for tag/label dimensions. Mark all capacity numbers as ESTIMATE unless measured.
OUTPUT FORMAT: Markdown: (1) Assumptions table, (2) Schema DDL, (3) Partitioning and retention plan, (4) Query-to-index mapping, (5) Risks and open questions.
```

### PROMPT-06-08 — Soft-Delete Strategy Review
**Use when:** deciding how to implement soft deletes (flag, timestamp, tombstone table) and their side effects.
**Output:** a strategy recommendation with query and index implications.
**Prompt:**
```text
ROLE: Data-modeling reviewer for soft-delete implementations.
CONTEXT: Tables involved: {{tables}}. ORM/framework: {{orm}}. Requirements: {{requirements}} (e.g., user-initiated restore, audit trail, GDPR erasure, unique constraints that must ignore deleted rows).
TASK: Compare strategies (boolean flag, deleted_at timestamp, separate tombstone/archive table) against the requirements. Cover: impact on every unique constraint, query filtering discipline (how to avoid forgetting WHERE clauses), index bloat, cascade behavior for relations, and hard-delete/retention policy.
CONSTRAINTS: Flag the classic pitfall of unique constraints blocking re-insert of a soft-deleted key and propose a concrete fix (partial index, compound key, or generated column) verified for {{engine}}. Do not pick a strategy without addressing restore and purge paths. State what the ORM does natively vs needs custom filters.
OUTPUT FORMAT: Markdown: (1) Requirement-to-strategy fit table, (2) Recommended design with DDL snippets, (3) Query-filtering convention and how to enforce it, (4) Index and constraint changes, (5) Failure modes to test.
```

### PROMPT-06-09 — Connection-Pool Tuning
**Use when:** database connections are saturating, queuing, or idle-wasting and pool size needs a rationale.
**Output:** a sizing model with measurement plan and rollout steps.
**Prompt:**
```text
ROLE: Database connection-pool engineer.
CONTEXT: Current pool settings: {{pool_settings}}. Deployment topology (app instances, PG/server config max_connections): {{topology}}. Observed symptoms or metrics: {{metrics}}. Driver/ORM pool library: {{pool_library}}.
TASK: Explain the pool-math reasoning (why pool size x instance count must stay under server max_connections, Little's-law view of wait time vs utilization). Propose a target pool size with the arithmetic shown, plus a measurement plan to validate it under load.
CONSTRAINTS: Label every number as MEASURED or ESTIMATE. Verify formulas against {{pool_library}} documentation; do not invent config keys. Include a staged rollout (change one variable, observe) and a rollback value. If metrics are missing, state which to collect first.
OUTPUT FORMAT: Markdown: (1) Current-state diagnosis, (2) Sizing arithmetic (inputs, formula, result), (3) Proposed settings diff, (4) Measurement plan with exact metrics/commands, (5) Rollout and rollback steps.
```

### PROMPT-06-10 — Data Retention and Archival Policy
**Use when:** defining how long data lives in hot storage, when it archives, and when it purges.
**Output:** a retention policy with implementation plan and legal/compliance checkpoints.
**Prompt:**
```text
ROLE: Data-governance engineer designing retention.
CONTEXT: Data domains: {{data_domains}}. Current storage growth (MEASURED or ESTIMATE): {{growth}}. Compliance constraints: {{compliance}} (e.g., GDPR right-to-erasure, finance record keeping). Query patterns needing historical data: {{history_needs}}.
TASK: Produce tiered retention (hot / warm / archive / purge) per data domain, the mechanism for each transition (partition drop, batch move, TTL), and the compliance mapping (what may never be hard-deleted, what must be erasable on request).
CONSTRAINTS: Do not set retention periods without a stated rationale tied to {{compliance}} or business need; where law is uncertain, flag for legal review rather than guessing. Verify TTL/partition-drop features against the target engine's docs. Include a dry-run and audit-trail requirement for purge jobs.
OUTPUT FORMAT: Markdown: (1) Retention matrix (domain, tiers, durations, rationale), (2) Transition mechanisms with implementation sketch, (3) Compliance mapping table, (4) Operational runbook outline (dry-run, audit, rollback), (5) Open legal questions.
```

### PROMPT-06-11 — ORM Anti-Pattern Review
**Use when:** auditing ORM usage for performance and correctness anti-patterns.
**Output:** a categorized anti-pattern report with fixed code sketches.
**Prompt:**
```text
ROLE: ORM usage reviewer with deep knowledge of {{orm}}.
CONTEXT: Codebase or excerpt: {{code_excerpt}}. ORM and version: {{orm_version}}. Known pain points: {{pain_points}}.
TASK: Scan for: N+1 lazy loading, cartesian joins from Include/ preload misuse, in-memory filtering of large sets, `.save()` of huge graphs, missing bulk operations, string-built queries (injection risk), and implicit transaction boundaries. For each, show the offending line and a corrected sketch.
CONSTRAINTS: Verify every proposed API call against {{orm_version}} documentation before writing it; mark UNVERIFIED if you cannot. Read the surrounding code to confirm context before flagging. Do not propose rewriting working code that has no identified problem. Severity: correctness > performance > style.
OUTPUT FORMAT: Markdown: (1) Findings table (anti-pattern, location, severity, confidence), (2) Detailed finding with before/after code, (3) Global recommendations (conventions, lint rules) with the exact rule/config name if it exists, (4) Items needing codebase access beyond the excerpt.
```

### PROMPT-06-12 — Deadlock Diagnosis
**Use when:** deadlocks occur in production and you need a root-cause analysis from logs and code.
**Output:** a deadlock graph interpretation, root cause, and prevention fixes.
**Prompt:**
```text
ROLE: Database concurrency diagnostician.
CONTEXT: Deadlock log entries: {{deadlock_logs}}. Engine and version: {{engine}}. Suspected code paths: {{code_paths}}. Schema/indexes involved: {{schema}}.
TASK: Parse each deadlock log into a wait-for graph: which transactions held which locks, in what order they requested them, and which was chosen as victim. Identify the lock-ordering inversion or gap-lock interaction causing the cycle, then map it to the application code paths.
CONSTRAINTS: Use only log facts for the graph; code mapping is INFERENCE until confirmed by reading {{code_paths}}. Verify engine-specific lock behavior (e.g., gap/next-key locks) against {{engine}} docs. Propose fixes that preserve correctness: consistent lock ordering, shorter transactions, or serialization at a coarser level. State "insufficient information" if the log lacks lock details.
OUTPUT FORMAT: Markdown: (1) Parsed wait-for graph (text diagram), (2) Root cause statement with confidence, (3) Code-path mapping, (4) Prevention fixes ranked by invasiveness, (5) Monitoring to add (exact deadlock metrics to alert on).
```

### PROMPT-06-13 — Full-Text Search Design
**Use when:** choosing and designing full-text search (engine built-in vs dedicated search service).
**Output:** a search architecture decision with index design and query plan.
**Prompt:**
```text
ROLE: Search engineer designing full-text search.
CONTEXT: Data to search: {{data_description}}. Query expectations: {{query_needs}} (languages, fuzzy matching, ranking signals, faceting). Write volume and latency SLO (ESTIMATE ok): {{volume_slo}}. Stack constraints: {{stack}}.
TASK: Recommend: database-native FTS vs external engine (e.g., Elasticsearch/OpenSearch/Meilisearch) with a decision table. Design the index mapping (analyzers, tokenizers, fields, boost weights), the sync strategy (transactional outbox vs polling vs dual-write), and ranking/fallback behavior.
CONSTRAINTS: Verify feature claims (language support, typo tolerance) against current docs before asserting them. Dual-write without outbox must be flagged as a consistency risk. Include reindex plan and zero-downtime index alias strategy. All latency/capacity numbers labeled ESTIMATE unless measured.
OUTPUT FORMAT: Markdown: (1) Decision table with verdict, (2) Index design, (3) Sync strategy diagram (Mermaid), (4) Query behavior spec, (5) Operational plan (reindex, monitoring), (6) Open questions.
```

### PROMPT-06-14 — Multi-Tenant Data Isolation Review
**Use when:** reviewing a shared-schema or shared-database multi-tenant design for isolation risks.
**Output:** an isolation audit with leak scenarios and fixes.
**Prompt:**
```text
ROLE: Multi-tenant architecture auditor.
CONTEXT: Isolation model (shared schema / schema-per-tenant / DB-per-tenant): {{model}}. Tenant-key handling in code: {{tenant_key}}. ORM/query layer: {{orm}}. Compliance needs: {{compliance}}.
TASK: Trace how tenant_id flows from authentication to every query. Identify leak scenarios: missing WHERE clauses, cross-tenant cache keys, background jobs without tenant context, connection reuse across tenants, analytics/export paths. Assess blast radius of one bug.
CONSTRAINTS: Verify any ORM-level scoping feature against {{orm}} docs before recommending it; if the codebase is unavailable, list the exact files/queries to inspect. Do not claim isolation is achieved by convention alone — demand an enforcement mechanism (DB RLS, middleware guard, or compile-time check). Label residual risk honestly.
OUTPUT FORMAT: Markdown: (1) Tenant-key flow diagram (Mermaid), (2) Leak-scenario table (scenario, likelihood, impact), (3) Enforcement recommendation, (4) Verification plan (exact test that proves cross-tenant access fails), (5) Residual risks.
```

### PROMPT-06-15 — Backup and Restore Drill Planner
**Use when:** validating that backups actually work by planning a restore drill.
**Output:** a drill runbook with pass/fail criteria and improvement actions.
**Prompt:**
```text
ROLE: Database reliability engineer planning a restore drill.
CONTEXT: Backup system: {{backup_system}} (snapshots, logical dumps, PITR/WAL archiving). Database engine and size: {{engine_size}}. RPO/RTO targets: {{rpo_rto}}. Environments available for drill: {{environments}}.
TASK: Design an end-to-end drill: pick a random restore point, restore into an isolated environment, verify data integrity (row counts, checksum sampling, application smoke queries), and measure achieved RPO/RTO against targets. Define explicit pass/fail criteria and what to do when each fails.
CONSTRAINTS: Do not assume backup success from job status alone — the drill must include an actual restore. Verify restore commands against {{backup_system}} docs for the deployed version. Include time estimates labeled ESTIMATE and a no-impact guarantee (isolated target). Identify what monitoring would have caught the drill's injected failure.
OUTPUT FORMAT: Markdown runbook: (1) Objectives and targets, (2) Step-by-step procedure with commands and expected output, (3) Verification queries, (4) Pass/fail criteria table, (5) Findings template and follow-up actions.
```

### PROMPT-06-16 — Data-Quality Check Suite
**Use when:** building automated checks that catch corrupt or implausible data early.
**Output:** a suite of data-quality checks with thresholds and alerting plan.
**Prompt:**
```text
ROLE: Data-quality engineer.
CONTEXT: Tables and critical columns: {{tables_columns}}. Known data problems: {{known_issues}}. Downstream consumers: {{consumers}}. Pipeline/runtime for running checks: {{runtime}}.
TASK: Design checks in four classes: schema (types, nullability), volume (row-count anomalies vs trailing average), distribution (null rate, min/max, duplicate rate, referential integrity), and business rules ({{business_rules}}). For each check define: metric, threshold (MEASURED baseline or ESTIMATE), severity, and action on failure.
CONSTRAINTS: Every threshold must cite its baseline source or be labeled ESTIMATE with a calibration plan. Do not write checks that alert constantly (define anomaly windows). Verify check can run within {{runtime}}. Include a quarantine vs fail-the-pipeline policy per severity.
OUTPUT FORMAT: Markdown: (1) Check catalog table (name, target, metric, threshold, severity), (2) Implementation sketch per check, (3) Calibration plan for ESTIMATE thresholds, (4) Alert routing and runbook notes, (5) Rollout order (shadow mode first).
```

### PROMPT-06-17 — Schema Diff to Migration Generator
**Use when:** converting a desired schema diff into a safe, ordered migration script.
**Output:** an ordered migration file with safety annotations.
**Prompt:**
```text
ROLE: Migration generator with safety review.
CONTEXT: Current schema (DDL): {{current_ddl}}. Target schema (DDL): {{target_ddl}}. Engine and version: {{engine}}. Migration tooling conventions: {{tooling}}.
TASK: Compute the diff (added/removed/changed tables, columns, indexes, constraints) and emit a migration that applies it in a safe order (create before drop, add nullable before backfill before set NOT NULL, index concurrently where supported). Annotate each statement SAFE / LOCKING / DESTRUCTIVE and split destructive steps into a separate follow-up migration.
CONSTRAINTS: Verify statement semantics against {{engine}} {{version}} docs (e.g., which ALTER forms rewrite tables). Do not silently drop columns with data — require an explicit archive/confirmation note. If the diff is ambiguous, list the ambiguity rather than guessing. Include rollback stubs where mechanically possible.
OUTPUT FORMAT: One code block per migration phase with: (1) Migration filename suggestion, (2) Annotated SQL or DSL, (3) Safety summary table, (4) Manual steps that cannot be automated, (5) Verification queries after apply.
```

### PROMPT-06-18 — Cache-Invalidation Strategy
**Use when:** designing when and how cached data gets invalidated after writes.
**Output:** an invalidation design with race analysis and failure behavior.
**Prompt:**
```text
ROLE: Caching architect.
CONTEXT: What is cached and how: {{cache_description}} (keys, TTLs, layers: in-process/Redis/CDN). Write paths that mutate the data: {{write_paths}}. Consistency requirement: {{consistency}} (stale-ok duration, or must-be-fresh).
TASK: Choose and detail an invalidation strategy: TTL-only, write-through, cache-aside with delete-on-write, versioning, or event-driven invalidation. Analyze the classic races (delete-then-write stale repopulation, thundering herd on miss) and specify defenses per layer.
CONSTRAINTS: Do not promise stronger consistency than {{consistency}} requires — weaker is cheaper. Verify any library/Redis command claims against docs. Include failure behavior (invalidation event lost, Redis down). Label latency numbers as ESTIMATE. State explicitly which inconsistencies are accepted.
OUTPUT FORMAT: Markdown: (1) Strategy decision with rationale, (2) Key/version design, (3) Race analysis and defenses, (4) Failure-mode table, (5) Monitoring metrics to add, (6) Accepted-inconsistency statement.
```

### PROMPT-06-19 — Read-Replica Routing Design
**Use when:** adding read replicas and deciding which queries may safely route to them.
**Output:** a routing policy with lag-awareness and consistency rules.
**Prompt:**
```text
ROLE: Database traffic-routing designer.
CONTEXT: Topology: {{topology}} (primary + N replicas, regions). Replication lag behavior (MEASURED or typical): {{lag}}. Query mix: {{query_mix}}. Framework/driver: {{driver}}.
TASK: Classify each query class (read-after-write user flows, reports, analytics, session reads) as primary-only or replica-eligible, with the reasoning. Design lag handling: max-lag threshold with fallback to primary, or read-your-writes tokens. Cover routing failure behavior and replica-lag monitoring.
CONSTRAINTS: Any flow that reads data the same request just wrote must default to primary unless a session-token mechanism is designed. Verify driver/routing features against {{driver}} docs. Include metrics: lag distribution, fallback rate, primary load delta. Label thresholds as ESTIMATE pending measurement.
OUTPUT FORMAT: Markdown: (1) Query-class routing table, (2) Lag-handling mechanism, (3) Configuration sketch (driver-level or proxy), (4) Failure behavior, (5) Monitoring plan, (6) Rollout steps.
```

### PROMPT-06-20 — Seed and Fixture Data Generator
**Use when:** creating realistic, deterministic seed/fixture data for dev and test environments.
**Output:** a generator spec plus reference dataset design.
**Prompt:**
```text
ROLE: Test-data engineer.
CONTEXT: Schema: {{schema}}. Scenarios to cover: {{scenarios}} (edge cases, volume needs, referential graphs). Determinism requirement: {{determinism}} (same seed → same data?). Privacy constraint: {{privacy}} (no real PII allowed).
TASK: Design a seed/fixture strategy: deterministic generator (seeded RNG), scenario bundles (minimal happy path, edge-case set, volume set), referential-integrity rules, and idempotency (re-runnable without duplicates). Ensure synthetic data looks plausible (distributions, formats) but contains zero real PII.
CONSTRAINTS: Verify any Faker/generator library calls against the library's current API docs; mark UNVERIFIED otherwise. Volume set must state generation-time ESTIMATE. Include a freshness story (how fixtures stay in sync with schema changes). Do not use production dumps even "anonymized" unless a stated mechanism guarantees irreversibility.
OUTPUT FORMAT: Markdown: (1) Strategy overview, (2) Scenario bundle table (bundle, purpose, size), (3) Generator implementation sketch, (4) Determinism and idempotency notes, (5) PII compliance checklist, (6) Maintenance plan.
```
