
## 01-product-requirements

### PROMPT-01-01 — PRD Generator
### PROMPT-01-02 — User Story Breakdown (INVEST)
### PROMPT-01-03 — JTBD Interview Synthesis
### PROMPT-01-04 — Acceptance Criteria Writer (Gherkin)
### PROMPT-01-05 — MVP Scope Cutter
### PROMPT-01-06 — Feature Spec from Vague Idea
### PROMPT-01-07 — Competitive Teardown
### PROMPT-01-08 — User Interview Question Designer
### PROMPT-01-09 — Assumption/Risk Register
### PROMPT-01-10 — Prioritization (RICE)
### PROMPT-01-11 — Roadmap Narrative
### PROMPT-01-12 — Edge-Case Brainstormer
### PROMPT-01-13 — Spec Review (Devil's Advocate)
### PROMPT-01-14 — Metrics Definition for a Feature
### PROMPT-01-15 — Deprecation Plan
### PROMPT-01-16 — Changelog-from-Diff
### PROMPT-01-17 — Stakeholder One-Pager
### PROMPT-01-18 — Regulatory/Compliance Checklist Mapper
### PROMPT-01-19 — User Persona Builder from Support Tickets
### PROMPT-01-20 — Scope-Creep Guard

## 02-ux-ui-design

### PROMPT-02-01 — Heuristic Evaluation (Nielsen)
### PROMPT-02-02 — Design-System Audit
### PROMPT-02-03 — Design Tokens Generator
### PROMPT-02-04 — Onboarding Flow Design
### PROMPT-02-05 — Empty/Error/Success States Trio
### PROMPT-02-06 — Dark-Mode Color Scale
### PROMPT-02-07 — Microcopy Rewrite
### PROMPT-02-08 — Accessibility Design Review (WCAG 2.2 AA)
### PROMPT-02-09 — Form UX Review
### PROMPT-02-10 — Dashboard Information Hierarchy
### PROMPT-02-11 — Conversion Funnel Critique
### PROMPT-02-12 — Mobile-Responsive Review
### PROMPT-02-13 — Loading-State UX Review (No Fake Progress)
### PROMPT-02-14 — Navigation IA Redesign
### PROMPT-02-15 — Wireframe-to-Spec
### PROMPT-02-16 — Animation/Motion Spec
### PROMPT-02-17 — User Flow Diagram from Screen Inventory
### PROMPT-02-18 — Copy Tone Guide
### PROMPT-02-19 — Design Handoff Checklist
### PROMPT-02-20 — Landing Page Critique

## 03-frontend-web

### PROMPT-03-01 — React Component Generator
### PROMPT-03-02 — State-Management Decision (Local vs Server vs Global)
### PROMPT-03-03 — Core Web Vitals Audit Plan
### PROMPT-03-04 — CSS Layout Fix (Flex/Grid)
### PROMPT-03-05 — Complex Form with Validation (Accessible)
### PROMPT-03-06 — Animation Spec (Transform/Opacity Only, Reduced-Motion)
### PROMPT-03-07 — SSR/Hydration Bug Diagnosis
### PROMPT-03-08 — Error-Boundary + Fallback Design
### PROMPT-03-09 — Data Table with Sort/Filter/Pagination (Virtualized)
### PROMPT-03-10 — Autocomplete/Combobox (ARIA)
### PROMPT-03-11 — Theming System Refactor
### PROMPT-03-12 — Bundle-Size Reduction Plan
### PROMPT-03-13 — Race-Condition Fix in Fetch (AbortController)
### PROMPT-03-14 — Local-First Offline Sync Design
### PROMPT-03-15 — URL/State Sync Design
### PROMPT-03-16 — Web Component from Scratch
### PROMPT-03-17 — iframe/Sandbox Security Review
### PROMPT-03-18 — Test Plan for a Component (RTL)
### PROMPT-03-19 — Migration Plan (Class→Hooks, Vue2→3, etc.)
### PROMPT-03-20 — Render-Performance Profile (Unnecessary Re-renders)

## 04-mobile-development

### PROMPT-04-01 — Screen Scaffold (SwiftUI / Jetpack Compose / RN)
### PROMPT-04-02 — Navigation Architecture (Stack/Tabs/Deep-Link)
### PROMPT-04-03 — Offline-First Data Layer
### PROMPT-04-04 — Push-Notification Strategy
### PROMPT-04-05 — App-Store Listing Optimizer
### PROMPT-04-06 — Startup Performance Audit (TTI)
### PROMPT-04-07 — Memory-Leak Hunt
### PROMPT-04-08 — Deep-Link/Universal-Link Setup
### PROMPT-04-09 — Biometric Auth Flow
### PROMPT-04-10 — Accessibility Audit (VoiceOver/TalkBack)
### PROMPT-04-11 — Release Checklist (Store Review)
### PROMPT-04-12 — OTA Update Strategy
### PROMPT-04-13 — Gesture Handling Spec
### PROMPT-04-14 — Haptic/Motion Design
### PROMPT-04-15 — Crash-Report Triage
### PROMPT-04-16 — Dependency Upgrade Plan (SDK Bump)
### PROMPT-04-17 — Screenshot/Test-Plan Generation
### PROMPT-04-18 — In-App Purchase/Subscription Flow
### PROMPT-04-19 — Background-Task Design
### PROMPT-04-20 — Beta Feedback Synthesis

## 05-api-design

### PROMPT-05-01 — REST Resource Design Review
### PROMPT-05-02 — Error-Response Standard (RFC 7807)
### PROMPT-05-03 — Pagination Strategy
### PROMPT-05-04 — OpenAPI Spec Generator from Code
### PROMPT-05-05 — OpenAPI-First Code Scaffold
### PROMPT-05-06 — Versioning Policy
### PROMPT-05-07 — Idempotency-Key Design
### PROMPT-05-08 — Rate-Limiting Design
### PROMPT-05-09 — Webhook Design (Signing, Retries)
### PROMPT-05-10 — GraphQL Schema Review (N+1, Pagination)
### PROMPT-05-11 — API Naming/Conventions Lint
### PROMPT-05-12 — Breaking-Change Detector (Diff Two Specs)
### PROMPT-05-13 — SDK Generation Review
### PROMPT-05-14 — Auth Design (OAuth2/OIDC Flows)
### PROMPT-05-15 — API Security Review Checklist
### PROMPT-05-16 — Deprecation/Migration Plan
### PROMPT-05-17 — Mock Server from Spec
### PROMPT-05-18 — Contract Test Generator
### PROMPT-05-19 — Performance Budget for Endpoints
### PROMPT-05-20 — Developer-Portal Documentation Set

## 06-databases

### PROMPT-06-01 — Schema Design Review (Normalization vs Denormalization)
### PROMPT-06-02 — Index Design from a Slow Query
### PROMPT-06-03 — Migration Safety Review (Expand-Contract)
### PROMPT-06-04 — N+1 Query Detection
### PROMPT-06-05 — Transaction Boundary Review
### PROMPT-06-06 — Query Optimization Explain-Plan Walkthrough
### PROMPT-06-07 — Time-Series Schema Design
### PROMPT-06-08 — Soft-Delete Strategy Review
### PROMPT-06-09 — Connection-Pool Tuning
### PROMPT-06-10 — Data Retention and Archival Policy
### PROMPT-06-11 — ORM Anti-Pattern Review
### PROMPT-06-12 — Deadlock Diagnosis
### PROMPT-06-13 — Full-Text Search Design
### PROMPT-06-14 — Multi-Tenant Data Isolation Review
### PROMPT-06-15 — Backup and Restore Drill Planner
### PROMPT-06-16 — Data-Quality Check Suite
### PROMPT-06-17 — Schema Diff to Migration Generator
### PROMPT-06-18 — Cache-Invalidation Strategy
### PROMPT-06-19 — Read-Replica Routing Design
### PROMPT-06-20 — Seed and Fixture Data Generator

## 07-architecture

### PROMPT-07-01 — System Design Doc (Interview-Style)
### PROMPT-07-02 — Architecture Decision Record Writer
### PROMPT-07-03 — Monolith vs Microservices Decision Matrix
### PROMPT-07-04 — Event-Driven Architecture Review
### PROMPT-07-05 — CQRS Suitability Analysis
### PROMPT-07-06 — Capacity-Planning Model
### PROMPT-07-07 — Technology-Selection Scorecard
### PROMPT-07-08 — Integration Pattern Choice (Sync/Async/BFF)
### PROMPT-07-09 — Failure-Mode Analysis (FMEA-Lite)
### PROMPT-07-10 — Architecture Diagram Generator (Mermaid from Description)
### PROMPT-07-11 — Bounded-Context Mapping (DDD)
### PROMPT-07-12 — Technical-Debt Register Builder
### PROMPT-07-13 — Scaling-Bottleneck Analysis
### PROMPT-07-14 — Single-Point-of-Failure Audit
### PROMPT-07-15 — Cross-Cutting Concerns Checklist
### PROMPT-07-16 — Third-Party Dependency Risk Review
### PROMPT-07-17 — Data-Consistency Strategy (Eventual vs Strong)
### PROMPT-07-18 — Cloud Cost-Estimation Model
### PROMPT-07-19 — Strangler-Fig Migration Path
### PROMPT-07-20 — Architecture Fitness Review Against NFRs

## 08-testing-qa

### PROMPT-08-01 — Unit-Test Strategy for a Module
### PROMPT-08-02 — TDD Red-Green-Refactor Driver
### PROMPT-08-03 — Integration-Test Plan (Testcontainers)
### PROMPT-08-04 — E2E Test Plan (Critical Paths Only)
### PROMPT-08-05 — Test-Data Builder Patterns
### PROMPT-08-06 — Flaky-Test Quarantine Protocol
### PROMPT-08-07 — Coverage-Gap Analysis
### PROMPT-08-08 — Contract-Test Generator (Consumer-Driven)
### PROMPT-08-09 — Mutation-Testing Review
### PROMPT-08-10 — Property-Based Test Design
### PROMPT-08-11 — Test-Smell Detector (Over-Mocking)
### PROMPT-08-12 — UAT Script Writer from Acceptance Criteria
### PROMPT-08-13 — Visual-Regression Setup Plan
### PROMPT-08-14 — Load-Test Scenario Design
### PROMPT-08-15 — Security-Regression Checklist
### PROMPT-08-16 — Snapshot-Test Review
### PROMPT-08-17 — Chaos/Failure-Injection Plan
### PROMPT-08-18 — QA Risk-Based Test Prioritization
### PROMPT-08-19 — Smoke-Suite Definition
### PROMPT-08-20 — Characterization Test Writer for Legacy Code

## 09-security

### PROMPT-09-01 — Threat Model (STRIDE-Lite) for a Feature
### PROMPT-09-02 — Authn Flow Review (Session/Token Lifecycle)
### PROMPT-09-03 — Authz Review (RBAC/ABAC, Privilege-Escalation Hunt)
### PROMPT-09-04 — OWASP Top 10 Code Review
### PROMPT-09-05 — Secrets-Handling Audit
### PROMPT-09-06 — Dependency Vulnerability Triage (CVE to Fix Plan)
### PROMPT-09-07 — Injection-Surface Review (SQL/NoSQL/Command/Template)
### PROMPT-09-08 — SSRF/Path-Traversal Review
### PROMPT-09-09 — API Abuse-Case Design
### PROMPT-09-10 — Supply-Chain Review (CI/CD, Actions Pinning)
### PROMPT-09-11 — Incident-Response Runbook Builder
### PROMPT-09-12 — Security-Headers/CSP Review
### PROMPT-09-13 — Encryption-at-Rest/Transit Checklist
### PROMPT-09-14 — Logging-PII Audit
### PROMPT-09-15 — Penetration-Test Scoping Brief
### PROMPT-09-16 — Secure-Defaults Config Review
### PROMPT-09-17 — Token/Credential-Rotation Plan
### PROMPT-09-18 — Security Regression Test Writer
### PROMPT-09-19 — Third-Party Vendor Security Questionnaire
### PROMPT-09-20 — Post-Incident Lessons-Learned Extractor

## 10-performance

### PROMPT-10-01 — Profiling Plan (CPU/Memory)
### PROMPT-10-02 — Slow-Request RCA from Traces
### PROMPT-10-03 — Caching-Layer Design (L1/L2/CDN)
### PROMPT-10-04 — DB Performance Top-10 Review
### PROMPT-10-05 — Frontend Performance Budget
### PROMPT-10-06 — Bundle-Splitting Plan
### PROMPT-10-07 — Memory-Leak Diagnosis Steps
### PROMPT-10-08 — Latency-Budget Analysis (p50/p95/p99)
### PROMPT-10-09 — Connection/Queue Saturation Analysis
### PROMPT-10-10 — N+1 / Fixture-Heavy Test Slowdown
### PROMPT-10-11 — Async/Parallelization Review
### PROMPT-10-12 — GC/Pause Analysis (or Equivalent Runtime)
### PROMPT-10-13 — Cold-Start Optimization (Serverless)
### PROMPT-10-14 — Image/Asset Optimization Plan
### PROMPT-10-15 — Database Lock-Contention Review
### PROMPT-10-16 — Cache-Stampede Protection
### PROMPT-10-17 — Backpressure Design
### PROMPT-10-18 — Benchmark Harness Builder (Honest, No Cherry-Picking)
### PROMPT-10-19 — Performance-Regression CI Gate
### PROMPT-10-20 — Capacity Headroom Report

## 11-devops-ci-cd

### PROMPT-11-01 — CI Pipeline with Fast-Feedback Ordering
### PROMPT-11-02 — Dockerfile Review: Caching & Non-Root
### PROMPT-11-03 — Docker Compose Local Stack Spec
### PROMPT-11-04 — Kubernetes Manifest Review
### PROMPT-11-05 — Terraform Plan Critique
### PROMPT-11-06 — SLO-Based Monitoring & Alerting Design
### PROMPT-11-07 — Incident Postmortem Facilitator
### PROMPT-11-08 — Feature-Flag Rollout Plan
### PROMPT-11-09 — Rollback Strategy Design
### PROMPT-11-10 — Environment Promotion Design
### PROMPT-11-11 — Secrets-in-CI Audit
### PROMPT-11-12 — Build-Time Optimization
### PROMPT-11-13 — Deploy Freeze / Change-Window Planner
### PROMPT-11-14 — Structured Logging Spec
### PROMPT-11-15 — Canary vs Blue-Green Decision & Analysis
### PROMPT-11-16 — GitHub Actions Workflow Review
### PROMPT-11-17 — On-Call Runbook Builder
### PROMPT-11-18 — Infrastructure Drift-Detection Plan
### PROMPT-11-19 — Infrastructure Cost-Optimization Review
### PROMPT-11-20 — Zero-Downtime Migration Checklist

## 12-debugging-troubleshooting

### PROMPT-12-01 — Evidence-First Root-Cause Analysis (5-Whys)
### PROMPT-12-02 — Reproduction Script Writer
### PROMPT-12-03 — Log Triage & Pattern Extraction
### PROMPT-12-04 — Git Bisect Assistant
### PROMPT-12-05 — Race-Condition Diagnosis
### PROMPT-12-06 — Memory Leak / Heap Triage
### PROMPT-12-07 — Production Debugging Guide (Safe, Read-Only)
### PROMPT-12-08 — Flaky-Failure Bisect
### PROMPT-12-09 — "Works on My Machine" Environment Diff
### PROMPT-12-10 — Stack-Trace Decoder for Juniors
### PROMPT-12-11 — Timeout & Cascade-Failure Analysis
### PROMPT-12-12 — Data-Corruption Forensics
### PROMPT-12-13 — Intermittent Network-Issue Checklist
### PROMPT-12-14 — Regression-Window Finder
### PROMPT-12-15 — Error-Message Improvement (Actionable Diagnostics)
### PROMPT-12-16 — Hypothesis-Log Template (Scientific Debugging)
### PROMPT-12-17 — Performance-Regression Bisect
### PROMPT-12-18 — Crash-Loop Back-Off Diagnosis
### PROMPT-12-19 — Third-Party Outage Assessment
### PROMPT-12-20 — Post-Fix Regression Guard Writer

## 13-code-review-refactoring

### PROMPT-13-01 — PR Review Checklist Run
### PROMPT-13-02 — Risk-First Review Summary
### PROMPT-13-03 — Large-PR Splitter
### PROMPT-13-04 — Behavior-Preserving Refactor Plan
### PROMPT-13-05 — Code-Smell Detector with Severity
### PROMPT-13-06 — Dead-Code Elimination Plan
### PROMPT-13-07 — Naming & Semantics Review
### PROMPT-13-08 — Error-Handling Pattern Review
### PROMPT-13-09 — Legacy-Code Characterization Before Change
### PROMPT-13-10 — Boy-Scout vs Scope-Discipline Adjudicator
### PROMPT-13-11 — API-Surface Simplification Review
### PROMPT-13-12 — Duplicate-Logic Consolidation
### PROMPT-13-13 — Test-Quality Review (Meaningful Assertions)
### PROMPT-13-14 — Dependency-Boundary Review
### PROMPT-13-15 — Refactor Execution with Green-Bar Discipline
### PROMPT-13-16 — Commit-Sequence Planner
### PROMPT-13-17 — PR Description Writer
### PROMPT-13-18 — Review-Comment Responder
### PROMPT-13-19 — Hotfix Review (Expedient but Safe)
### PROMPT-13-20 — Deprecation Cleanup Executor

## 14-documentation

### PROMPT-14-01 — README Writer/Refresh
### PROMPT-14-02 — API Reference Generator
### PROMPT-14-03 — Architecture Overview (C4-Lite)
### PROMPT-14-04 — Runbook Writer
### PROMPT-14-05 — ADR Set Generator
### PROMPT-14-06 — Documentation Accuracy Review
### PROMPT-14-07 — Code-Comment Policy
### PROMPT-14-08 — Tutorial / Getting-Started Guide
### PROMPT-14-09 — Changelog Generator
### PROMPT-14-10 — Onboarding Doc for New Developers
### PROMPT-14-11 — Troubleshooting FAQ Builder
### PROMPT-14-12 — Inline-Docstring Generator (Style-Consistent)
### PROMPT-14-13 — Diagram-as-Code (Mermaid) Generator
### PROMPT-14-14 — Glossary / Terminology Doc
### PROMPT-14-15 — Security Documentation Review
### PROMPT-14-16 — Deprecation Notice Writer
### PROMPT-14-17 — Design Doc Template Fill
### PROMPT-14-18 — Docs-Site Information Architecture Review
### PROMPT-14-19 — "Explain This Code" for Juniors
### PROMPT-14-20 — Documentation-Debt Register

## 15-prompt-engineering-ai-features

### PROMPT-15-01 — System-Prompt Architect for an AI Feature
### PROMPT-15-02 — RAG Pipeline Design
### PROMPT-15-03 — Eval-Harness Builder
### PROMPT-15-04 — Structured-Output Contract (Schema + Retries)
### PROMPT-15-05 — Tool/Function-Calling Contract Design
### PROMPT-15-06 — Hallucination-Reduction Patterns
### PROMPT-15-07 — Guardrail & Injection-Defense Spec
### PROMPT-15-08 — Prompt-Compression Rewrite
### PROMPT-15-09 — Multi-Step Agent Planner (Plan/Act/Verify)
### PROMPT-15-10 — Prompt Versioning & A/B Plan
### PROMPT-15-11 — Cost/Latency Budget for LLM Calls
### PROMPT-15-12 — Context-Window Budgeting Spec
### PROMPT-15-13 — Fallback & Degradation Design
### PROMPT-15-14 — Prompt Regression Test Writer
### PROMPT-15-15 — Refusal & Edge-Case Test Suite
### PROMPT-15-16 — Few-Shot Example Curator
### PROMPT-15-17 — Semantic Router Design (Intent Classification)
### PROMPT-15-18 — Human-in-the-Loop Checkpoint Spec
### PROMPT-15-19 — Prompt-Injection Red-Team Generator
### PROMPT-15-20 — Observability Spec for AI Features

## 16-data-engineering

### PROMPT-16-01 — ETL vs ELT Pipeline Design
### PROMPT-16-02 — Dimensional Model Review
### PROMPT-16-03 — Data-Quality Check Suite
### PROMPT-16-04 — Streaming vs Batch Decision
### PROMPT-16-05 — dbt Model Review
### PROMPT-16-06 — Orchestration DAG Design
### PROMPT-16-07 — Schema Evolution Strategy
### PROMPT-16-08 — Idempotent Backfill Plan
### PROMPT-16-09 — Data Lineage Documentation
### PROMPT-16-10 — CDC Pipeline Design
### PROMPT-16-11 — Big-Query Cost Optimization
### PROMPT-16-12 — Data Privacy Classification
### PROMPT-16-13 — Incremental Model Pattern
### PROMPT-16-14 — Source/Sink Connector Review
### PROMPT-16-15 — Dead-Letter and Replay Design
### PROMPT-16-16 — Partition Strategy Review
### PROMPT-16-17 — Data Contract Definition
### PROMPT-16-18 — Pipeline Observability Design
### PROMPT-16-19 — Entity Resolution Design
### PROMPT-16-20 — Legacy DB to Warehouse Migration

## 17-analytics-growth

### PROMPT-17-01 — Event Tracking Plan
### PROMPT-17-02 — Funnel Analysis Design
### PROMPT-17-03 — A/B Test Design
### PROMPT-17-04 — Metrics Tree / North Star
### PROMPT-17-05 — Decision-Oriented Dashboard Spec
### PROMPT-17-06 — Retention Cohort Analysis
### PROMPT-17-07 — Activation Moment Identification
### PROMPT-17-08 — Pricing Experiment Design
### PROMPT-17-09 — Churn-Signal Detector
### PROMPT-17-10 — Unbiased Survey Design
### PROMPT-17-11 — Experiment Result Read
### PROMPT-17-12 — Segmentation Analysis
### PROMPT-17-13 — SEO / Landing Audit
### PROMPT-17-14 — Onboarding Optimization Analysis
### PROMPT-17-15 — Feature Adoption Analysis
### PROMPT-17-16 — Data-Informed vs Data-Driven Memo
### PROMPT-17-17 — Growth-Loop Identification
### PROMPT-17-18 — Analytics Implementation Audit
### PROMPT-17-19 — Qualitative Feedback Synthesis
### PROMPT-17-20 — Anti-Vanity KPI Review

## 18-team-process

### PROMPT-18-01 — Sprint-Planning Facilitator
### PROMPT-18-02 — Estimation Calibration
### PROMPT-18-03 — Retrospective Facilitator
### PROMPT-18-04 — RFC Writer
### PROMPT-18-05 — RFC Reviewer
### PROMPT-18-06 — Tech-Debt Prioritization
### PROMPT-18-07 — Incident Communication Templates
### PROMPT-18-08 — Hiring-Rubric Designer
### PROMPT-18-09 — Work-Sample Interview Design
### PROMPT-18-10 — 1:1 Agenda Builder
### PROMPT-18-11 — Knowledge-Transfer Doc
### PROMPT-18-12 — Design-Review Meeting Prep
### PROMPT-18-13 — Async Update Optimizer
### PROMPT-18-14 — OKR Drafting for an Eng Team
### PROMPT-18-15 — Delegation Brief
### PROMPT-18-16 — Meeting Notes to Actions
### PROMPT-18-17 — Team-API Document
### PROMPT-18-18 — Cross-Team Dependency Mapper
### PROMPT-18-19 — Burnout-Risk Process Review
### PROMPT-18-20 — Onboarding-Buddy Checklist

## 19-ai-coding-workflows

### PROMPT-19-01 — Plan-First Session Bootstrap
### PROMPT-19-02 — Verify-Loop Driver
### PROMPT-19-03 — TDD Driver for a Feature
### PROMPT-19-04 — Read-Before-Edit Guard
### PROMPT-19-05 — Parallel-Work Decomposition
### PROMPT-19-06 — Context-Budget Manager
### PROMPT-19-07 — Safe-Autonomy Policy Writer
### PROMPT-19-08 — Conventional Commit Writer
### PROMPT-19-09 — PR Description and Review Guide
### PROMPT-19-10 — Code Explainer for Onboarding
### PROMPT-19-11 — Slice-a-Large-Change Planner
### PROMPT-19-12 — Mistake-to-Constraint Encoder
### PROMPT-19-13 — Codebase Orientation Brief
### PROMPT-19-14 — Subsystem Tutor
### PROMPT-19-15 — Shell-Command Explainer
### PROMPT-19-16 — Rubber-Duck Debugger
### PROMPT-19-17 — Change-Impact Analysis
### PROMPT-19-18 — Refactor Green-Bar Protocol
### PROMPT-19-19 — Session Handoff Note
### PROMPT-19-20 — Evidence-First Bug Hunt

## 20-fullstack-blueprints

### PROMPT-20-01 — SaaS Starter
### PROMPT-20-02 — CRUD App from Entity List
### PROMPT-20-03 — Real-Time Chat/Collab App
### PROMPT-20-04 — Admin Dashboard from DB Schema
### PROMPT-20-05 — CLI Tool with Subcommands and Config
### PROMPT-20-06 — Browser Extension
### PROMPT-20-07 — Landing Page + Waitlist
### PROMPT-20-08 — File Upload + Processing Pipeline
### PROMPT-20-09 — Multi-User Todo with Sharing
### PROMPT-20-10 — E-Commerce Checkout Flow
### PROMPT-20-11 — Job Board with Search and Filters
### PROMPT-20-12 — Booking/Appointment System
### PROMPT-20-13 — RSS/Reader App
### PROMPT-20-14 — URL Shortener with Analytics
### PROMPT-20-15 — Personal Finance Tracker
### PROMPT-20-16 — Quiz/Exam App with Grading
### PROMPT-20-17 — API-Only Service + OpenAPI + Client SDK
### PROMPT-20-18 — Webhook Receiver with Retries and DLQ
### PROMPT-20-19 — Static Blog with MDX
### PROMPT-20-20 — Hackathon MVP in 48 Hours
