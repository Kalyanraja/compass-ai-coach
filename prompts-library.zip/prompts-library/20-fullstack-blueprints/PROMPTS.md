# 20 — Fullstack Blueprints

End-to-end build prompts: each specifies stack placeholders, data model, surface area, auth, tests, and acceptance criteria, and always plans first. Placeholder convention: anything in `{{double_curly_braces}}` is user-supplied input — replace it before sending; for optional context, leave the braces with an empty value rather than deleting them.

### PROMPT-20-01 — SaaS Starter
**Use when:** bootstrapping a SaaS app with auth, billing, and a dashboard.
**Output:** a build plan, then implementation of auth, billing, and dashboard skeleton.
**Prompt:**
```text
ROLE: You are a senior fullstack engineer scaffolding a production SaaS starter.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}; billing via {{billing_provider}}; auth via {{auth_provider_or_own}}.
DATA MODEL: users, teams (org unit), memberships (role), subscriptions (plan, status), audit_log.
SURFACE: pages — signup/login, team switcher, dashboard shell with empty states, settings (team, billing); API — auth callbacks, team CRUD, subscription webhook, audit-log read.
CONSTRAINTS:
- Plan first: output the full plan (schemas, routes, file tree, verification commands) and wait for my OK before writing code.
- Read any existing repo config before choosing versions; do not invent dependency APIs — verify against installed package versions or docs.
- Billing webhook must verify signatures and handle idempotent event processing; state the replay protection design.
- Auth: session handling, protected routes, and role checks (owner/member); no unprotected mutating endpoints.
- Tests: one integration test per API group plus a smoke test for auth flow; name the commands and iterate until green.
OUTPUT FORMAT:
1. Plan: data model DDL sketch | route table | file tree | verification commands.
2. Implementation after OK, stepwise with per-step verification.
3. Acceptance checklist: each requirement with pass evidence.
```

### PROMPT-20-02 — CRUD App from Entity List
**Use when:** generating a complete CRUD app from a list of entities.
**Output:** API + UI + tests for every entity, generated consistently.
**Prompt:**
```text
ROLE: You are generating a CRUD application from an entity specification.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}.
ENTITIES: {{entity_list_with_fields}} (name, fields with types, and relations).
SURFACE: for each entity — list page (pagination, search, sort), detail page, create/edit forms, delete with confirmation; API — REST endpoints per entity; tests — API integration tests.
CONSTRAINTS:**
- Derive the schema strictly from {{entity_list_with_fields}}; if a field type is ambiguous, ask (list ambiguities) rather than choosing silently.
- Validation rules live in one shared schema used by both API and forms; no divergent client/server rules.
- Standard conventions: consistent pluralization, consistent error shape, cursor or page pagination on every list endpoint.
- Plan first: entity-to-endpoint mapping table and file tree, then wait for my OK.
- Name the verification command per entity (e.g., its test file) and iterate until all are green; do not invent ORM APIs — check the installed version's docs.
OUTPUT FORMAT:
1. Mapping table: entity | table | endpoints | pages | test file.
2. Plan (schemas, file tree, commands) awaiting OK.
3. Stepwise implementation with verification transcript.
4. Acceptance checklist per entity.
```

### PROMPT-20-03 — Real-Time Chat/Collab App
**Use when:** building a chat or collaborative real-time app.
**Output:** plan, then implementation of realtime transport, persistence, presence, and tests.
**Prompt:**
```text
ROLE: You are a senior engineer building a real-time collaboration app.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}; realtime via {{realtime_tech}} (websockets, SSE, or managed).
DATA MODEL: workspaces, channels, messages (edited/deleted flags), users, presence.
SURFACE: channel list, message view with optimistic send, typing indicators, presence list; API — history pagination, send, edit, delete; realtime — new-message and presence events.
CONSTRAINTS:**
- Plan first (data model, event protocol, file tree, verification commands) and wait for my OK.
- Define the event envelope (id, type, payload, timestamp) and ordering strategy; state the reconnect/replay behavior.
- Optimistic UI must reconcile with server truth (temp IDs, failure states); describe the reconciliation approach before coding it.
- Presence must have expiry (heartbeat timeout); no ghost users after disconnect.
- Tests: protocol-level tests for event ordering and reconnect replay plus API tests; run and iterate until green.
OUTPUT FORMAT:
1. Plan: event protocol | schema | file tree | commands.
2. Implementation steps with verification.
3. Failure-mode table: disconnect, duplicate send, out-of-order events — behavior per case.
4. Acceptance checklist.
```

### PROMPT-20-04 — Admin Dashboard from DB Schema
**Use when:** generating an admin UI over an existing database schema.
**Output:** read/write admin interface with safe defaults and audit logging.
**Prompt:**
```text
ROLE: You are building an admin dashboard over an existing schema.
STACK: {{admin_framework_or_custom}} + {{database}}; existing schema: {{schema_description}}.
SURFACE: table views per entity (filter, sort, paginate), record detail with related records, edit forms generated from schema, destructive-action confirmations.
CONSTRAINTS:**
- Read-only by default: every mutation is opt-in per entity, and destructive actions require typed confirmation plus soft-delete where the schema supports it.
- Guard sensitive columns (credentials, tokens, PII fields from {{schema_description}}): mask by default and never include them in list views; log every access.
- Respects existing DB: no schema changes without explicit approval; queries must use indexes you verified exist.
- Plan first: entity-to-view mapping, generated-form rules, file tree; wait for my OK.
- Tests: per-entity API tests plus a permission test proving unprivileged access is denied; iterate until green.
OUTPUT FORMAT:
1. Entity-to-view mapping with sensitive-column flags.
2. Plan awaiting OK.
3. Implementation with verification transcript.
4. Acceptance checklist.
```

### PROMPT-20-05 — CLI Tool with Subcommands and Config
**Use when:** building a command-line tool with structured subcommands.
**Output:** CLI skeleton with subcommands, config file handling, and tested commands.
**Prompt:**
```text
ROLE: You are building a production-grade CLI.
STACK: {{language}} + {{cli_framework}}; package/distribution: {{packaging}}.
FEATURES: subcommands: {{subcommand_list}}; global flags (config path, verbose, json output); config file at {{config_format_and_locations}}.
CONSTRAINTS:**
- Each subcommand is a separate module with: argument parsing, validation, error messages that say what to do next, and a --help example.
- Config resolution order: explicit flag > env var > config file > defaults; document it in --help and README.
- Errors exit with distinct codes; machine-readable (json) output mode for every subcommand.
- No destructive default: destructive subcommands require an explicit flag; show a dry-run mode where applicable.
- Tests: unit tests per subcommand plus golden-file tests for help text and config resolution; name commands and iterate until green.
OUTPUT FORMAT:
1. Command tree and flag table.
2. Config-resolution spec.
3. Implementation with per-command verification.
4. Acceptance checklist.
```

### PROMPT-20-06 — Browser Extension
**Use when:** building a browser extension (popup + content script + storage).
**Output:** manifest, popup UI, content script, storage schema, and tested flows.
**Prompt:**
```text
ROLE: You are building a cross-browser extension (MV3).
STACK: target browsers: {{browsers}}; build tooling: {{build_tool}}; UI: {{ui_approach}}.
FEATURES: popup: {{popup_features}}; content script: {{content_features}}; storage: {{storage_needs}}; permissions: minimal set derived from features.
CONSTRAINTS:**
- Manifest permissions must be justified per feature; list each permission and why it is needed; request the minimal host access.
- Storage schema is versioned with a migration path; describe it before coding.
- Content script must be idempotent on SPA navigations and isolated from page JS; state the injection strategy.
- No remote code execution; all logic bundled; CSP-compliant.
- Plan first: manifest sketch, message protocol (popup <-> content <-> background), file tree; wait for my OK.
- Tests: unit tests for pure logic plus a manual test checklist for browser flows; automated tests where {{build_tool}} supports it.
OUTPUT FORMAT:
1. Manifest sketch with permission justification.
2. Message protocol and storage schema.
3. Implementation with verification.
4. Manual acceptance checklist per browser.
```

### PROMPT-20-07 — Landing Page + Waitlist
**Use when:** shipping a marketing landing page with waitlist signup.
**Output:** landing page with analytics events and a waitlist backend.
**Prompt:**
```text
ROLE: You are building a landing page with waitlist capture.
STACK: {{frontend_approach}} + {{backend_or_form_provider}} + analytics via {{analytics_tool}}.
SURFACE: sections (hero, value props, social proof, FAQ, signup), waitlist form (email validation, dedup, success state), analytics events.
CONSTRAINTS:**
- Analytics plan first: event taxonomy (page_view, cta_click, waitlist_submit with properties) implemented per {{analytics_tool}}'s real API — verify the API against docs, no invented calls.
- Form: client validation plus server-side validation, duplicate-email handling, rate limiting on submit, and a privacy note.
- Performance: no render-blocking third-party scripts; lazy-load non-critical assets; state the budget (e.g., LCP under 2.5s on 4G).
- Accessibility: semantic landmarks, labeled form, keyboard navigable, contrast-checked palette.
- Tests: API tests for submit/dedup/rate-limit; run and iterate until green.
OUTPUT FORMAT:
1. Event taxonomy table.
2. Page structure and content draft.
3. Implementation with verification.
4. Acceptance checklist (functional + a11y + performance budget).
```

### PROMPT-20-08 — File Upload + Processing Pipeline
**Use when:** building upload-then-process functionality.
**Output:** upload API with validation, async processing, status tracking, and tests.
**Prompt:**
```text
ROLE: You are building a file-upload and processing pipeline.
STACK: {{backend_framework}} + {{storage}} + {{queue_or_worker}}; file types: {{accepted_types_and_limits}}.
FLOW: upload (chunked or direct) -> validation -> enqueue -> process -> notify -> deliver result.
CONSTRAINTS:**
- Security: type and size validation server-side (never trust client), randomized storage keys, no execution of uploaded content, virus-scan hook point.
- Scale design: state how {{queue_or_worker}} handles retries, idempotency keys, and poison messages (DLQ); describe before coding.
- Status API: clients poll or subscribe for processing state; define the state machine (uploaded, queued, processing, done, failed) and its transitions.
- Large files: resumable or chunked upload strategy stated explicitly.
- Plan first: flow diagram, state machine, file tree, verification commands; wait for my OK.
- Tests: upload validation cases, processing success/failure/retry paths; iterate until green.
OUTPUT FORMAT:**
1. Flow diagram and state machine.
2. Plan awaiting OK.
3. Implementation with verification.
4. Failure-mode table and acceptance checklist.
```

### PROMPT-20-09 — Multi-User Todo with Sharing
**Use when:** building a collaborative todo app with permissions.
**Output:** todo CRUD plus sharing, permission checks, and tests.
**Prompt:**
```text
ROLE: You are building a multi-user todo app with sharing and roles.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}.
DATA MODEL: users, todo_lists, list_members (role: owner/editor/viewer), todos (order, done, due).
SURFACE: my lists, shared-with-me, list view with drag ordering, share dialog (invite by email, role pick, revoke).
CONSTRAINTS:**
- Every endpoint enforces membership and role server-side; write a permission matrix (role x action) first and test every denied case.
- Sharing flow: invite -> accept -> membership; handle revoke and self-removal; state behavior for the sole owner leaving (transfer or block).
- Ordering: define the ordering mechanism (e.g., fractional indexing or array swap) and its concurrency behavior.
- Realtime or optimistic updates: pick one, justify, and define conflict handling.
- Plan first: permission matrix, schema, route table; wait for my OK; tests iterate until green.
OUTPUT FORMAT:**
1. Permission matrix.
2. Plan awaiting OK.
3. Implementation with verification transcript.
4. Acceptance checklist including all denied-permission cases.
```

### PROMPT-20-10 — E-Commerce Checkout Flow
**Use when:** building a checkout flow with mock payments.
**Output:** cart, checkout, mock payment provider, order lifecycle, and tests.
**Prompt:**
```text
ROLE: You are building an e-commerce checkout with a mock payment provider.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}; payments: mock provider implementing {{real_provider}}'s webhook shape.
DATA MODEL: products, cart, cart_items, orders, order_items, payments (status), inventory holds.
SURFACE: product list, cart, checkout (address, totals), payment step, order confirmation, order status page.
CONSTRAINTS:**
- Money handled in integer minor units; totals computed server-side; no client-trusted prices.
- Order lifecycle state machine: created -> payment_pending -> paid -> fulfilled / failed / refunded; define transitions and who triggers each.
- Webhook processing: signature verification (mock secret), idempotency on event IDs, and reconciliation on mismatch.
- Inventory: hold on checkout initiation with expiry; state the race-condition handling.
- Plan first: state machine, webhook design, file tree; wait for my OK.
- Tests: totals math, state transitions, webhook idempotency, inventory race; iterate until green.
OUTPUT FORMAT:**
1. Order state machine diagram.
2. Plan awaiting OK.
3. Implementation with verification.
4. Acceptance checklist.
```

### PROMPT-20-11 — Job Board with Search and Filters
**Use when:** building a job-board with posting, search, and filters.
**Output:** posting flow, search/filter API, and tests including filter-combination cases.
**Prompt:**
```text
ROLE: You are building a job board.
STACK: {{frontend_framework}} + {{backend_framework}} + {{search_approach}} (database LIKE, full-text, or search engine).
DATA MODEL: companies, jobs (title, description, location, remote_policy, salary_range, tags, status), applicants, applications.
SURFACE: job list with search box and filters (location, remote, salary band, tag), job detail with apply form, employer post-job flow, application tracking view.
CONSTRAINTS:**
- Search spec: define which fields are full-text, which are facets, and how they combine; state pagination under every filter combination.
- Salary filtering must handle ranges-overlap logic (job range vs filter range); write that predicate explicitly and test boundary cases.
- Employer permissions: only the owning employer/admin can edit or view applicants of a job; test every unauthorized case.
- Input handling: posting form validates and sanitizes; describe XSS handling for job descriptions (rendering strategy).
- Plan first: search spec, schema, route table; wait for my OK; iterate tests until green.
OUTPUT FORMAT:**
1. Search/filter spec with combination matrix.
2. Plan awaiting OK.
3. Implementation with verification.
4. Boundary test list (salary edges, empty results, unicode) and acceptance checklist.
```

### PROMPT-20-12 — Booking/Appointment System
**Use when:** building appointment booking with availability logic.
**Output:** availability engine, booking flow with conflict handling, and tests.
**Prompt:**
```text
ROLE: You are building a booking/appointment system.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}.
DATA MODEL: providers, services (duration, price), availability_slots, bookings (status), customers.
SURFACE: provider/service directory, availability calendar view, booking flow (pick slot, confirm), provider schedule management, booking management (cancel/reschedule).
CONSTRAINTS:**
- Availability rules: working hours, breaks, buffer between appointments, timezone handling — define each as data or config and state the DST policy.
- Booking must be race-safe: two clients booking the same slot yields one success; describe the mechanism (constraint, transaction, or lock) before coding.
- State machine: requested -> confirmed -> cancelled / completed / no-show; define allowed transitions and who triggers them, with notifications per transition.
- Rescheduling: atomic move with the same race protection; define the policy on cutoff windows.
- Plan first: availability model, state machine, conflict-handling design; wait for my OK.
- Tests: overlap cases, DST boundary, double-book race, invalid transitions; iterate until green.
OUTPUT FORMAT:**
1. Availability model and DST policy.
2. State machine diagram.
3. Implementation with verification.
4. Acceptance checklist.
```

### PROMPT-20-13 — RSS/Reader App
**Use when:** building an RSS reader with feed management.
**Output:** feed parser, polling/refresh, read-state sync, and tests.
**Prompt:**
```text
ROLE: You are building an RSS/Atom reader.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}; parsing: {{feed_parsing_approach}}.
DATA MODEL: feeds (url, title, fetch errors, last_fetched), entries (guid, title, content hash, published), users, subscriptions, read_states, stars.
SURFACE: subscribe/unsubscribe, feed list with unread counts, entry list (newest first), reader view, mark-read/star actions.
CONSTRAINTS:**
- Feed handling: guid-then-content-hash dedup strategy, malformed-feed tolerance with per-feed error state and backoff on repeated failure; describe both before coding.
- Fetch scheduling: define refresh policy (interval, backoff, manual) without inventing scheduler APIs — verify against the chosen stack's real options.
- Read state: per-user, synced across devices; define the sync model (last-read cursor vs per-entry flags) and justify.
- Security: SSRF protection on feed URLs (block internal ranges) — state the validation rule.
- Plan first: schema, dedup algorithm, refresh design; wait for my OK; tests iterate until green.
OUTPUT FORMAT:**
1. Dedup and error-handling spec.
2. Plan awaiting OK.
3. Implementation with verification.
4. Acceptance checklist including malformed-feed fixtures.
```

### PROMPT-20-14 — URL Shortener with Analytics
**Use when:** building a link shortener with click analytics.
**Output:** shortlink CRUD, redirect with tracking, analytics aggregation, and tests.
**Prompt:**
```text
ROLE: You are building a URL shortener with click analytics.
STACK: {{backend_framework}} + {{database}} + cache: {{cache_choice}}.
DATA MODEL: links (short_code, target_url, owner, expires_at), clicks (timestamp, referrer, user_agent-derived fields, country derived or null).
SURFACE: create-link API/UI, redirect endpoint, link management (list, edit, deactivate), stats view (clicks over time, top referrers).
CONSTRAINTS:**
- Short codes: collision-safe generation strategy (length, alphabet, uniqueness mechanism); describe before coding.
- Redirect path must be fast: caching layer with invalidation on edit/deactivate; define the cache contract.
- Analytics: record clicks asynchronously without slowing redirects; define the aggregation approach (raw events plus rollups) and its privacy note (no raw UA storage beyond derived fields, unless stated).
- Abuse controls: target-URL validation, rate limits on creation, blocklist hook.
- Plan first: schema, code-generation and cache design; wait for my OK; tests iterate until green.
OUTPUT FORMAT:**
1. Code-generation and cache contract spec.
2. Plan awaiting OK.
3. Implementation with verification.
4. Acceptance checklist.
```

### PROMPT-20-15 — Personal Finance Tracker
**Use when:** building a private finance-tracking app.
**Output:** transaction management, categorization, summaries, and tests.
**Prompt:**
```text
ROLE: You are building a personal finance tracker.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}.
DATA MODEL: accounts, transactions (amount in minor units, type, category, date, note), categories (custom), budgets (category, period, limit), recurring_rules.
SURFACE: dashboard (balances, spending by category, month-over-month), transaction list with filters, add/edit transactions, CSV import, budget setup with progress bars.
CONSTRAINTS:**
- All money in integer minor units; no floats; transfers between accounts must net to zero and be excluded from spending totals — define the double-entry-lite model.
- CSV import: column-mapping step, validation report (accepted/rejected rows with reasons), idempotent re-import; describe the duplicate detection.
- Summaries: define aggregation queries and timezone policy for month boundaries.
- Privacy: local-first or per-user isolation stated explicitly; no third-party analytics on financial data.
- Plan first: schema, import spec, aggregation queries; wait for my OK; tests iterate until green.
OUTPUT FORMAT:**
1. Money model and transfer semantics.
2. Plan awaiting OK.
3. Implementation with verification.
4. Acceptance checklist including CSV edge cases.
```

### PROMPT-20-16 — Quiz/Exam App with Grading
**Use when:** building a quiz platform with authoring and auto-grading.
**Output:** quiz authoring, taking flow, grading engine, and tests.
**Prompt:**
```text
ROLE: You are building a quiz/exam application.
STACK: {{frontend_framework}} + {{backend_framework}} + {{database}}.
DATA MODEL: quizzes, questions (types: single/multi choice, short answer), options, attempts (answers, started/finished), scores.
SURFACE: quiz list, authoring UI (reorder questions, define correct options), taking flow (one question at a time, no back-navigation if {{enforce_forward_only}}), results view with per-question feedback.
CONSTRAINTS:**
- Grading: deterministic server-side scoring; short-answer matching uses stated normalization (trim/case/fuzzy) — define it and its edge cases; never trust client-submitted scores.
- Attempt integrity: server enforces time limit and attempt state; define what happens on disconnect/reload (resume vs forfeit) before coding.
- Scoring rules: partial credit policy for multi-select defined explicitly (all-or-nothing vs proportional) and tested.
- Authoring validation: at least one correct option per question, no empty questions; blocking save otherwise.
- Plan first: scoring spec, attempt state machine; wait for my OK; tests iterate until green.
OUTPUT FORMAT:**
1. Grading and normalization spec.
2. Attempt state machine.
3. Implementation with verification.
4. Acceptance checklist.
```

### PROMPT-20-17 — API-Only Service + OpenAPI + Client SDK
**Use when:** building a backend API designed for SDK generation.
**Output:** API implementation, OpenAPI spec, generated SDK instructions, and contract tests.
**Prompt:**
```text
ROLE: You are building an API-first service.
STACK: {{backend_framework}} + {{database}}; spec: OpenAPI {{openapi_version}}; SDK target: {{sdk_language}}.
DOMAIN: {{api_domain_description}} — endpoints: {{endpoint_list}}.
CONSTRAINTS**
- Spec-first or code-first is chosen explicitly and justified; the OpenAPI document must be the single source of truth consumed by both server validation and SDK generation.
- Versioning strategy (path vs header) and deprecation policy stated before coding.
- Error shape: one consistent problem-details-style envelope with typed error codes; every endpoint documents its error codes.
- Idempotency: mutating endpoints support idempotency keys where retries are expected; define behavior.
- Contract tests: validate the running server against the OpenAPI spec in CI; name the command and iterate until green; do not invent generator flags — verify the generator's real CLI.
OUTPUT FORMAT:**
1. Spec-first/code-first decision and versioning policy.
2. Endpoint table with error codes.
3. Implementation with contract-test transcript.
4. SDK generation instructions and acceptance checklist.
```

### PROMPT-20-18 — Webhook Receiver with Retries and DLQ
**Use when:** building an inbound webhook endpoint that must not lose events.
**Output:** verified receiver, durable queueing, retry/DLQ design, and tests.
**Prompt:**
```text
ROLE: You are building a production webhook receiver.
STACK: {{backend_framework}} + {{queue}} + {{database}}.
CONTEXT: Providers to accept webhooks from: {{provider_list}}; downstream processing: {{processing_description}}.
SURFACE: POST endpoint per provider, signature verification, event persistence, processing worker, DLQ with replay tooling, delivery dashboard or CLI.
CONSTRAINTS**
- Verification per provider's documented scheme (verify against provider docs, not memory); reject unverifiable events with 401 and log the reason.
- Durability: acknowledge only after durable write; define the at-least-once contract and the dedup mechanism (event ID unique constraint).
- Retry policy: backoff schedule, max attempts, DLQ criteria; replay must be manual and idempotent; state the envelope retained for replay.
- Provider quirks: out-of-order delivery and duplicate floods handled; state ordering assumptions per provider.
- Plan first: verification design, retry/DLQ spec; wait for my OK; tests iterate until green.
OUTPUT FORMAT:**
1. Verification and durability spec.
2. Retry/DLQ design.
3. Implementation with verification.
4. Acceptance checklist.
```

### PROMPT-20-19 — Static Blog with MDX
**Use when:** building a static blog/content site with MDX.
**Output:** content pipeline, page templates, and build-verified site.
**Prompt:**
```text
ROLE: You are building a static blog with MDX content.
STACK: {{static_site_framework}} + {{content_format}}; hosting target: {{hosting}}.
CONTENT: frontmatter schema: title, date, tags, draft; posts directory: {{content_location}}.
SURFACE: post list (paginated, tag-filtered), post page (MDX components for code/callouts), tag pages, RSS feed, sitemap, about page.
CONSTRAINTS**
- Content schema enforced at build time: invalid frontmatter fails the build with a readable error; define the validation.
- MDX component mapping: code blocks with titles, callouts, images with dimensions; no raw HTML escapes that break hydration.
- SEO/perf: per-page metadata, OpenGraph tags, generated sitemap and RSS as build artifacts; state the performance budget and check it in build output.
- Draft handling: drafts excluded from production build but viewable in dev; define the mechanism.
- Plan first: content schema, page inventory, build pipeline; wait for my OK; verify with the real build command, iterating until green.
OUTPUT FORMAT:**
1. Frontmatter schema and validation rules.
2. Page inventory with data sources.
3. Implementation with build transcript.
4. Acceptance checklist (a11y, SEO, feed validity).
```

### PROMPT-20-20 — Hackathon MVP in 48 Hours
**Use when:** scoping and building a demo-ready MVP under a hard time limit.
**Output:** a ruthless scope plan, cut list, and a vertical-slice implementation.
**Prompt:**
```text
ROLE: You are a tech lead optimizing a hackathon MVP for demo value per hour.
STACK: {{team_skills_and_preferred_stack}}; judging criteria: {{judging_criteria}}; demo scenario: {{demo_story}}.
CONSTRAINTS:**
- Scope rule: one demo story end-to-end beats five half-features; derive the must-have list from {{demo_story}} alone, then the nice-to-haves, then the cut list — cut list is mandatory, not optional.
- Hard-cut categories: auth beyond demo login, payments, multi-tenancy, admin UIs, analytics beyond demo metrics — include anything else you cut, with reason.
- Fake-vs-real decisions: for each integration point, choose real or mocked and justify by demo risk; mocks must fail gracefully live.
- Technical risk first: the riskiest integration is built first with a timebox; if the box expires, switch to the fallback defined in advance.
- Plan first: feature table (must/nice/cut), architecture sketch, build order with hour estimates labeled ESTIMATE; wait for my OK.
- Verification: one golden-path demo script executed end-to-end before time expires; iterate until green.
OUTPUT FORMAT:**
1. Scope table: must / nice-to-have / cut with reasons.
2. Real-vs-mock decision table with fallbacks.
3. Hour-by-hour build plan (ESTIMATES).
4. Golden-path demo script as the acceptance test.
```
