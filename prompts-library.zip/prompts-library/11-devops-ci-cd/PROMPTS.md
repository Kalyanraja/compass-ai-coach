# DevOps & CI/CD Prompts (PROMPT-11-01 … PROMPT-11-20)

Covers pipeline design, container and Kubernetes review, IaC critique, SLO-based monitoring, incident process, rollout/rollback strategy, secrets hygiene, and migration safety.
Placeholder convention: `{{double_braces}}` mark user-supplied inputs (repo paths, configs, commands); leave them verbatim in the prompt when filling in.

### PROMPT-11-01 — CI Pipeline with Fast-Feedback Ordering
**Use when:** designing or restructuring a CI pipeline for a repo with slow, unordered checks.
**Output:** a staged pipeline plan with job ordering, parallelism, and timing estimates.
**Prompt:**
```text
You are a CI/CD architect. Context: repository at {{repo_description}}, primary language {{language}}, current pipeline {{current_pipeline_or_none}}, target feedback budget {{max_minutes}}.
Task: design a CI pipeline that orders jobs by expected value-per-second: cheapest signal first (lint, format, typecheck, fast unit tests), then medium (build, integration tests), then slow (E2E, security scans, packaging).
Constraints:
- Run independent jobs in parallel stages; gate expensive stages on cheap ones passing.
- Use dependency/path filtering so unaffected packages skip their jobs; state which filter tool (e.g., path filters, Turborepo/Nx affected, Bazel) fits the repo and why.
- Distinguish merge-blocking checks from advisory checks; justify each blocking decision.
- Label every duration estimate as an estimate and say what measurement would replace it.
Do not invent existing CI features — if unsure whether the platform supports a capability, mark it "verify against {{ci_platform}} docs".
Output format: numbered pipeline stages, each with jobs, trigger conditions, runner needs, and estimated duration; end with a rollback note if the new pipeline regresses.
```

### PROMPT-11-02 — Dockerfile Review: Caching & Non-Root
**Use when:** reviewing or hardening a Dockerfile for production images.
**Output:** a line-by-line review plus a rewritten Dockerfile and build-cache analysis.
**Prompt:**
```text
You are a container security and performance reviewer. Context: Dockerfile below, base image {{base_image}}, runtime workload {{workload_type}}, platform {{target_platform}}.
{{dockerfile_content}}
Task: review this Dockerfile for (1) layer-cache efficiency — order steps from least to most frequently changing, minimize cache-busted layers; (2) image size — multi-stage build, .dockerignore gaps, package cleanup; (3) security — non-root user, pinned base digests, no secrets in layers, minimal tooling in the final stage.
Constraints:
- Verify every flag and instruction against the actual Dockerfile syntax and the base image's documented behavior; flag anything you cannot verify as "unverified".
- Present a rewritten Dockerfile as a full replacement, not a diff of fragments.
- For each change, state the impact (build time, image size, attack surface) and label it fact or estimate.
Do not recommend tools that require root inside the container or volume mounts that defeat reproducibility.
Output format: findings table (severity, line, issue, fix), rewritten Dockerfile, and a short checklist for future changes.
```

### PROMPT-11-03 — Docker Compose Local Stack Spec
**Use when:** defining a reproducible docker-compose local dev environment.
**Output:** a complete compose file plus a README snippet and a health-check script.
**Prompt:**
```text
You are a developer-experience engineer. Context: project at {{repo_description}}, services to run {{services_list}}, required backing dependencies {{dependencies}}, ports that must stay fixed {{fixed_ports}}.
Task: produce a docker-compose.yml for a local dev stack that is reproducible, fast to boot, and safe against port conflicts.
Constraints:
- Every service needs an explicit healthcheck; the app service must depend_on with condition: service_healthy.
- Use .env with sane defaults for anything environment-specific; never hardcode credentials — provide placeholder values and document where real ones come from.
- Pin image versions by tag (and digest where practical); justify any :latest.
- Include a named volume per stateful service and a one-command reset path.
- Add resource limits appropriate for a laptop; label them as tunable.
Do not add orchestration features compose cannot express (e.g., complex init ordering beyond healthchecks) — note them as "needs a different tool".
Output format: the compose file, a .env.example, a 10-line README usage section, and a smoke-test command sequence.
```

### PROMPT-11-04 — Kubernetes Manifest Review
**Use when:** reviewing Deployments/Services/etc. before they reach a cluster.
**Output:** a findings report with corrected manifests.
**Prompt:**
```text
You are a Kubernetes production reviewer. Context: manifests for {{app_name}} targeting namespace {{namespace}}, cluster constraints {{cluster_constraints}}, traffic profile {{traffic_profile}}.
{{manifest_content}}
Task: review the manifests for (1) resources — requests/limits set, justified against a stated workload assumption, QoS class implications; (2) probes — liveness vs readiness vs startupProbe distinction, initialDelay/period tuned, failureThreshold sane; (3) availability — replicas, topologySpreadConstraints or podAntiAffinity, disruption budgets, graceful shutdown hooks; (4) security — runAsNonRoot, readOnlyRootFilesystem, seccomp, dropped capabilities, no hostPath/hostNetwork.
Constraints:
- Every recommendation must name the exact manifest field it changes.
- Where a value is a guess (memory limit, probe timing), state the assumption and how to validate it in staging.
- Flag capabilities that require the workload to actually support them (e.g., readOnlyRootFilesystem breaks some apps) as "verify with the app".
Do not invent CRDs or cluster features; if a fix needs an operator or admission policy, say so.
Output format: table of findings (severity, manifest, field, issue, fix), corrected YAML for each changed object, and a pre-merge checklist.
```

### PROMPT-11-05 — Terraform Plan Critique
**Use when:** reviewing a `terraform plan` output before apply.
**Output:** a risk-ordered critique of the plan and apply recommendations.
**Prompt:**
```text
You are an IaC reviewer. Context: plan output below for workspace {{workspace}}, target environment {{environment}}, last applied state {{last_apply_summary}}.
{{terraform_plan_output}}
Task: critique this plan before apply. Identify (1) destructive changes (deletes, force-replacements) and whether each is expected; (2) changes that will cause downtime (resource recreation, ASG replacement, DNS cuts); (3) plan noise from missing import/state drift; (4) cost-impacting changes; (5) violations of common module conventions (hardcoded values, missing tags, unversioned modules).
Constraints:
- Distinguish "plan says destroy+create" from "plan silently replaces" — quote the exact plan lines as evidence.
- For any change you cannot attribute to the stated intent, flag it for human confirmation before apply.
- If the plan appears truncated or refresh-pending, say so and ask for a full refresh plan.
- Label downtime risk as fact (evidence in plan) or estimate (needs provider docs).
Do not recommend `terraform apply -auto-approve`, target applies to skip the review, or state edits.
Output format: risk table (severity, address, action, evidence line, recommendation), a go/no-go recommendation with conditions, and the exact apply command to run if approved.
```

### PROMPT-11-06 — SLO-Based Monitoring & Alerting Design
**Use when:** defining metrics, dashboards, and alerts grounded in SLOs.
**Output:** an SLO doc with SLIs, error budgets, alert rules, and dashboard outline.
**Prompt:**
```text
You are an SRE designing observability. Context: service {{service_name}}, user-facing function {{user_journey}}, current pain {{alerting_pain}}, existing metrics available {{existing_metrics_or_unknown}}.
Task: design an SLO-based monitoring setup: (1) 2–4 SLIs with concrete PromQL/LogQL-style queries (name the metric source you assume and mark assumptions); (2) SLO targets with justification; (3) a multi-window, multi-burn-rate alert set with runbook links per alert; (4) dashboard layout: SLO compliance first, then RED/USE signals.
Constraints:
- Every alert must answer: what symptom, who acts, what runbook, what page vs ticket severity.
- No alert on causes alone (CPU, pod restarts) unless tied to a user-facing symptom; explain any exception.
- If required metrics do not exist, list them as instrumentation gaps with priority.
- Distinguish facts (from provided context) from estimates (typical values) explicitly.
Do not set more than one page-level alert per SLI without justification.
Output format: SLO table (SLI, query, target, window), burn-rate alert definitions with thresholds, dashboard section spec, and instrumentation-gap list.
```

### PROMPT-11-07 — Incident Postmortem Facilitator
**Use when:** running or writing a blameless postmortem after an incident.
**Output:** a structured postmortem draft with timeline, contributing factors, and action items.
**Prompt:**
```text
You are a postmortem facilitator. Context: incident summary {{incident_summary}}, impact {{impact_description}}, raw artifacts below (chat logs, alerts, deploy history, metrics snippets).
{{incident_artifacts}}
Task: produce a blameless postmortem: (1) corrected, sourced timeline (every entry cites which artifact it came from); (2) contributing factors separated into trigger, latent conditions, and detection gaps; (3) what went well / what went poorly in response; (4) action items with owner, due date placeholder, and type (mitigate/prevent/detect).
Constraints:
- Use neutral language: describe systems and decisions, never assign blame to people.
- Mark any timeline entry that is inferred rather than evidenced, and list what evidence would confirm it.
- If artifacts are insufficient to reconstruct the timeline, list the missing evidence explicitly instead of guessing.
- Distinguish "stated in artifacts" from "my inference" for every root-cause claim.
Do not declare a single root cause when multiple contributing factors exist; present the full causal chain.
Output format: markdown postmortem with the sections above, plus a 5-line executive summary suitable for stakeholders.
```

### PROMPT-11-08 — Feature-Flag Rollout Plan
**Use when:** planning a gradual release behind feature flags.
**Output:** a rollout plan with flag configuration, stages, kill criteria, and cleanup tasks.
**Prompt:**
```text
You are a release engineer. Context: feature {{feature_description}}, flag system {{flag_platform}}, blast radius if broken {{blast_radius}}, rollback mechanism {{rollback_mechanism}}.
Task: design a feature-flag rollout: (1) flag shape — boolean vs percentage vs targeting rules, and why; (2) staged rollout (internal → canary cohort → percentage ramps → full) with entry/exit criteria per stage; (3) kill criteria — concrete metric thresholds that trigger automatic or manual disable; (4) observability — which dashboards/alerts watch the rollout; (5) cleanup — flag retirement task and deadline.
Constraints:
- Each stage must have a minimum soak time and a named approver placeholder.
- Kill criteria must be measurable and pre-agreed, not "if something looks wrong".
- Cover the "flag off" path: does the code behave correctly and performantly when the flag is disabled (cold path)?
- Label metric thresholds as estimates to be tuned with baseline data.
Do not design around flags that require code deploys to toggle; if the platform lacks runtime toggles, state that limitation first.
Output format: rollout stage table (cohort, percentage, soak, entry criteria, exit criteria), kill-criteria list with thresholds, monitoring checklist, and cleanup checklist.
```

### PROMPT-11-09 — Rollback Strategy Design
**Use when:** defining how to undo a deployment safely.
**Output:** a rollback runbook with decision tree, commands, and data-migration handling.
**Prompt:**
```text
You are a release-safety engineer. Context: deployable {{artifact_description}}, deployment mechanism {{deploy_mechanism}}, data changes involved {{data_changes}}, previous version {{previous_version}}.
Task: design a rollback strategy covering: (1) trigger conditions — which signals authorize rollback vs forward-fix; (2) rollback procedure — exact commands/steps with expected output at each step; (3) data compatibility — will the old code run safely against new data/schema? If not, define the forward-compatible migration or the restore procedure; (4) verification — how to confirm rollback health; (5) communication — who is notified, with a template message.
Constraints:
- If the deploy includes irreversible data migrations, state that rollback is not possible and a forward-fix or restore-from-backup plan is required; give that plan.
- Every command must be copy-paste runnable against the stated mechanism; mark any step that needs credentials or elevated access.
- Include a decision tree: symptom → diagnose → rollback or forward-fix, in text form.
- Time-box each phase with estimates labeled as estimates.
Do not assume blue-green or canary infrastructure exists unless stated; if it does not, design for the available mechanism.
Output format: decision tree, numbered rollback runbook, data-compatibility section, verification checklist, and comms template.
```

### PROMPT-11-10 — Environment Promotion Design
**Use when:** designing how changes flow dev → staging → prod.
**Output:** a promotion design with environment definitions, gates, and configuration strategy.
**Prompt:**
```text
You are a platform engineer. Context: environments today {{current_environments}}, team size {{team_size}}, compliance needs {{compliance_requirements}}, deployment tooling {{deploy_tooling}}.
Task: design an environment-promotion model: (1) environment inventory with purpose and data strategy per environment (synthetic, anonymized, prod-copy); (2) promotion gates between environments — automated checks plus human approvals, and who owns each gate; (3) configuration management — how config differs per environment without per-env code branches; (4) drift handling — how environments stay reproducible (infra as code, image immutability).
Constraints:
- Environments should differ only by configuration, never by artifact; justify any exception.
- Gates must be objective (test results, policy checks) rather than "someone clicks approve" wherever possible.
- For any approval gate, define the approver role and what evidence they review.
- If compliance requires separation of duties, map it explicitly to the gate design.
Do not recommend more environments than the team can realistically maintain; state the maintenance cost of each.
Output format: environment table (name, purpose, data, gates in/out), gate definitions with owners, config strategy, and drift-control mechanisms.
```

### PROMPT-11-11 — Secrets-in-CI Audit
**Use when:** auditing CI configuration and pipeline code for secret leakage.
**Output:** an audit report with leak findings, severity, and remediation steps.
**Prompt:**
```text
You are a security engineer auditing CI. Context: CI configs below from {{ci_platform}}, related scripts included.
{{ci_config_and_scripts}}
Task: audit for secrets exposure: (1) secrets in plaintext (files, inline env vars, echoed in logs); (2) overly broad secret scoping — org-level secrets available to untrusted jobs, secrets passed to fork PRs; (3) leakage vectors — set -x output, debug logging, artifacts/caches containing secrets, error messages; (4) weak handling — secrets in env vars consumed by untrusted actions, no rotation after exposure.
Constraints:
- Cite the exact file and line for every finding; if line numbers are unavailable, quote the exact text.
- Rate severity by exploitability, not just presence (a masked-but-reusable secret vs a public one).
- For each finding give the concrete fix, and check the fix against the platform's documented secret mechanisms — flag as "verify in docs" where unsure.
- Note what you cannot determine from static review (runtime behavior, historical leaks) as audit limitations.
Do not print or repeat any secret value found; reference it by location only.
Output format: findings table (severity, location, vector, fix), platform hardening checklist, and a rotation runbook outline.
```

### PROMPT-11-12 — Build-Time Optimization
**Use when:** a build is too slow and needs a systematic speedup.
**Output:** an optimization plan with measurement method and expected gains per change.
**Prompt:**
```text
You are a build-performance engineer. Context: build system {{build_tool_and_version}}, current duration {{current_duration}}, where time is spent {{profile_data_or_unknown}}, developer count affected {{team_size}}.
Task: create a build-optimization plan: (1) measurement first — how to profile the build (built-in profiler, timestamps, remote-build-observability) and the baseline to record; (2) optimization candidates ordered by expected ROI: caching (local/remote), parallelism, incremental compilation, dependency trimming, task graph fixes, toolchain upgrades; (3) for each candidate: mechanism, effort estimate, expected gain (labeled estimate), and risk.
Constraints:
- Do not recommend a change without a measurement that confirms it addresses the actual bottleneck; if profile data is missing, the first deliverable is the profiling plan.
- Flag optimizations that change build outputs or weaken reproducibility; require verification steps for those.
- Cache correctness (invalidation, poisoning) must be addressed for any caching proposal.
- Effort and gain numbers are estimates — state the confidence.
Do not propose "buy faster machines" as a primary recommendation without first ruling out algorithmic fixes.
Output format: profiling plan, ranked optimization table (change, effort, gain, risk, verification), and a rollout sequence that keeps the build green.
```

### PROMPT-11-13 — Deploy Freeze / Change-Window Planner
**Use when:** planning safe change windows around holidays, launches, or freezes.
**Output:** a change-window policy with calendar rules, exception process, and comms plan.
**Prompt:**
```text
You are a change-management planner. Context: organization {{org_description}}, freeze triggers {{freeze_triggers}}, systems in scope {{systems_list}}, current change process {{current_process}}.
Task: design a deploy-freeze and change-window policy: (1) freeze calendar rules — what triggers a freeze, how long, and lead time for announcing; (2) change windows — standard windows per environment with timezone made explicit; (3) exception process — who can approve an emergency change during a freeze, with what evidence; (4) comms — announcement templates and reminder schedule; (5) freeze-mode guardrails — which automated deploys continue (security patches) vs stop.
Constraints:
- Define "emergency" objectively; anything not meeting it waits.
- Every rule must state its owner role and the enforcement mechanism (CI check, calendar, manual gate).
- If teams span timezones, define a single reference timezone and state it.
- Distinguish policy text (facts you are defining) from estimates (adoption effort).
Do not design a process that requires 24/7 human approval with no fallback; specify what happens when approvers are unreachable.
Output format: policy document with freeze rules, window table, exception flow, comms templates, and an enforcement checklist.
```

### PROMPT-11-14 — Structured Logging Spec
**Use when:** standardizing log output across services.
**Output:** a logging specification with field schema, levels policy, and example outputs.
**Prompt:**
```text
You are an observability engineer. Context: services {{service_list}}, languages/frameworks {{language_stack}}, current logging state {{current_logging}}, log consumers {{log_platform}}.
Task: write a structured-logging specification: (1) required fields per event (timestamp, severity, service, version, trace/span IDs, message) plus optional domain fields; (2) severity-level policy — precise definitions of when to use each level, with examples; (3) conventions — field naming (snake_case), no PII rules, message style (constant strings with fields, not concatenation); (4) performance and sampling guidance for high-volume paths; (5) what NOT to log (secrets, full payloads, health-check noise).
Constraints:
- Provide at least one example JSON log line per severity level, using a realistic scenario from the context.
- Every field must have a type and an example value.
- PII and secrets rules must be concrete (field names to exclude/redact), not "avoid sensitive data".
- Where framework defaults conflict with the spec (e.g., duplicate timestamps), state the override needed.
Do not design a schema so large that emitting it becomes expensive; mark optional fields clearly.
Output format: field schema table, severity policy with examples, redaction rules, and a migration checklist per service.
```

### PROMPT-11-15 — Canary vs Blue-Green Decision & Analysis
**Use when:** choosing or analyzing a deployment strategy for a service.
**Output:** a decision analysis with a recommended strategy and its operational requirements.
**Prompt:**
```text
You are a deployment-strategy analyst. Context: service {{service_description}}, traffic shaping available {{traffic_control}}, infrastructure {{infra_platform}}, session/state characteristics {{statefulness}}, team maturity {{team_level}}.
Task: analyze canary vs blue-green vs rolling for this service: (1) decision criteria — statefulness, request-level traffic splitting capability, rollback speed needs, cost of doubled capacity, testability of the new version; (2) recommended strategy with justification against each criterion; (3) if canary: canary stages, metric-based promotion gates, and abort thresholds; (4) if blue-green: drain/verification/switch procedure; (5) failure modes the chosen strategy does NOT protect against.
Constraints:
- Score each strategy against the criteria in a comparison table; label scores as judgment where not derived from stated facts.
- Every promotion gate must reference a measurable signal and its threshold.
- State infrastructure prerequisites; if the platform lacks them, recommend the closest achievable strategy.
- Call out database compatibility — the strategy only covers app instances if schema changes are backward/forward compatible.
Do not claim zero-downtime if any step (drain, DNS, LB update) has a window of unavailability; quantify it.
Output format: criteria table, recommendation with procedure, gates/thresholds, prerequisites, and explicit non-covered failure modes.
```

### PROMPT-11-16 — GitHub Actions Workflow Review
**Use when:** reviewing a GitHub Actions workflow before merging.
**Output:** a findings report with corrected workflow YAML.
**Prompt:**
```text
You are a GitHub Actions specialist. Context: workflow YAML below, repo trust model {{trust_model}}, self-hosted runners {{runner_setup}}.
{{workflow_yaml}}
Task: review the workflow for: (1) security — script injection via untrusted input (PR titles, branch names), overly permissive GITHUB_TOKEN, third-party actions unpinned, secrets handling, pull_request_target misuse; (2) correctness — trigger conditions, path filters, concurrency groups, checkout of the right ref, matrix explosion; (3) efficiency — redundant jobs, missing caching, oversized matrices, artifact usage; (4) maintainability — duplication, missing workflow_dispatch inputs, naming.
Constraints:
- Pin every recommended action to a full-length commit SHA and say how to verify the SHA (e.g., via the action's releases page); do not trust floating tags.
- Cite the exact YAML line for each finding.
- Verify syntax recommendations against current GitHub Actions documented behavior; mark anything version-dependent as "verify in docs".
- For pull_request_target usage, require an explicit justification and a safe pattern (e.g., no checkout of untrusted code with secrets).
Do not weaken the token below what jobs need; instead, scope permissions per job.
Output format: findings table (severity, line, issue, fix), corrected full workflow YAML, and a checklist for future workflows.
```

### PROMPT-11-17 — On-Call Runbook Builder
**Use when:** writing a runbook for a specific alert or service failure.
**Output:** a complete runbook with diagnostics, mitigations, escalation, and prevention.
**Prompt:**
```text
You are an SRE writing runbooks. Context: alert {{alert_name}}, firing condition {{alert_condition}}, service {{service_name}}, architecture notes {{architecture_notes}}, known past incidents {{past_incidents}}.
Task: write an on-call runbook: (1) overview — what this alert means, typical causes ranked by frequency; (2) triage — read-only diagnostic commands in order (each with expected healthy output and what deviation means); (3) mitigation — immediate actions to reduce impact, ordered by speed vs risk; (4) resolution — root-fix steps or links to owning team; (5) escalation — when to escalate, to whom (role placeholder), with what evidence collected; (6) prevention — follow-up actions that stop recurrence.
Constraints:
- Every diagnostic command must be safe/read-only; if a mitigation command mutates state, mark it clearly and require confirmation.
- Include expected output for each diagnostic; write "varies by version — verify against {{service_version}}" where output differs.
- Time-box: state rough time estimates per section, labeled as estimates.
- If past incidents are provided, incorporate their root causes as first-check items.
Do not include commands that delete data, restart production databases, or rotate credentials without an explicit approval step.
Output format: runbook markdown with the sections above, formatted for copy-paste during an incident.
```

### PROMPT-11-18 — Infrastructure Drift-Detection Plan
**Use when:** production infra has drifted from IaC and needs detection + remediation.
**Output:** a drift-detection design with tooling options, workflow, and remediation policy.
**Prompt:**
```text
You are a platform engineer. Context: IaC stack {{iac_tooling}}, cloud/provider {{cloud_provider}}, known drift incidents {{known_drift}}, change channels {{change_channels}} (console, CLI, other teams).
Task: design a drift-detection plan: (1) detection layers — scheduled plan/refresh drift detection, real-time event-based detection (cloud trail events), and their tradeoffs; (2) scope — which resources/classes are drift-critical vs noisy, and how to suppress known-benign drift; (3) workflow — detect → ticket → human review → either import-to-code or revert, with SLAs per severity; (4) prevention — least-privilege console access, CI-only applies, policy checks; (5) tooling recommendation with justification against the stated stack.
Constraints:
- Recommend tools that actually integrate with the stated IaC tool and provider; flag any capability you cannot verify as "verify in docs".
- Define what counts as drift vs intentional emergency change (audit trail requirement).
- Detection frequency and SLAs are estimates; label them and state the risk of slower detection.
- Include a first-run remediation backlog triage method (age × blast radius).
Do not propose auto-reverting drift without human review; state why that is unsafe.
Output format: detection architecture description, severity policy, workflow diagram in text, tooling comparison table, and prevention checklist.
```

### PROMPT-11-19 — Infrastructure Cost-Optimization Review
**Use when:** reviewing cloud spend for savings without hurting reliability.
**Output:** a cost review with prioritized savings, reliability impact, and verification plan.
**Prompt:**
```text
You are a FinOps engineer. Context: monthly spend {{spend_summary}}, top cost services {{top_services}}, workload characteristics {{workload_profile}}, reliability constraints {{reliability_requirements}}.
Task: perform a cost-optimization review: (1) quick wins — obvious waste: idle resources, orphaned volumes/snapshots, oversized always-on dev environments, unutilized reserved capacity; (2) structural optimizations — right-sizing, spot/preemptible usage where safe, storage tiering, scheduling non-prod; (3) for each recommendation: expected monthly saving (estimate with confidence), implementation effort, and reliability risk; (4) guardrails — which optimizations are forbidden by the stated reliability requirements.
Constraints:
- Never recommend savings that violate the stated reliability constraints; if a constraint makes a common optimization unsafe, say so explicitly.
- Savings figures must be labeled estimates and show the calculation inputs from the provided data; where data is insufficient, say "insufficient information" and list what data would enable the estimate.
- Right-sizing must include a measurement period requirement (e.g., 14–30 days of utilization) before acting.
- Include a rollback note for every change.
Do not recommend reserved-capacity commitments without utilization evidence.
Output format: findings table (item, action, est. saving, effort, risk), guardrail list, prioritized execution sequence, and ongoing monitoring recommendations.
```

### PROMPT-11-20 — Zero-Downtime Migration Checklist
**Use when:** planning a production migration (schema, service, or data store).
**Output:** an execution checklist with expand/contract steps, verification gates, and rollback points.
**Prompt:**
```text
You are a migration engineer. Context: migration type {{migration_type}}, system {{system_description}}, current and target state {{from_to}}, traffic level {{traffic_profile}}, maintenance window allowed {{window_policy}}.
Task: build a zero-downtime migration execution checklist using expand/contract where applicable: (1) pre-migration — backups/restore verification, capacity headroom, feature-flag or compatibility requirements, stakeholder sign-offs; (2) expand phase — additive changes only, dual-write or backfill strategy, reconciliation verification; (3) cutover — traffic switch procedure with verification at each step; (4) contract phase — old-path removal only after soak period; (5) rollback points — what is reversible at each phase and what is not.
Constraints:
- Every step needs: command/action, expected result, verification check, and rollback action.
- If any phase is irreversible (destructive schema change, data format change), isolate it, delay it to the contract phase, and require an explicit gate.
- Backfill/reconciliation must define tolerance (row counts, checksums, lag limits) as measurable thresholds.
- Time estimates per phase are estimates — label them.
- State explicitly which steps require read-only vs write access and which need downtime if the expand/contract assumption fails.
Do not permit "drop old column" in the same release that introduces the new one; enforce at least one full deploy cycle between expand and contract.
Output format: numbered checklist grouped by phase, with a rollback column and go/no-go gates marked.
```
