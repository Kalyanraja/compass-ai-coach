# 17 — Analytics & Growth

Covers event tracking, experimentation, funnels, retention, metrics design, and decision memos. Placeholder convention: anything in `{{double_curly_braces}}` is user-supplied input — replace it before sending; for optional context, leave the braces with an empty value rather than deleting them.

### PROMPT-17-01 — Event Tracking Plan
**Use when:** defining a new analytics event taxonomy for a product.
**Output:** event dictionary with naming, properties, and triggers ready for implementation.
**Prompt:**
```text
You are a product-analytics engineer writing an event-tracking plan.
CONTEXT: Product: {{product_description}}. Key user journeys: {{user_journeys}}. Analytics tool: {{analytics_tool}}. Existing events (if any): {{existing_events}}.
TASK: Define the event taxonomy: event names, triggers, properties, and ownership rules.
CONSTRAINTS:
- Follow verb_noun naming (e.g., checkout_started); one event per observable action; no events for UI clicks that carry no decision value.
- Every event lists: name, trigger condition, all properties with type and example, and whether it fires client- or server-side.
- Every property must answer a stated analytical question; drop properties with no question attached and note what was cut.
- Flag duplicate or overlapping events against {{existing_events}} instead of adding near-duplicates.
OUTPUT FORMAT:
1. Event dictionary table: name | trigger | properties (typed) | side | question it answers.
2. Property-convention rules (casing, IDs, timestamps).
3. Cut list: considered events that were rejected and why.
4. QA checklist for verifying instrumentation after release.
```

### PROMPT-17-02 — Funnel Analysis Design
**Use when:** designing a funnel to diagnose where users drop off.
**Output:** funnel definition with steps, edge-case rules, and expected diagnostic output.
**Prompt:**
```text
You are a product analyst designing a funnel analysis.
CONTEXT: Product flow: {{flow_description}}. Goal: {{goal}}. Time window expectations: {{time_window}}. Known complicating behaviors (refresh, back button, multi-device): {{complicating_behaviors}}.
TASK: Define the funnel steps and the measurement rules precise enough to implement in SQL or an analytics tool.
CONSTRAINTS:
- Each step needs a precise inclusion rule (event + property filters); fuzzy steps like "engaged" are forbidden unless operationally defined.
- Explicitly define: step ordering (strict vs any-order), conversion window, dedup within step, and how back-navigation is handled.
- State at least three ways the funnel can be misleading (e.g., event loss, step definition drift) and how to sanity-check each.
- Label all assumptions about user behavior as ASSUMPTIONS with a suggested validation query or check.
OUTPUT FORMAT:
1. Step table: order | step name | inclusion rule | exclusion rule.
2. Measurement rules paragraph (ordering, window, dedup, back-nav).
3. Misleading-funnel risk table with mitigation per risk.
4. Output spec: table or chart the analysis should produce and the decision it supports.
```

### PROMPT-17-03 — A/B Test Design
**Use when:** designing an experiment before launch.
**Output:** experiment spec: hypothesis, randomization, power analysis, guardrails, decision rules.
**Prompt:**
```text
You are an experimentation scientist designing an A/B test.
CONTEXT: Change: {{change_description}}. Primary metric: {{primary_metric}}. Baseline rate and variance (if known): {{baseline_stats}}. Available traffic: {{traffic}}. Risk tolerance: {{risk_tolerance}}.
TASK: Produce a full experiment spec, including a power analysis and stopping rules.
CONSTRAINTS:
- Compute required sample size and duration from the inputs; if inputs are missing, say "insufficient information" and give the formula plus what to measure instead of inventing numbers.
- Define one primary metric, secondary metrics, and guardrail metrics; the decision rule keys on the primary metric only.
- Specify randomization unit (user/session) and justify it against the change's effect scope.
- No peeking: state the analysis cadence and the correction or fixed-horizon rule used.
- Call out interaction risks with other running experiments or seasonality.
OUTPUT FORMAT:
1. Hypothesis (one sentence, falsifiable) and success criteria.
2. Power analysis: effect size, alpha, power, required sample, duration — labeled FACT or ESTIMATE per input.
3. Metrics table: primary/secondary/guardrail with definitions.
4. Randomization and exclusion rules.
5. Decision procedure: ship, iterate, or abandon, with thresholds.
```

### PROMPT-17-04 — Metrics Tree / North Star
**Use when:** deriving a metrics tree or north-star metric for a product.
**Output:** metric hierarchy from north star down to input metrics, with definitions.
**Prompt:**
```text
You are a metrics architect building a metrics tree.
CONTEXT: Product and business model: {{product_and_model}}. Candidate north stars: {{candidates}}. Current team's focus: {{team_focus}}. Data availability: {{data_availability}}.
TASK: Derive a north-star metric and decompose it into a tree of input metrics down to team-actionable levers.
CONSTRAINTS:**
- The north star must be: reflective of delivered value, influenceable by the team, and measurable with existing or near-term data; score each candidate against these three and show the scores.
- Every metric in the tree gets a precise definition: formula, data source, owner, and current value if known (else "to be measured").
- Cut branches that no team action can influence; name the team that owns each remaining leaf.
- Do not average away segment differences; note where the aggregate metric hides opposing segment trends.
OUTPUT FORMAT:
1. Candidate scoring table with the winner and why.
2. Tree diagram: north star -> 3-6 inputs -> levers.
3. Metric dictionary for every node (formula, source, owner).
4. Anti-patterns section: what this metric incentivizes and how to counter it.
```

### PROMPT-17-05 — Decision-Oriented Dashboard Spec
**Use when:** speccing a dashboard that should drive decisions, not just display numbers.
**Output:** dashboard spec with decisions, sections, and alert logic.
**Prompt:**
```text
You are an analytics engineer writing a dashboard specification.
CONTEXT: Audience: {{audience}}. Decisions this dashboard should inform: {{decisions}}. Available data: {{data_sources}}. Refresh cadence: {{refresh_cadence}}.
TASK: Spec a decision-oriented dashboard.
CONSTRAINTS:
- Every widget must name the decision it informs; widgets with no decision go in a "cut or backlog" list.
- Lead each section with the headline number and its target/threshold, then breakdowns; no widget without a stated comparison (target, prior period, or segment).
- Define alert conditions: which widgets, what thresholds, who gets notified.
- Say "insufficient information" if the data sources cannot support a required decision, and state the gap.
OUTPUT FORMAT:
1. Decision-to-widget mapping table.
2. Section-by-section layout with widget definitions (metric, comparison, granularity).
3. Alert rules table.
4. Cut/backlog list with reasons.
5. Acceptance checklist for the builder.
```

### PROMPT-17-06 — Retention Cohort Analysis
**Use when:** analyzing retention by cohort to find where users churn.
**Output:** cohort analysis design with retention curves and segment cuts.
**Prompt:**
```text
You are a growth analyst running a retention cohort analysis.
CONTEXT: Product: {{product_description}}. Activation event: {{activation_event}}. Retention definition candidates: {{retention_definitions}}. Data access: {{data_access}}. Suspected issues: {{suspected_issues}}.
TASK: Define and execute (as a spec if no data access) a cohort retention analysis.
CONSTRAINTS:**
- Pick a primary retention definition (e.g., D1/D7/D30 by week-0 cohort) and justify it against the product's natural usage cycle; flag if the cycle is unknown and what to check.
- Plan segment cuts in advance (max 4) to avoid p-hacking; every cut must have a hypothesis attached.
- Include a resurrection/lapsed-user treatment rule: who is counted as retained after inactivity.
- Specify the exact output: cohort table, curve chart, and the three questions the readout must answer.
- Label any benchmark numbers as ESTIMATES unless I provide sources.
OUTPUT FORMAT:
1. Definitions section (cohort, activation, retention, lapsed rule).
2. Analysis plan with segment cuts and hypotheses.
3. Output spec: table shape, chart, and readout questions.
4. Interpretation guide: how to read curve shapes (cliff, plateau, decay) as diagnoses.
```

### PROMPT-17-07 — Activation Moment Identification
**Use when:** trying to find the "aha" moment that predicts retention.
**Output:** ranked candidate activation events with validation methodology.
**Prompt:**
```text
You are a growth analyst hunting for an activation moment.
CONTEXT: Product: {{product_description}}. Candidate user actions: {{candidate_actions}}. Retention outcome: {{retention_metric}}. Historical data description: {{historical_data}}.
TASK: Rank candidate actions by strength of association with retention and propose a validation methodology.
CONSTRAINTS:
- Correlation first, causation never assumed: separate "predictive" from "causal" in your framing, and design the follow-up experiment to test causality.
- Handle reverse causality explicitly: retained users may simply do the action more because they are retained.
- Require a minimum effect-size and prevalence bar: a perfect predictor used by 0.1% of users is not an activation moment.
- If data access is not available, output a SQL/analysis plan instead of inventing results; label all effect sizes as TO-BE-MEASURED.
OUTPUT FORMAT:
1. Candidate scoring rubric (prevalence, effect size, timing) and the ranked list.
2. Analysis plan: queries or model spec.
3. Correlation-vs-causation section with the validation experiment design.
4. Recommendation: which candidate(s) to test as onboarding nudges.
```

### PROMPT-17-08 — Pricing Experiment Design
**Use when:** designing a pricing change test (price point, packaging, or trials).
**Output:** experiment design with guardrails and decision framework.
**Prompt:**
```text
You are a monetization analyst designing a pricing experiment.
CONTEXT: Current pricing: {{current_pricing}}. Proposed change: {{proposed_change}}. Customer base: {{customer_base}}. Legal/billing constraints: {{constraints}}.
TASK: Design the experiment and the analysis plan.
CONSTRAINTS:
- Guardrails are mandatory: churn, refund rate, support tickets, brand/NPS risk; define each with a kill threshold.
- Segment the analysis plan by plan tier and tenure; aggregate-only reads hide the segments that subsidize the average.
- Address price-display fairness: how to avoid showing different prices to comparable customers in ways that breach trust or regulation — flag this as a constraint to clear with counsel, not to solve unilaterally.
- If baseline conversion is unknown, say "insufficient information" and give the pre-experiment measurement plan.
OUTPUT FORMAT:
1. Experiment design: arms, randomization unit, eligibility, duration.
2. Metrics table: primary (revenue per eligible user), secondaries, guardrails with kill thresholds.
3. Analysis plan: segmentation, novelty-effect check, post-period holdout.
4. Decision framework: ship / iterate / abandon with numeric thresholds.
```

### PROMPT-17-09 — Churn-Signal Detector
**Use when:** defining signals that predict churn for intervention.
**Output:** prioritized churn-signal list with intervention mapping and validation plan.
**Prompt:**
```text
You are a data scientist building a churn early-warning spec.
CONTEXT: Product: {{product_description}}. Churn definition: {{churn_definition}}. Interventions available: {{interventions}}. Data available: {{available_data}}.
TASK: Define which signals predict churn, how to validate them, and which intervention each signal triggers.
CONSTRAINTS:**
- Every signal needs: definition (queryable), lead time before churn, expected precision/recall direction, and the intervention it triggers — signals with no attached intervention are cut.
- Rank by actionability times precision, not by raw predictive power; a perfect-but-unactionable signal is useless.
- Propose validation: backtest window, comparison against a baseline (e.g., random or last-login heuristic), and the metric to beat — labeled ESTIMATE where unknown.
- Respect intervention fatigue: cap total intervention volume per user and state the cap logic.
OUTPUT FORMAT:
1. Signal table: name | definition | lead time | precision/recall | intervention.
2. Priority ranking with rationale.
3. Backtest/validation plan.
4. Intervention-volume rules and measurement of intervention impact.
```

### PROMPT-17-10 — Unbiased Survey Design
**Use when:** writing a customer survey whose results must be defensible.
**Output:** survey draft plus a bias self-review.
**Prompt:**
```text
You are a survey-methodology expert writing an unbiased questionnaire.
CONTEXT: Research question: {{research_question}}. Audience: {{audience}}. Delivery channel and length limit: {{channel_and_length}}. Decisions the results will inform: {{decisions}}.
TASK: Draft the survey and audit it for bias.
CONSTRAINTS:
- No leading, loaded, or double-barreled questions; every question gets a one-line rationale for why it is asked and what decision it feeds.
- Use balanced scales (equal positive/negative options), include a neutral option where appropriate, and randomize option order where order effects are plausible.
- Screen out satisficing: include one attention check and avoid matrices over 5 rows.
- Define the analysis plan before finalizing questions: what cross-tabs and what minimum sample per segment are needed; say "insufficient information" if sample expectations are unknown.
OUTPUT FORMAT:
1. Survey draft: questions, types, scales, branching, estimated completion time.
2. Per-question rationale and decision-mapping table.
3. Bias audit: each question screened for leading wording, anchoring, acquiescence, recall bias, with fixes applied.
4. Analysis plan and minimum sample sizes (labeled ESTIMATE if unknown).
```

### PROMPT-17-11 — Experiment Result Read
**Use when:** an A/B test has finished and results need an honest read.
**Output:** verdict memo with guardrail check, peeking assessment, and recommendation.
**Prompt:**
```text
You are an experimentation scientist reading results skeptically.
CONTEXT: Experiment spec: {{experiment_spec}}. Results data: {{results_data}}. Runtime and peeking history: {{peeking_history}}. Business pressure: {{business_pressure}}.
TASK: Produce a verdict memo: ship, iterate, extend, or abandon.
CONSTRAINTS:
- Check methodology before results: sample ratio mismatch, guardrail breaches, segment imbalances, novelty effects; any failed check must be named before any conclusion.
- If unplanned peeks occurred, state how that changes the confidence in the result and what correction applies; do not silently ignore it.
- Report the primary metric result with a confidence interval, not just a point estimate and p-value.
- Separate "statistically significant" from "business-meaningful" with a minimum detectable business effect as the bar.
- If the data is incomplete or inconsistent, say "insufficient information" and list what is needed.
OUTPUT FORMAT:
1. Methodology check table: check | pass/fail | evidence.
2. Primary metric result with interval and business-meaningfulness assessment.
3. Segment and guardrail findings.
4. Verdict with reasoning, plus follow-up experiment if "iterate".
```

### PROMPT-17-12 — Segmentation Analysis
**Use when:** segmenting users/customers to find where value concentrates.
**Output:** segmentation plan or read with stability checks.
**Prompt:**
```text
You are an analyst building a defensible segmentation.
CONTEXT: Base to segment: {{base_description}}. Segmentation goal: {{goal}}. Candidate dimensions: {{candidate_dimensions}}. Data available: {{data_available}}.
TASK: Produce the segmentation: choose dimensions, define segment rules, size them, and profile them.
CONSTRAINTS:
- Segments must be: measurable, mutually exclusive (or explicitly overlapping with rules), large enough to act on (state a minimum size and its basis), and stable over a stated period.
- Profile each segment on behavior and value, but avoid essentializing or sensitive-attribute segments unless the goal explicitly requires it; flag any such request for review.
- Compare at least two segmentation schemes and justify the chosen one against the stated goal.
- Label all sizing numbers as FACT (from provided data) or ESTIMATE.
OUTPUT FORMAT:
1. Chosen scheme with segment definitions (queryable rules).
2. Sizing table: segment | count | % | value metric.
3. Profiles: one paragraph per segment, behavior and value.
4. Rejected schemes and why.
5. Action recommendations per segment with expected effort (ESTIMATE).
```

### PROMPT-17-13 — SEO / Landing Audit
**Use when:** auditing a landing page or site section for organic-search performance.
**Output:** prioritized audit with evidence types and expected impact.
**Prompt:**
```text
You are an SEO auditor reviewing a page for organic acquisition.
CONTEXT: Page/site: {{page_description}}. Target queries: {{target_queries}}. Current performance: {{current_performance}}. Competitors ranking: {{competitors}}.
TASK: Audit the page and produce a prioritized fix list.
CONSTRAINTS:
- Structure the audit: technical (indexability, speed, mobile), on-page (title, headings, intent match), authority (internal/external links), and content depth versus ranking competitors.
- Every finding states the evidence you would check (specific tool or query) — do not claim a defect you cannot verify; mark unverifiable items as "check" not "fail".
- Prioritize by expected impact times confidence; label expected traffic impact as ESTIMATE with reasoning.
- No tricks that violate search-engine guidelines; include a short "do not" list.
OUTPUT FORMAT:
1. Findings table: area | issue | evidence to verify | priority | est. impact.
2. Quick wins (under one day).
3. Content-gap notes versus {{competitors}}.
4. 30-day re-measurement plan.
```

### PROMPT-17-14 — Onboarding Optimization Analysis
**Use when:** improving a new-user onboarding flow.
**Output:** friction diagnosis with prioritized fixes and measurement plan.
**Prompt:**
```text
You are a growth analyst diagnosing onboarding friction.
CONTEXT: Onboarding flow: {{flow_steps}}. Activation target: {{activation_target}}. Funnel data: {{funnel_data}}. User feedback: {{user_feedback}}.
TASK: Diagnose where and why users stall, and prioritize fixes.
CONSTRAINTS:
- Triangulate three evidence types (funnel drop-off, feedback themes, session replay/support notes); conclusions from one source only must be labeled UNCORROBORATED.
- Separate fixable friction (steps, copy, defaults) from structural issues (wrong audience, missing value); only the first belongs in this plan.
- Every recommendation gets: expected mechanism (why it moves the number), effort, and how it will be measured; expected lift labeled ESTIMATE.
- Order recommendations by expected impact divided by effort, and state what you would A/B test vs ship outright.
OUTPUT FORMAT:
1. Friction map: step | drop-off | evidence type | diagnosis.
2. Prioritized fix list with mechanism, effort, and measurement per fix.
3. Test-vs-ship plan.
4. What to instrument before/after to prove the fix worked.
```

### PROMPT-17-15 — Feature Adoption Analysis
**Use when:** a feature is under-adopted and you need to understand why.
**Output:** adoption diagnosis with a discoverability-vs-value breakdown.
**Prompt:**
```text
You are a product analyst diagnosing low feature adoption.
CONTEXT: Feature: {{feature_description}}. Adoption numbers: {{adoption_numbers}}. Target user: {{target_user}}. Alternatives users currently use: {{current_alternatives}}.
TASK: Diagnose the adoption gap: awareness, discoverability, comprehension, or value; then propose interventions per stage.
CONSTRAINTS:
- Split the funnel explicitly: eligible -> aware -> tried -> repeated -> habituated; state which transition is failing and with what evidence.
- Consider that low adoption may be correct (the feature may not matter); include evidence that would support killing or de-prioritizing it.
- Interventions must map to the failing transition; generic "promote it more" recommendations are not acceptable.
- Label all projected gains as ESTIMATES and pair each with the metric that would confirm or refute it.
OUTPUT FORMAT:
1. Adoption funnel with rates and the failing transition highlighted.
2. Diagnosis: which stage fails and why (evidence per claim).
3. Interventions table: stage | intervention | effort | est. effect | measurement.
4. Kill/de-prioritize criteria.
```

### PROMPT-17-16 — Data-Informed vs Data-Driven Memo
**Use when:** a decision is being over- or under-indexed on data.
**Output:** a memo that separates what data can and cannot settle.
**Prompt:**
```text
You are an analyst writing a decision memo about the role of data itself.
CONTEXT: Decision at hand: {{decision}}. Available data: {{available_data}}. Stakeholder positions: {{stakeholder_positions}}. Reversibility of the decision: {{reversibility}}.
TASK: Write a memo separating data-settled questions from judgment calls, and recommend how the decision should be made.
CONSTRAINTS:
- Classify each question as: settled by data (state what analysis settles it), partially informed (state what data narrows), or judgment (state whose judgment and why).
- Identify where stakeholders are debating with numbers that cannot answer the question; name this explicitly.
- Recommend decision mode: data-driven (analysis gates), data-informed (data as one input), or judgment-led with data guardrails; justify by reversibility and cost of being wrong.
- Do not manufacture certainty: end the memo with the residual uncertainty stated plainly.
OUTPUT FORMAT:
1. Question classification table.
2. Misuse-of-data section.
3. Recommended decision mode and process.
4. Residual uncertainties and how they will be monitored after the decision.
```

### PROMPT-17-17 — Growth-Loop Identification
**Use when:** looking for self-reinforcing growth loops in a product.
**Output:** candidate loops mapped with constraints and feasibility ranking.
**Prompt:**
```text
You are a growth strategist mapping growth loops.
CONTEXT: Product: {{product_description}}. User types: {{user_types}}. Current acquisition channels: {{current_channels}}. Viral or network mechanics present: {{network_mechanics}}.
TASK: Identify candidate growth loops (e.g., viral, content, paid, sales) and rank them by fit.
CONSTRAINTS:
- A loop is only valid if every step has a mechanism, a conversion rate, and a limiter; draw each loop step by step with those annotations.
- Compute or estimate loop gain (new users per existing user per cycle) as a range labeled ESTIMATE, and identify which step caps it.
- Distinguish loops from funnels: if a mechanism requires continuous paid input with no reinvestment of output, it is a channel, not a loop — classify honestly.
- Flag dependencies (e.g., two-sided liquidity) that make a loop non-viable below scale.
OUTPUT FORMAT:
1. Loop diagrams (2-4 candidates) with per-step mechanisms and rates.
2. Feasibility ranking with the binding constraint per loop.
3. What to measure to validate the top loop before investing.
4. Loops explicitly rejected and why.
```

### PROMPT-17-18 — Analytics Implementation Audit
**Use when:** auditing existing tracking for dupes, gaps, and drift.
**Output:** audit findings with fix prioritization and governance proposal.
**Prompt:**
```text
You are an analytics auditor reviewing a tracking implementation.
CONTEXT: Product: {{product_description}}. Event schema/code: {{tracking_code_or_schema}}. Known issues: {{known_issues}}. Tooling: {{analytics_tool}}.
TASK: Audit for duplicate events, naming drift, missing properties, and zombie events.
CONSTRAINTS:
- Classify every event: healthy, duplicate (merge candidate), drifted (naming/property inconsistency), zombie (no consumers), or gap (needed per journey, missing).
- For duplicates and drift, propose the canonical form and the migration plan (dual-write window, cutover, cleanup).
- Cross-check against the key user journeys; a journey step with no event is a finding even if the schema looks internally consistent.
- Do not invent consumer information; zombie detection requires consumer data — if absent, list the events to check and against which dashboards/queries.
OUTPUT FORMAT:
1. Event-by-event classification table.
2. Merge/migration plan for duplicates and drift.
3. Gap list mapped to journeys.
4. Governance proposal: naming enforcement, schema review gate, ownership.
```

### PROMPT-17-19 — Qualitative Feedback Synthesis
**Use when:** synthesizing interviews, reviews, or open-text feedback into themes.
**Output:** theme map with evidence counts, quotes, and confidence levels.
**Prompt:**
```text
You are a researcher synthesizing qualitative feedback.
CONTEXT: Feedback source: {{feedback_source_and_size}}. Raw feedback: {{feedback_excerpt_or_data}}. Product area: {{product_area}}. Prior beliefs to test: {{hypotheses}}.
TASK: Synthesize into themes with evidence, separating signal from noise.
CONSTRAINTS:
- Every theme needs: description, count/proportion of feedback supporting it, two verbatim quotes, and whether it confirms or contradicts a stated hypothesis.
- Distinguish frequency from intensity; a rare but severe issue outranks a common minor one — show both dimensions.
- Flag survivorship and source bias: who is not represented in this feedback (e.g., churned users, non-English speakers).
- Do not generalize beyond the sample; state the sample limits in a dedicated section.
- If the excerpt is too small to theme reliably, say "insufficient information" and specify how many more responses are needed.
OUTPUT FORMAT:
1. Theme table: theme | evidence count | quotes | hypothesis relation | confidence.
2. Frequency-intensity map.
3. Representativeness and bias section.
4. Recommended follow-ups ranked by decision impact.
```

### PROMPT-17-20 — Anti-Vanity KPI Review
**Use when:** reviewing a KPI dashboard for vanity or gaming-prone metrics.
**Output:** audit that reclassifies metrics and proposes guardrail pairs.
**Prompt:**
```text
You are a metrics auditor hunting vanity metrics.
CONTEXT: Dashboard or KPI list: {{kpi_list}}. Business model: {{business_model}}. Incentives tied to these numbers: {{incentives}}.
TASK: Audit each KPI: is it actionable, honest, and hard to game? Propose fixes or guardrail metrics.
CONSTRAINTS:
- Test each metric against: does it move when real user value moves; can it rise while the business gets worse; does any team own both the metric and the means to inflate it.
- For every vanity or gaming-prone metric, propose a guardrail metric pair (e.g., MAU with churn; ticket-closed rate with reopen rate) and explain the coupling.
- Classify each KPI: keep, keep-with-guardrail, replace (name the replacement), or drop.
- Where the metric's definition is ambiguous, say "insufficient information" and give the defining question.
OUTPUT FORMAT:
1. KPI audit table: metric | classification | gaming vector | guardrail/replacement.
2. Coupled-metric pairs to adopt.
3. Definitions to tighten (metric | current definition | proposed precise definition).
4. Summary: what the dashboard would look like after the audit.
