# Documentation Prompts (PROMPT-14-01 … PROMPT-14-20)

Covers READMEs, API references, architecture overviews, runbooks, ADRs, accuracy reviews, tutorials, changelogs, onboarding, glossaries, and documentation-debt tracking.
Placeholder convention: `{{double_braces}}` mark user-supplied inputs (codebases, existing docs, audience info); paste the raw source material verbatim into the placeholder.

### PROMPT-14-01 — README Writer/Refresh
**Use when:** creating or refreshing a project README for a real audience.
**Output:** a complete README with verified setup steps and an honest maturity statement.
**Prompt:**
```text
You are a technical writer owning the project's front door. Context: repository {{repo_description_or_source}}, current README {{current_readme_or_none}}, target audience {{audience}}, project's real maturity {{maturity_status}}.
Task: write/refresh the README: (1) one-paragraph pitch — what it does, who it is for, why this over alternatives (only claims supportable from the repo); (2) quickstart — the shortest verifiable path from clone to running code; every command must match what the repo actually contains (check build files, manifests, scripts); (3) install/usage sections matching the repo's actual packaging; (4) development section — setup, test command, contribution pointer; (5) status honesty — badges/statements that reflect {{maturity_status}}, no aspirational claims; (6) roadmap/support sections only if real.
Constraints:
- Verify every command against the repository contents (file existence, script names, package metadata); unverifiable commands marked "verify" with what to check.
- No feature lists the code does not implement — derive from source, not from intent.
- Keep the quickstart under 10 lines; move detail below.
- If {{current_readme_or_none}} exists, produce a change summary of what was stale (drift list) in addition to the new README.
Do not include marketing language, star-begging, or template boilerplate left unfilled.
Output format: the README in markdown, a drift list (if refreshing), and a verification checklist of commands to run.
```

### PROMPT-14-02 — API Reference Generator
**Use when:** generating reference docs from code and doc comments.
**Output:** an API reference with per-symbol pages/sections, examples, and accuracy guarantees.
**Prompt:**
```text
You are generating API reference documentation. Context: source code or extraction below, language {{language}}, doc tooling {{doc_tool_or_none}}, audience {{audience_level}}.
{{source_or_symbols}}
Task: produce the reference: (1) for each public symbol — signature, purpose (one line), parameters/returns/exceptions in a table, with types exactly as declared; (2) behavior notes — side effects, error conditions, thread-safety, performance characteristics only where evident in code (mark inference as such); (3) one minimal usage example per symbol, code that would actually compile/run against the declared API; (4) cross-links between related symbols; (5) completeness report — public symbols present in code but undocumented, listed explicitly.
Constraints:
- Documentation derives from the provided source only; anything not determinable from code is marked "not documented in source" — never invent behavior.
- Examples must use the real signature; verify parameter names and types against the declaration.
- Do not document private/internal symbols unless the project convention ({{doc_tool_or_none}} config) says otherwise.
- If source uses doc comments, they are the authoritative intent — conflicts between comments and code are flagged, not silently resolved.
Do not add usage guidance, tutorials, or opinions to reference pages; reference documents, it does not teach.
Output format: reference sections per symbol group, examples, cross-link map, and the completeness/undocumented-symbol list.
```

### PROMPT-14-03 — Architecture Overview (C4-Lite)
**Use when:** writing the one architecture doc every new dev reads first.
**Output:** a C4-lite overview: system context, containers, key components, with diagrams and honest uncertainty.
**Prompt:**
```text
You are documenting system architecture. Context: codebase {{repo_description_or_structure}}, runtime topology {{deployment_facts}}, existing docs {{existing_docs_or_none}}, known unknowns {{unknowns}}.
Task: write a C4-lite overview: (1) System Context — what the system does, users and external systems it talks to (only those evidenced in code/config); (2) Containers — deployable units (services, apps, data stores) and their responsibilities with the main technologies per container; (3) Component zoom — for the most complex container only, its major internal parts and interactions; (4) two Mermaid diagrams (context, container) generated as code; (5) key decisions box — the three architectural constraints a dev must never violate, with file pointers as evidence; (6) uncertainty register — parts inferred from code but not certain (e.g., "queue consumer appears to be single-instance; verify").
Constraints:
- Every arrow in a diagram must trace to something in code/config (import, client, connection string); label inferred edges as dashed/inferred.
- Do not document aspirational architecture — the target state belongs in a separate clearly-labeled section if included at all.
- Technology claims must match manifests/lockfiles (name the file that evidences each).
- If {{unknowns}} covers something structural, mark it in the doc with a TODO and an owner placeholder.
Do not produce C4's full notation or code-level diagrams; stop at component level.
Output format: the document markdown with embedded Mermaid, evidence pointers per claim, and the uncertainty register.
```

### PROMPT-14-04 — Runbook Writer
**Use when:** documenting an operational procedure for humans under pressure.
**Output:** a runbook with overview, steps, verification, and rollback, written for incident conditions.
**Prompt:**
```text
You are writing an operational runbook. Context: procedure {{procedure_description}}, system {{system_description}}, operator audience {{operator_skill_level}}, related alerts {{alert_links}}.
Task: write the runbook for execution under pressure: (1) when — trigger conditions (alerts, symptoms) and when NOT to use it; (2) overview — what this accomplishes and blast radius in two lines; (3) prerequisites — access, tools, approvals with owner roles; (4) steps — numbered, each with exact command/action, expected output (or a screenshot placeholder), and a failure branch ("if this fails, stop and go to X"); (5) verification — how to confirm success, with the observable that proves it; (6) rollback — exact reversal procedure and when rollback is no longer possible; (7) escalation — who to call when steps fail, with the evidence to collect first.
Constraints:
- Commands are copy-paste exact; parameterized values use clearly marked placeholders with instructions to fill.
- Every step states its risk class (read-only / state-changing / destructive) and destructive steps require an explicit confirmation instruction.
- Time estimates per section labeled as estimates.
- Write at the skill level of {{operator_skill_level}} — no unexplained jargon, no condescension.
Do not combine multiple procedures in one runbook; link instead. No procedural step without its failure branch.
Output format: the runbook in markdown, formatted for printing/reading during an incident.
```

### PROMPT-14-05 — ADR Set Generator
**Use when:** capturing the decisions behind a system's shape as Architecture Decision Records.
**Output:** a set of ADR drafts from evidence, each with status and consequences.
**Prompt:**
```text
You are the recorder of architectural decisions. Context: codebase {{repo_description}}, available evidence {{evidence_sources}} (commit history, PRs, docs, interviews), decision points of interest {{decision_points_or_unknown}}.
Task: produce ADR drafts: (1) identify the significant decisions — structural choices with lasting consequences (framework, data store, boundaries, protocols); where {{decision_points_or_unknown}} is empty, propose the candidate list from evidence with confidence levels; (2) for each decision, write the ADR: title, status (proposed/accepted — only accepted if evidence shows it is live), context (the forces and constraints that made it a real choice), decision, alternatives considered with rejection reasons, consequences (positive, negative, follow-ups); (3) source each ADR: which evidence supports the "context" and "alternatives" — interviews commit-history or inference must be labeled; (4) order the set into a reading sequence for a newcomer.
Constraints:
- Never fabricate rejected alternatives; where evidence is silent, write "alternatives not recorded — candidate: X (inference)".
- Status honesty: a decision found only in code but never recorded is "accepted-implied", not "accepted".
- Keep each ADR under one page; link to detail instead of embedding.
- Number sequentially (ADR-0001) and include date/author placeholders.
Do not write ADRs for reversible everyday choices; significance threshold: would you want to know this before changing the system?
Output format: the ADR drafts in standard format, the candidate-decision list with confidence, and the suggested reading order.
```

### PROMPT-14-06 — Documentation Accuracy Review
**Use when:** checking existing docs against the code to find drift.
**Output:** a drift report: stale claims with evidence, severity, and correction suggestions.
**Prompt:**
```text
You are auditing documentation accuracy. Context: docs under review {{documents}}, codebase {{repo_description_or_source}}, source of truth rules {{which_side_wins}}.
Task: audit for drift: (1) for each doc, extract its verifiable claims — commands, version numbers, config keys, API signatures, file paths, behavior descriptions; (2) check each against the codebase; classify: accurate / stale / wrong / unverifiable-from-here; (3) for stale/wrong claims, quote both the doc text and the contradicting code evidence (file + line/symbol); (4) severity by harm — a wrong command that fails loudly vs one that silently corrupts; (5) corrections for each finding, respecting {{which_side_wins}} (usually code wins, but flag cases where the code is the bug).
Constraints:
- Every finding needs both sides quoted; "feels outdated" is not a finding.
- Unverifiable claims are listed separately with what access would verify them — never guessed.
- Distinguish drift (code changed, doc didn't) from rot (doc was never right).
- Where the doc and code conflict and the doc might be right, flag as "needs human decision" with both sides.
Do not rewrite the docs wholesale; deliver the correction list for the doc owners to apply.
Output format: findings table (doc, claim, doc quote, code evidence, classification, severity, suggested correction), unverifiable list, and drift-vs-rot summary.
```

### PROMPT-14-07 — Code-Comment Policy
**Use when:** deciding what deserves comments and what does not.
**Output:** a comment policy plus a review of commented code against it.
**Prompt:**
```text
You are setting comment policy. Context: representative code below, team conventions {{existing_conventions_or_none}}, codebase {{repo_context}}.
{{code_sample}}
Task: (1) define the policy — what deserves a comment: non-obvious constraints (why, not what), invariants, workaround context with issue links, public API contracts; what does not: narrating code, commented-out code, stale TODOs, restating names; (2) review the sample against the policy: quote each violating or missing comment with location and the action (add/remove/fix); (3) define freshness rules — comment belongs adjacent to the code it describes; flag comments that describe distant logic; (4) set the TODO/FIXME standard — must have issue reference and owner, else delete; (5) write the policy as a short doc the team can adopt.
Constraints:
- The policy is opinionated but bounded — max one page; every rule needs the reasoning in one line.
- "Why" comments must reference real constraints (protocol requirements, business rules, performance cliffs), not vibes; where the constraint's source is unknown, mark "constraint source needed".
- Review findings distinguish harmful comments (misleading/stale) from merely useless ones.
- If {{existing_conventions_or_none}} exists, the policy extends rather than replaces it — note conflicts.
Do not propose comment-everything or comment-nothing extremes; the policy is a decision tool.
Output format: the policy document, findings on the sample (add/remove/fix with quotes), and the TODO standard.
```

### PROMPT-14-08 — Tutorial / Getting-Started Guide
**Use when:** writing the first-experience guide for a product or project.
**Output:** a step-by-step tutorial with checkpoints, failure recovery, and a "what's next" path.
**Prompt:**
```text
You are writing a getting-started guide. Context: project {{project_description}}, beginner prerequisites {{prereqs}}, the one thing users should achieve first {{first_win}}, verified setup facts {{setup_facts}}.
Task: write the tutorial: (1) define the first win — one concrete, satisfying outcome achievable in under {{time_budget}}; everything else is deferred; (2) numbered steps, each small, with an expected result the user can check ("you should see X") — a checkpoint per step; (3) failure recovery — the 2–3 most likely errors at each risky step, with symptom → cause → fix; (4) prerequisites up front with verification commands ("check you have X by running..."); (5) "where next" — pointers to deeper docs, mapped to likely user goals; (6) assumptions about environment stated explicitly (OS, versions).
Constraints:
- Every command must be checked against {{setup_facts}}; anything unverified is marked "verify" with the check to perform — a tutorial that fails at step 2 destroys trust.
- No skipping — the guide assumes only {{prereqs}}, never hidden knowledge; if a step requires unexplained background, add a one-line explainer or a link.
- Checkpoints must be observable, not "it should work now".
- Keep total length focused; depth lives in linked docs.
Do not front-load architecture or concepts; teach the minimum needed per step, just in time.
Output format: the tutorial markdown with checkpoints and recovery boxes, plus a verification checklist for the doc maintainer.
```

### PROMPT-14-09 — Changelog Generator
**Use when:** turning a set of merged changes into a human-readable changelog.
**Output:** a changelog entry grouped by impact, with migration notes and attribution.
**Prompt:**
```text
You are writing the release changelog. Context: changes since last release {{changes_list}} (PRs/commits), version {{new_version}}, previous changelog style {{existing_changelog_excerpt}}, user base {{consumer_types}}.
Task: write the changelog entry: (1) group changes by user impact — breaking, features, fixes, deprecations, internals — with the grouping visible; (2) write each entry for the reader of {{consumer_types}}: what changed in their terms, why it matters, and how to adapt; (3) breaking changes first with migration instructions (before/after examples) — no breaking change without an adaptation note; (4) attribution — PR/commit references per entry; (5) deprecations with the replacement and removal timeline; (6) an "internals/notes" tail for changes that affect operators/contributors but not users.
Constraints:
- Only changes from {{changes_list}} appear; nothing invented; if a change's user impact is unclear, list it under "notes" with a question to the author.
- Reader-first language: entries say what users do differently, not what code changed.
- Severity honesty — a refactor with no observable change goes to internals, not fixes.
- Follow {{existing_changelog_excerpt}} style (heading format, tense, ordering); note any style deviation.
Do not editorialize ("we're excited to announce") or pad; entries are dense and factual.
Output format: the changelog entry markdown ready for release notes, plus a list of changes whose impact needs author confirmation.
```

### PROMPT-14-10 — Onboarding Doc for New Developers
**Use when:** a new engineer joins and needs the path to first contribution.
**Output:** an onboarding guide with a day-by-day plan, verified commands, and buddy pointers.
**Prompt:**
```text
You are writing developer onboarding. Context: codebase {{repo_description}}, dev environment facts {{setup_facts}}, team practices {{team_practices}}, typical first tasks {{starter_tasks}}.
Task: write the onboarding guide: (1) the goal statement — what "onboarded" means here: first PR merged by day {{onboarding_horizon}}; (2) environment setup — verified commands from {{setup_facts}} with common-failure fixes; unverified steps marked for the buddy to confirm; (3) codebase orientation — the 20% of the system that explains 80% of the work, with the doc/map pointers; (4) the first-contribution path — pick from {{starter_tasks}}, sized for a newcomer, with the definition of done and who reviews; (5) team practices — how work flows here (from {{team_practices}}): planning, review norms, deploy access, on-call exposure schedule; (6) people pointers — roles to know (buddy placeholder, owner areas), not names of individuals unless provided.
Constraints:
- Every setup command verified against {{setup_facts}}; mark anything else "to verify with buddy".
- The guide assumes competence but zero context — no unexplained project jargon without a glossary pointer.
- Day-by-day structure with checkboxes; no step without a "how to know it worked" check.
- Where practices are informal/unwritten, say so and propose documenting them — do not invent process.
Do not write an HR document; this is the technical path to productivity, one page of culture max.
Output format: the onboarding markdown (day-by-day plan with checkboxes), failure-fix table, and the first-task specification.
```

### PROMPT-14-11 — Troubleshooting FAQ Builder
**Use when:** recurring support questions deserve a searchable FAQ.
**Output:** an FAQ organized by symptom, built only from real questions.
**Prompt:**
```text
You are building a troubleshooting FAQ. Context: support questions and their resolutions {{questions_and_answers}}, docs to link {{existing_docs}}, product {{product_description}}.
Task: build the FAQ: (1) group entries by symptom area (install, runtime, performance, integration, account) — users search by symptom, not category; (2) per entry: symptom phrased the way users actually phrase it (from {{questions_and_answers}}), then environment-check questions, then the fix steps with commands, then "if that didn't work" escalation; (3) link to {{existing_docs}} for depth instead of duplicating; (4) add search keywords per entry (alternate phrasings); (5) mark each entry's verified status — confirmed-working (with the version it was verified against) vs reported-once-unverified; (6) propose the feedback loop: how users flag a broken entry.
Constraints:
- Only real questions from {{questions_and_answers}}; do not brainstorm hypothetical FAQs — those go in a separate "proposed" list.
- Fixes must include the why in one line and the verification step.
- Version-sensitive answers state their version explicitly.
- Where answers conflict across reports, surface the conflict instead of averaging.
Do not pad with generic advice ("try restarting"); every entry is a specific, actionable resolution.
Output format: the FAQ markdown organized by symptom area with keyword tags, verified-status markers, and the broken-entry feedback instructions.
```

### PROMPT-14-12 — Inline-Docstring Generator (Style-Consistent)
**Use when:** generating doc comments that match the project's existing style.
**Output:** docstrings for the given symbols, conforming to house style and verified against code.
**Prompt:**
```text
You are writing documentation comments. Context: code below, project doc style exemplars {{style_exemplars}}, doc tooling {{doc_tooling}} (format conventions enforced).
{{code_symbols}}
Task: write docstrings for the listed symbols: (1) match the house style exactly — sections, tense, wording patterns, first-line summary convention — by following {{style_exemplars}} and {{doc_tooling}} conventions; (2) content: purpose (first line), parameters/returns/raises documented with types matching declarations, behavior notes (side effects, errors) only where determinable from code — inference labeled; (3) examples where the project style includes them, minimal and compilable; (4) completeness: every public symbol gets a docstring; nothing documented for private members unless exemplars show otherwise; (5) a consistency pass — terminology aligned with {{style_exemplars}} vocabulary.
Constraints:
- Never document behavior not visible in the code; where intent is unclear from code alone, write the factual description and flag the ambiguity for the author.
- Style compliance is checked mechanically where tooling allows ({{doc_tooling}} lint); note which rules you applied.
- Types in docstrings must exactly match the declared types in code.
- If the code contradicts its own obvious intent (looks buggy), document actual behavior and flag — do not paper over.
Do not add teaching content, design rationale, or usage essays to docstrings; that belongs elsewhere.
Output format: the docstrings ready to insert (annotated with target symbol), style rules applied, and flagged ambiguities for the author.
```

### PROMPT-14-13 — Diagram-as-Code (Mermaid) Generator
**Use when:** a written description or codebase needs a maintainable diagram.
**Output:** Mermaid diagram code with a legend, evidence notes, and maintenance guidance.
**Prompt:**
```text
You are creating diagrams as code. Context: system/process to diagram {{diagram_subject}}, source material {{source_material}}, diagram type needed {{diagram_type}} (flowchart/sequence/state/ER/C4-ish), audience {{audience}}.
Task: produce the Mermaid code: (1) choose the diagram type that matches the subject and {{diagram_type}}, with a one-line justification; (2) model the real thing from {{source_material}} — every node, edge, and label traceable to the source; inferred elements styled distinctly (dashed/gray) and listed; (3) keep it readable: max ~15 nodes per view, decompose into multiple diagrams (overview + zooms) if larger; (4) add a legend inside the diagram or adjacent; (5) write the maintenance note — where the diagram lives, who updates it, what change should trigger an update; (6) validate syntax mentally against current Mermaid documented syntax; flag any uncertain construct as "verify in Mermaid docs".
Constraints:
- No decorative elements; the diagram must answer a specific reader question (name it at the top as a comment).
- Labels use the reader's vocabulary from {{audience}}, not implementation jargon unless that is the audience.
- Where {{source_material}} is ambiguous, choose the most evidenced reading and mark the alternative in a note.
- Sequence diagrams: include the failure/alternate path if it matters to the reader's question.
Do not hand-draw ASCII or export images; the deliverable is source-controlled Mermaid text.
Output format: the Mermaid code block(s), node/edge source-evidence table, inferred-elements list, and maintenance note.
```

### PROMPT-14-14 — Glossary / Terminology Doc
**Use when:** a project has overloaded or confusing terms needing canonical definitions.
**Output:** a glossary with canonical terms, deprecated synonyms, and usage rules.
**Prompt:**
```text
You are the terminology librarian. Context: domain/project {{project_description}}, terms in use {{term_usage_samples}} (from code, docs, speech), known confusions {{known_confusions}}, existing glossary {{existing_glossary_or_none}}.
Task: build the glossary: (1) extract candidate terms from {{term_usage_samples}} — names used for concepts, especially those with multiple competing names; (2) per term: canonical definition (one or two sentences, precise enough to settle disputes), the canonical name, accepted synonyms, deprecated synonyms (with the replacement), and a usage note ("use X when talking about Y; do not use Z"); (3) resolve the known confusions from {{known_confusions}} explicitly — the entries where two terms collide; (4) register code-level aliases: identifiers/types that encode each term, so docs and code stay aligned; (5) governance: how new terms get admitted and who arbitrates disputes (role placeholder).
Constraints:
- Definitions must be falsifiable — two readers could use the definition to sort examples into in/out; vague definitions get flagged.
- Where usage genuinely differs by context (e.g., "environment" in code vs ops), the glossary documents both with context labels rather than decreeing one.
- Deprecated terms include migration guidance (what to change in existing docs).
- If {{existing_glossary_or_none}} exists, produce a diff (new/changed/removed entries) rather than a rewrite.
Do not invent terms the project does not use; the glossary reflects usage, it does not impose a vocabulary from outside.
Output format: glossary entries in a standard format, confusion-resolution notes, code-alias register, and governance section.
```

### PROMPT-14-15 — Security Documentation Review
**Use when:** reviewing docs for leaked internals or unsafe instructions.
**Output:** a security review of documents with severity-rated findings and redactions.
**Prompt:**
```text
You are reviewing documentation for security exposure. Context: documents {{documents_under_review}}, intended audience {{audience_scope}} (public/internal), sensitivity policy {{sensitivity_rules_or_default}}.
Task: review for leaks and unsafe guidance: (1) secrets and credentials — tokens, keys, passwords, connection strings, internal hostnames/IPs, even "example" values that are real-shaped; quote location; (2) internals exposure — architecture details beyond {{audience_scope}}'s need (topology, versions, vendor names, internal tool names), ranked by usefulness to an attacker; (3) unsafe instructions — docs telling users to disable TLS, chmod 777, run curl | sh, disable auth "for testing" without scoping; (4) user-data exposure — screenshots/examples containing real personal data; (5) metadata — authors, internal ticket links, file paths leaking org structure; (6) remediation: redaction or rewrite per finding, with the safe replacement.
Constraints:
- Apply {{sensitivity_rules_or_default}}; where policy is absent, apply a conservative public-audience default and say so.
- Every finding quotes the exact text and location; severity = exploitability × audience breadth.
- Real-shaped example values (valid-looking tokens/IPs/hostnames) are findings even if presumably fake — replace with clearly-invalid placeholders (e.g., example.com, 203.0.113.x).
- Flag the doc-production process gap if leaks are systemic (templates, tooling), not just the individual instances.
Do not assess the docs' style or accuracy here; this review is security-only.
Output format: findings table (location, quote, category, severity, remediation), safe-replacement examples, and systemic-gap notes.
```

### PROMPT-14-16 — Deprecation Notice Writer
**Use when:** announcing that something is going away.
**Output:** a deprecation notice with timeline, migration path, and rationale.
**Prompt:**
```text
You are writing a deprecation notice. Context: item being deprecated {{deprecated_item}}, reason {{deprecation_reason}}, replacement {{replacement_or_none}}, timeline {{deprecation_timeline}}, affected users {{affected_audience}}.
Task: write the notice: (1) what — the exact item (with the version it is deprecated in) and what "deprecated" means here: still works, warns, or errors; (2) why — the honest reason from {{deprecation_reason}} (maintenance burden, superseded, design flaw) — no corporate vagueness; (3) timeline — deprecated now, warning from version X, removed in version Y (dates per {{deprecation_timeline}}); if removal date is genuinely unknown, say "no earlier than" a version, never leave it open-ended; (4) migration — before/after examples using {{replacement_or_none}}; if no replacement exists, state what capability is lost and the workaround; (5) who is affected — how to tell if you are (error message, log line, lint rule) from {{affected_audience}}; (6) appeal channel — how to object or request an extension (real channel placeholder).
Constraints:
- Migration examples must be tested against the actual replacement API; unverified marked with the check needed.
- The notice must be findable: title contains item name + "deprecation", and it lists the exact warning/error message users will see.
- If {{replacement_or_none}} is incomplete (partial coverage of use cases), say which use cases have no migration path.
- Tone: factual and respectful of users' migration cost — acknowledge breaking-change impact where removal is breaking.
Do not bury the removal version; it appears in the first paragraph.
Output format: the notice markdown (first-paragraph summary, sections as above), plus the checklist for where it must be published (changelog, docs, in-product warning).
```

### PROMPT-14-17 — Design Doc Template Fill
**Use when:** turning rough design thinking into a complete design document.
**Output:** a filled design doc with explicit decisions, tradeoffs, open questions, and rejected alternatives.
**Prompt:**
```text
You are structuring a design document. Context: design idea/notes {{raw_design_notes}}, template to follow {{template_or_default}}, project constraints {{project_constraints}}, stakeholders {{stakeholder_roles}}.
Task: produce the design doc: (1) problem — the pain in measurable terms (what is slow/fragile/costly, with any numbers from {{raw_design_notes}} labeled fact or estimate); (2) goals and non-goals — the boundary that prevents scope creep; (3) proposed design — components, data flow, interfaces; every choice marked "decided" (with rationale) or "open" (with options and a decision owner); (4) alternatives considered — at least two, each with why rejected (honest reasons, not strawmen); (5) tradeoffs — what the design costs (complexity, latency, ops burden) stated plainly; (6) risks and mitigations; (7) rollout — migration path, feature flags, rollback; (8) open questions table with owner and due placeholder.
Constraints:
- Nothing marked "decided" without rationale; nothing left vague that {{raw_design_notes}} could have pinned down — if the notes are silent, it goes to open questions.
- All quantitative claims from notes carry their label (fact/estimate); no new numbers invented.
- If {{template_or_default}} is provided, follow its section structure exactly.
- The doc must be reviewable by {{stakeholder_roles}} — each section notes which stakeholder should scrutinize it.
Do not write persuasion prose; the doc is a decision record and review artifact, not a pitch.
Output format: the filled design doc markdown, open-questions table, and a pre-review checklist per stakeholder role.
```

### PROMPT-14-18 — Docs-Site Information Architecture Review
**Use when:** a documentation site has grown messy and users get lost.
**Output:** an IA critique with a proposed structure, move/merge/split list, and redirect plan.
**Prompt:**
```text
You are an information architect for documentation. Context: current docs structure {{current_sitemap_or_tree}}, analytics/search data {{usage_data_or_none}}, user journeys {{top_user_goals}}, content inventory sample {{representative_pages}}.
Task: review the IA: (1) map current structure against {{top_user_goals}} — for each top goal, the path a user takes today (steps count, dead ends, orphan pages); (2) diagnose: duplication (same topic in N places), fragmentation (one topic split across pages), misplacement (content under the wrong parent), burial (high-value content deep in the tree); (3) propose the target structure — taxonomy principles (task-based vs concept-based), top-level groups, naming rules; (4) move/merge/split table for every affected page, with redirect source → target; (5) entry-point design: landing pages per audience segment from {{top_user_goals}}; (6) measurement: what to track after the change to confirm improvement.
Constraints:
- Recommendations grounded in {{usage_data_or_none}} where present; without data, state assumptions and propose the tracking that would validate them.
- Every proposed move names its user goal justification; structure follows goals, not org chart.
- Preserve deep links: every move/merge gets a redirect entry; nothing is deleted without an archival note.
- Scope honesty: separate "do now" (fixes dead ends/duplication) from "restructure later".
Do not propose IA by personal aesthetics; each change cites a user-goal failure it fixes.
Output format: goal-to-path analysis, diagnosis findings, target structure tree, move/merge/split table with redirects, and measurement plan.
```

### PROMPT-14-19 — "Explain This Code" for Juniors
**Use when:** a junior developer needs a guided walkthrough of unfamiliar code.
**Output:** a layered explanation: narrative, line-by-line walkthrough, and self-check questions.
**Prompt:**
```text
You are mentoring a junior engineer. Context: code below, their background {{reader_background}}, why they are reading it {{reading_purpose}}.
{{code_excerpt}}
Task: explain the code in layers: (1) the narrative — what this code accomplishes and where it sits in the system, in plain language (2–4 sentences); (2) the walkthrough — line-by-line or block-by-block, from entry to exit, defining every construct the first time it appears; name the control flow explicitly ("this loop ends when...", "if this branch is taken, it means..."); (3) the data — what data flows in, what transformations happen, what flows out; trace one concrete example input through the code with its intermediate values; (4) the traps — the non-obvious parts where a reader would misjudge behavior (mutations, short-circuits, implicit assumptions); (5) self-check — 3–4 questions the reader should now be able to answer, with answers inverted below; (6) next steps — what to read next for deeper understanding.
Constraints:
- Define every jargon term and symbol construct on first use; assume {{reader_background}} but no familiarity with this codebase.
- The traced example must be real — use actual values and compute the actual intermediates; if an input would error, show that path too.
- Explain what the code DOES, grounded in the shown code; if behavior depends on code not shown, say exactly what is missing.
- Match depth to {{reading_purpose}} — skip internals not relevant to it.
Do not dump the code back with inline comments only; the layered structure is the deliverable. No condescension, no unrequested redesign suggestions.
Output format: the layered explanation with the worked example trace and self-check questions.
```

### PROMPT-14-20 — Documentation-Debt Register
**Use when:** cataloguing documentation problems so they can be triaged and fixed.
**Output:** a prioritized debt register with types, impact, effort, and a burn-down plan.
**Prompt:**
```text
You are the registrar of documentation debt. Context: docs corpus {{docs_inventory_or_sample}}, known complaints {{known_pain_points}}, audit findings {{prior_audit_findings_or_none}}, team capacity {{maintenance_capacity}}.
Task: build the register: (1) inventory findings — for each doc/debt item: location, debt type (missing, stale, wrong, fragmented, orphaned, inconsistent-style, inaccessible), evidence quote, and how the debt harms readers (which user goal fails); (2) severity — reader impact × traffic likelihood; justify with the evidence; (3) effort estimate per item (S/M/L with what each entails) — labeled as estimates; (4) prioritization — the fix order given {{maintenance_capacity}}: the cheapest high-impact items first, plus the "critical staleness" class that must gate releases; (5) prevention hooks — where docs-review belongs in the workflow (definition of done, CI checks, PR template questions) so debt stops accumulating; (6) burn-down — a realistic schedule against {{maintenance_capacity}}, with a review cadence.
Constraints:
- Items come only from provided evidence; speculative debt goes in a separate "suspected" list with the check to confirm.
- Every item links its harm to a user goal, not aesthetics.
- Effort estimates include review cost, not just writing cost.
- If {{prior_audit_findings_or_none}} exists, report disposition of each prior finding (fixed/persisted/worsened) — repeat findings signal failed process.
Do not let the register become a wishlist; anything not scheduled within the burn-down horizon is explicitly deferred, not silently dropped.
Output format: register table (id, location, type, evidence, harm, severity, effort), prioritization rationale, prevention-hook recommendations, and burn-down schedule.
```
