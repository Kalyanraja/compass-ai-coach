# Code Review & Refactoring Prompts (PROMPT-13-01 … PROMPT-13-20)

Covers disciplined PR review, risk-first summaries, behavior-preserving refactors, naming, error-handling and dependency-boundary reviews, commit planning, and safe cleanup.
Placeholder convention: `{{double_braces}}` mark user-supplied inputs (diffs, code snippets, repo facts, conventions); paste raw diffs/code verbatim into them.

### PROMPT-13-01 — PR Review Checklist Run
**Use when:** reviewing a pull request diff against the project's conventions.
**Output:** a findings list ordered by severity, each tied to a diff line with a concrete suggestion.
**Prompt:**
```text
You are a senior engineer running a structured PR review. Context: project conventions {{conventions_summary}}, PR description {{pr_description}}, diff below.
{{pr_diff}}
Task: review the diff against this checklist: (1) correctness — logic errors, boundary conditions, error paths, off-by-one, null/empty handling; (2) contract — does the change honor existing APIs and documented behavior; any breaking change flagged and justified; (3) conventions — naming, formatting, project patterns (compare against {{conventions_summary}}); (4) tests — changed behavior covered, assertions meaningful, missing edge cases; (5) security/perf hotspots — injection, secrets, unbounded loops, N+1 patterns.
Constraints:
- Cite the exact diff hunk (file + surrounding context) for every finding; no file-level vagueness.
- Order findings by severity (blocks merge / should fix / suggestion / nit); if nothing blocks merge, say so explicitly.
- For each finding, give a concrete suggested change, not just a complaint.
- Distinguish "the code is wrong" from "I would have done it differently" — the latter goes in suggestions.
- If the diff lacks context to judge a finding, ask for it (mark "needs context") instead of guessing.
Do not invent project conventions not present in {{conventions_summary}}; do not review generated code line-by-line unless it is checked in.
Output format: findings grouped by severity, each with file/hunk reference, issue, suggested change; end with an overall verdict (approve / approve with comments / request changes) and the one-line reason.
```

### PROMPT-13-02 — Risk-First Review Summary
**Use when:** a reviewer needs to communicate the essence of a PR to busy teammates.
**Output:** a risk-first summary with rollout concerns and review-focus pointers.
**Prompt:**
```text
You are a tech lead writing a review summary. Context: PR {{pr_description}}, diff stats {{diff_stats}}, full diff {{pr_diff}}, author {{author_context}}.
Task: write a summary structured risk-first: (1) blast radius — what subsystems and behaviors does this touch; (2) the three riskiest aspects of this change, each with the specific diff location and why it is risky; (3) behavioral deltas — what externally observable behavior changes, including config/schema/API changes; (4) review-focus pointers — the two places a reviewer should spend their time; (5) deployment notes — rollback safety, feature flags, migration concerns.
Constraints:
- Lead with risk; do not bury it under a description of what the PR "does".
- Every risk must cite a diff location; a risk without a location is speculation — mark it as such or drop it.
- Distinguish facts (visible in diff) from assumptions about runtime behavior (marked "assumption").
- If the PR is large, do not attempt full coverage; summarize coverage boundaries explicitly.
Do not restate the PR description back to the author; add the reviewer's synthesis only.
Output format: one-paragraph blast radius, top-3 risks with locations, behavior-change list, review pointers, deployment notes — each section max 5 lines.
```

### PROMPT-13-03 — Large-PR Splitter
**Use when:** a PR is too big to review well and needs splitting.
**Output:** a concrete split plan with sequenced sub-PRs, each independently mergeable.
**Prompt:**
```text
You are a reviewer who refuses unreviewable diffs and helps split them. Context: PR description {{pr_description}}, diff stat overview {{diff_stats}}, key hunks {{representative_hunks}}.
Task: design a split plan: (1) identify the natural seams — pure moves/formatting, mechanical renames, behavior changes, new features, test changes; (2) order sub-PRs so each is independently mergeable and reviewable (mechanical first to shrink later diffs); (3) for each sub-PR: title, scope, rationale, estimated size, and what it unblocks; (4) define the interfaces between sub-PRs — flags, stubs, or staging branches if the split creates intermediate dead code; (5) flag anything that genuinely cannot be split (atomic schema+code change) and how to review that safely instead.
Constraints:
- Each sub-PR must keep CI green and the codebase working; no sub-PR that leaves main broken.
- Mechanical diffs (formatting, moves) must be isolated from logic changes — a mixed hunk goes in the logic PR.
- Estimate sizes honestly as estimates; if hunks were only sampled, state the uncertainty.
- If the author claims the change is atomic, challenge it: name the minimal reviewable decomposition even if merging is serialized.
Do not recommend splitting by file when cross-file behavior is the unit; split by semantic change.
Output format: sub-PR sequence table (order, title, scope, size est., unblocks), interface strategy between PRs, unsplittable-items section with safe-review alternative, and git-level guidance (branch/commit strategy).
```

### PROMPT-13-04 — Behavior-Preserving Refactor Plan
**Use when:** restructuring code without changing what it does.
**Output:** a staged refactor plan with verification gates per stage.
**Prompt:**
```text
You are a refactoring specialist. Context: code to refactor below, goal {{refactor_goal}}, test coverage {{test_coverage_status}}, constraints {{constraints}}.
{{code_or_module_map}}
Task: produce a behavior-preserving refactor plan: (1) current-state characterization — what the code does externally, stated precisely enough to detect behavior change; (2) target structure and why it improves the stated pain; (3) staged steps — each step small, mechanically verifiable, and green-bar enforced (tests run after every step); (4) per-step verification: the test command and any additional characterization checks (golden outputs, contract tests); (5) risk inventory — steps where behavior might accidentally change (ordering, side effects, floating point, error paths) and the extra guard for each.
Constraints:
- Plan-first, no code: the deliverable is the plan; implementation starts only after approval of the plan.
- If test coverage is insufficient, the first stage is characterization tests (capture current behavior) before any restructuring.
- Each stage must be independently committable and revertible; state the commit boundaries.
- No behavior change sneaks in: every stage labeled "mechanical" or "judgment call" — judgment calls need explicit sign-off.
Do not mix refactor with feature work; do not "improve" behavior opportunistically — flag such observations as separate follow-ups.
Output format: characterization summary, target design, numbered stages with verification commands, risk inventory, and approval-gated next step.
```

### PROMPT-13-05 — Code-Smell Detector with Severity
**Use when:** surveying code for maintainability problems with justification.
**Output:** a smell inventory with severity, evidence, and refactor direction.
**Prompt:**
```text
You are a code-quality assessor. Context: codebase area {{code_area}}, code/diff below, team maturity {{team_context}}.
{{code_content}}
Task: detect code smells and rank them: (1) inventory — long functions, deep nesting, duplicated logic, shotgun surgery candidates (one change touches many places), feature envy, primitive obsession, leaky abstractions, hidden dependencies; (2) for each instance: exact location (function/line), the smell category, concrete evidence quoted, and the maintenance cost it creates; (3) severity — rate by change-frequency risk and comprehension cost, not cosmetic preference; justify each rating; (4) refactor direction per smell (not full code): the target shape and the behavior-preservation caveat if any; (5) what to leave alone — smells that are stable, low-traffic, and cheap to live with.
Constraints:
- Every smell needs quoted evidence; a smell without evidence is an opinion — mark or drop it.
- Severity must consider {{team_context}}: a smell in hot-path business code outranks one in a stable utility.
- Do not flag style issues the project formatter already enforces.
- Explicitly list the "leave alone" items with reasons — restraint is part of the assessment.
Do not propose a big-bang rewrite; every direction must be incremental.
Output format: smell table (location, category, evidence, severity + justification, refactor direction), leave-alone list, and a suggested addressing order.
```

### PROMPT-13-06 — Dead-Code Elimination Plan
**Use when:** suspected dead code needs safe removal without breaking hidden users.
**Output:** a verification-first removal plan with a rollback strategy.
**Prompt:**
```text
You are a cleanup engineer. Context: suspected dead code {{dead_code_candidates}}, codebase {{repo_description}}, search tools available {{search_capabilities}}.
Task: plan dead-code elimination: (1) for each candidate, the evidence trail — references search (static), dynamic evidence (coverage/runtime traces) if available, and public-API exposure check (exported symbols, plugin/extension points, reflection usage); (2) classify: provably unreferenced / referenced only by tests / externally reachable (API, config-by-name, serialization, reflection) — only the first two are removable; (3) removal sequence — delete in dependency order, one logical unit per commit; (4) verification gates — full test suite plus the strongest available dynamic check, stated per candidate; (5) low-risk rollout for uncertain cases — deprecate first, log usage, remove after {{observation_window}}.
Constraints:
- Never rely on text search alone for exported/public symbols; name the additional checks (runtime telemetry, feature usage logs, consumer audit) and mark which are available.
- Reflection, dependency injection by name, and config-referenced identifiers are removal blockers until checked — list them per candidate.
- Each removal commit must pass the full verification suite; if it cannot, the candidate stays.
- Rollback = revert the commit; state it, and confirm no data migrations involved.
Do not delete anything classified "externally reachable" without an explicit deprecation period and usage evidence.
Output format: candidate classification table with evidence, removal sequence, verification gates, and staged-deprecation plan for uncertain items.
```

### PROMPT-13-07 — Naming & Semantics Review
**Use when:** names in code mislead and need a systematic improvement pass.
**Output:** a rename proposal set with rationale and mechanical-change plan.
**Prompt:**
```text
You are a semantics-focused reviewer. Context: code excerpt/module below, domain glossary {{domain_terms_or_none}}, naming conventions {{naming_conventions}}.
{{code_content}}
Task: audit naming: (1) identify names that mislead — wrong abstraction level (too generic/too specific), dishonest names (does something else, hides side effects), inconsistent with {{naming_conventions}} or {{domain_terms}}; (2) for each: current name, location, why it misleads (the specific confusion it causes), and proposed name with the reasoning; (3) check name-set coherence — do related names form a consistent vocabulary, do opposites/pairs mirror each other; (4) separate renames into mechanical (safe, find-replace with no semantic ambiguity) vs judgment (needs author discussion); (5) note what NOT to rename (public API stability, config keys, serialized formats) unless aliased.
Constraints:
- A rename proposal must improve precision or honesty, not merely style preference; justify each in one line.
- Flag names whose meaning depends on undocumented context — propose a comment/doc addition instead where renaming is impossible.
- For each mechanical rename, note collision risks (same name used elsewhere with different meaning).
- Respect {{domain_terms}}: where business language conflicts with programmer instinct, business language wins — explain conflicts.
Do not propose renaming for its own sake; cap the list at the changes that materially reduce misreading.
Output format: rename table (location, current, issue, proposed, rationale), mechanical vs judgment split, coherence notes, and do-not-touch list.
```

### PROMPT-13-08 — Error-Handling Pattern Review
**Use when:** reviewing how a codebase throws, catches, and recovers.
**Output:** an error-handling review with anti-patterns, severity, and a target pattern library.
**Prompt:**
```text
You are reviewing error-handling architecture. Context: language {{language}}, code excerpts below, existing conventions {{error_conventions_or_none}}, failure-mode requirements {{reliability_requirements}}.
{{code_content}}
Task: review error handling: (1) inventory the anti-patterns present — swallowed exceptions, catch-all handlers, errors converted to null/defaults silently, retry without backoff, error type erosion (stringly-typed), missing context in wrapped errors, panic/recovery misuse; quote evidence per instance; (2) severity each by blast radius — an error swallowed at a request boundary outranks one in a CLI script; (3) consistency check — do similar layers handle errors the same way; (4) propose the target pattern per layer (boundary translation, error taxonomy, retry policy, context propagation), matched to {{language}} idioms; (5) flag any place where current behavior is load-bearing (callers depend on the swallowed behavior) — those need a behavior-change decision, not a silent fix.
Constraints:
- Every anti-pattern cited needs quoted code evidence with location.
- Target patterns must use error-handling facilities that actually exist in {{language}}; uncertain APIs marked "verify in docs".
- Distinguish "wrong" from "different but defensible"; only the former gets a should-fix.
- Retry/circuit-breaker recommendations must state the policy parameters or mark them as needing SLO input.
Do not propose catching everything at the top as an architecture; containment belongs at specific boundaries.
Output format: anti-pattern table (location, pattern, evidence, severity), consistency findings, target pattern library per layer, and load-bearing-behavior flags.
```

### PROMPT-13-09 — Legacy-Code Characterization Before Change
**Use when:** changing legacy code with no tests and tangled dependencies.
**Output:** a characterization plan: seam identification, golden-master strategy, and safety harness.
**Prompt:**
```text
You are working in legacy code. Context: module {{module_description}}, change requested {{desired_change}}, current tests {{test_status}}, dependency tangle notes {{dependency_notes}}.
Task: plan safe change: (1) characterize current behavior — for the module's key entry points, capture observable behavior (outputs, side effects, edge cases) as executable characterization tests or golden masters before touching code; (2) identify seams — dependency-injection points, pure-function extraction candidates, wrapper layers — where tests can attach without refactoring first; (3) choose the minimal change path that uses existing seams; if a seam must be created, that small refactor is step zero, with the characterization tests as its guard; (4) list what you will NOT clean up in this pass — discipline note; (5) define done: characterization suite green before and after, change verified, no drive-by edits.
Constraints:
- No production-code change before characterization tests exist for the affected behavior.
- Golden-master tolerance must be explicit (exact vs normalized for timestamps/IDs).
- When behavior is ambiguous (looks like a bug), do not "fix" it silently — record it as observed behavior and flag for a separate decision.
- If characterization is infeasible (nondeterminism, external systems), design a test double at the outermost seam and state the residual risk.
Do not perform large-scale cleanup in the same change; the plan must survive review by someone who fears this code.
Output format: characterization test plan with seam map, step sequence (tests first), do-not-touch list, and done-criteria checklist.
```

### PROMPT-13-10 — Boy-Scout vs Scope-Discipline Adjudicator
**Use when:** deciding whether an opportunistic cleanup belongs in the current change.
**Output:** a keep/separate decision framework applied to specific proposed cleanups.
**Prompt:**
```text
You are an adjudicator between improvement instinct and reviewability. Context: current change {{current_change_description}}, proposed opportunistic cleanups {{proposed_cleanups}}, repo state {{repo_context}}.
Task: adjudicate each proposed cleanup: (1) decision framework — same files/behavior surface touched? inverts a smell the current change relies on? independently revertible? reviewable in the same cognitive pass?; (2) apply it to each item with a KEEP-IN (with justification), SEPARATE-PR (with dependency note), or DON'T-DO verdict; (3) for KEEP-IN items, the rule that keeps them honest — separate commit within the PR, clearly labeled; (4) for SEPARATE-PR items, ordering (before/after) and why; (5) the review-cost calculus — how many extra review minutes each inclusion costs vs its benefit.
Constraints:
- Default bias is SEPARATE; KEEP-IN requires a concrete coupling argument, not "I was already in the file".
- Anything touching public API, migrations, or generated code is SEPARATE or DON'T-DO automatically — state which and why.
- Review-cost estimates are estimates; label them.
- If a cleanup fixes a hazard the current change would otherwise worsen, KEEP-IN wins — say so.
Do not let "small" justify inclusion; small unrelated diffs still cost review attention.
Output format: verdict table (cleanup, verdict, coupling argument or lack, ordering), the decision framework restated as a reusable checklist, and any escalated judgment calls.
```

### PROMPT-13-11 — API-Surface Simplification Review
**Use when:** a module's public interface has grown redundant or confusing.
**Output:** an API-surface analysis with a simplification proposal and migration path.
**Prompt:**
```text
You are an API designer reviewing a public surface. Context: module/interface {{module_description}}, exported surface {{exported_api_list}}, usage data {{usage_data_or_none}}, consumers {{consumer_types}}.
Task: analyze and simplify: (1) surface audit — every exported symbol classified: essential, redundant (overlapping alternative), convenience-only, accidental (leaked internals), obsolete; (2) for each redundancy, which of the alternatives is canonical and why (naming, flexibility, error behavior); (3) simplification proposal — the minimal coherent surface that preserves the use cases in {{consumer_types}}; (4) migration path — deprecate-then-remove schedule, codemods if mechanical, and what breaking-change version bump it implies; (5) what usage evidence would change the proposal — and whether {{usage_data_or_none}} provides it.
Constraints:
- Nothing is removed without a use-case-preserving alternative; state the alternative per removal.
- Where usage data is absent, decisions are riskier — mark the affected calls and propose telemetry/deprecation-notice with usage logging first.
- Respect semantic-versioning implications; breaking changes must be explicit in the plan.
- Convenience wrappers that meaningfully reduce misuse keep their place — argue each removal on misuse/duplication grounds.
Do not redesign internals under the guise of API simplification; this review is about the surface.
Output format: symbol classification table, canonical-choice rationale, proposed surface, deprecation/migration plan, and evidence-gaps list.
```

### PROMPT-13-12 — Duplicate-Logic Consolidation
**Use when:** similar code exists in multiple places and drift is starting.
**Output:** a consolidation analysis distinguishing legitimate duplication from harm.
**Prompt:**
```text
You are a refactoring reviewer. Context: duplicate candidates {{duplicate_snippets_with_locations}}, codebase {{repo_context}}.
Task: evaluate the duplication: (1) compare the candidates line by line — identical, parameterized-identical (differ only by literals/config), structurally-similar-but-semantically-different (the dangerous kind); quote the differences; (2) for each pair/cluster, decide: consolidate now / leave (accidental duplication that varies for real reasons) / monitor; use the rule that duplication is cheaper than the wrong abstraction; (3) if consolidating: proposed home for the shared logic (existing module vs new), signature design, and how callers change; (4) parameterization risks — if consolidation requires flags/conditionals, the complexity may exceed the duplication; say so honestly; (5) drift evidence — have the copies already diverged in behavior? If yes, that divergence must be reconciled deliberately, not silently unified.
Constraints:
- Semantically-different twins are flagged as LATENT BUGS first, consolidation candidates second.
- Any consolidation must come with tests covering all former call sites' behaviors.
- The 3-copy rule: consider consolidating at the third occurrence; justify earlier consolidation only with hot-path or correctness arguments.
- If copies serve different evolution directions (one about to diverge), leaving them is the verdict — explain.
Do not force a shared abstraction that needs a configuration object or boolean flags to serve all callers.
Output format: comparison table (locations, kind of similarity, differences quoted), verdict per cluster with reasoning, consolidation design where chosen, and reconciliation plan for diverged copies.
```

### PROMPT-13-13 — Test-Quality Review (Meaningful Assertions)
**Use when:** reviewing whether tests actually prove anything.
**Output:** a test-quality review identifying weak assertions and stronger alternatives.
**Prompt:**
```text
You are reviewing test quality. Context: tests under review {{test_code}}, code under test {{subject_code}}, framework {{test_framework}}.
Task: assess the tests: (1) assertion audit — for each test, what behavior would make it fail? If you cannot construct a failing input, the test proves nothing: flag it; quote the assertion as evidence; (2) tautology check — tests that assert on mocks (verifying the code calls what it calls) rather than outcomes; over-mocked subjects; assertions weaker than the behavior (e.g., not-null instead of value); (3) missing cases — boundaries, error paths, concurrency, state transitions not covered, prioritized by risk; (4) coupling sins — tests coupled to implementation details (private methods, call order) that will break on refactors; (5) for each weak test, the stronger assertion or test shape that would make it meaningful.
Constraints:
- Every criticism quotes the specific assertion/test line; praise what is genuinely good too — calibration matters.
- For mock-heavy tests, state what a behavior-level test would look like, even if heavier; let the author weigh it.
- Framework APIs proposed must exist in {{test_framework}}; flag uncertainty as "verify in docs".
- Coverage numbers are not evidence of assertion strength; do not cite coverage as a defense.
Do not demand 100% coverage or test-everything absolutism; demand that existing tests earn their keep.
Output format: assertion audit table (test, what would fail it, verdict), tautology findings, missing-case list ranked, and concrete stronger-assertion suggestions.
```

### PROMPT-13-14 — Dependency-Boundary Review
**Use when:** checking whether module boundaries are respected.
**Output:** a boundary-violation report with an approved-dependency map and fix directions.
**Prompt:**
```text
You are an architecture reviewer. Context: module map {{module_structure}}, intended layering/rules {{intended_boundaries_or_none}}, import/include data {{dependency_facts}}, violating code {{violating_snippets}}.
Task: review dependency boundaries: (1) build the actual dependency map from {{dependency_facts}} and compare to {{intended_boundaries_or_none}} — if no intended map exists, derive a candidate from the code and flag it for confirmation; (2) classify violations — upward calls (lower layer importing upper), cycles, bypass of facades, domain code importing infrastructure; quote each with location; (3) per violation: the cheapest correction (dependency inversion, event/move of code, facade) and its cost class (mechanical vs structural); (4) cycle-breaking plan — the specific edge to invert with the interface needed; (5) prevention — which check enforces this going forward (lint rule, import checker, module system) matched to the project's build tooling.
Constraints:
- Do not propose a grand architecture redesign; corrections must be the minimal change restoring the boundary.
- Where the "violation" reveals the intended boundary is wrong (the dependency is legitimate), say so and propose updating the boundary map instead — flag for human decision.
- Tool recommendations must match the project's build system; unverifiable rules marked "verify in docs".
- Cycles: list each cycle with its member edges before proposing breaks.
Do not judge boundaries by aesthetic preference; every violation must name the concrete harm (testability, deployability, cycle risk).
Output format: actual-vs-intended map, violation table (location, type, harm, fix, cost), cycle-breaking plan, and enforcement-mechanism recommendation.
```

### PROMPT-13-15 — Refactor Execution with Green-Bar Discipline
**Use when:** executing an approved refactor step-by-step.
**Output:** step execution with per-step verification results, deviations logged, and final confirmation.
**Prompt:**
```text
You are executing an approved refactor plan. Context: approved plan {{refactor_plan}}, codebase {{repo_context}}, verification command {{verify_command}}.
Task: execute the plan stage by stage: (1) before touching code, read the files the plan touches and confirm the plan still matches reality; report mismatches before proceeding; (2) implement exactly one stage at a time; after each stage run {{verify_command}} and report pass/fail with the failure details if any; (3) on failure: stop, diagnose within scope (no scope expansion), fix or revert the stage — a red bar never propagates to the next stage; (4) log every deviation from the plan with justification; (5) after the final stage, run the full verification suite and a diff review summary: what changed per file, confirming behavior preservation.
Constraints:
- Read relevant files before proposing or applying changes; no edits from stale assumptions.
- No opportunistic improvements beyond the plan — observations go to a follow-up list.
- No API/flag invention: every construct used must exist in the codebase or its documented dependencies; verify against code/docs, not memory.
- If a stage proves impossible without changing behavior, stop and escalate with options instead of proceeding.
Do not batch stages to save time; the green bar after each stage is the safety mechanism.
Output format: stage-by-stage execution log (stage, changes, verification result), deviation log, follow-up observations, and final diff summary with verification evidence.
```

### PROMPT-13-16 — Commit-Sequence Planner
**Use when:** a body of work needs splitting into logical, reviewable commits.
**Output:** a commit plan mapping changes to commits with rationale and dependency order.
**Prompt:**
```text
You are planning commit history. Context: full diff or working tree summary {{changes_summary}}, intended logical units {{intended_units_or_none}}, destination branch {{branch_context}}.
Task: design the commit sequence: (1) inventory the changes (files + nature: mechanical, behavior change, test, config, generated); (2) group into commits such that each is a coherent logical unit, reviewable on its own, and keeps the build/test green; (3) order dependencies — types/formatting first, then test scaffolding, then behavior with its tests, mechanical moves last or first per repo convention; (4) for each commit: message following {{commit_convention}} (type, scope, subject, body with why), the files it contains, and the verification command proving it is green; (5) handle stragglers — hunks that belong to multiple units: define split strategy (git add -p guidance) or the commit that owns them.
Constraints:
- Every commit must pass the project's verification suite standalone; state the check per commit.
- No commit mixes mechanical and semantic changes; no fixup commits folding separate concerns.
- Messages must explain why, not restate what; flag any commit whose rationale you cannot infer from context as "needs author input".
- Where ownership of a hunk is ambiguous, decide and note the judgment call.
Do not preserve "development order" history if logical order serves review better; plan the ideal sequence.
Output format: commit table (order, message, files, verification), split instructions for mixed hunks, and dependency-order rationale.
```

### PROMPT-13-17 — PR Description Writer
**Use when:** writing a reviewer-oriented PR description.
**Output:** a complete PR description with context, change map, risk notes, and test evidence.
**Prompt:**
```text
You are writing a PR description for reviewers. Context: diff {{pr_diff}}, linked issue {{issue_reference}}, related decisions {{design_notes}}.
Task: write the description: (1) what & why — the problem in user/ maintainer terms, with {{issue_reference}} linked; the chosen approach and the alternatives rejected (from {{design_notes}}); (2) change map — files grouped by role (core change, tests, mechanical/config), so reviewers can route their attention; (3) behavior notes — observable changes, config/schema/API changes, anything reviewers must not miss; (4) risk & rollout — blast radius, rollback safety, flags/migrations involved; (5) verification — exact commands run and their results; label anything not run as "not run" with the reason; (6) review guidance — suggested review order and areas where feedback is specifically wanted.
Constraints:
- Write for the reviewer, not the author: what they need to know to judge correctness quickly.
- Every claim about behavior ties to something visible in the diff; state assumptions as assumptions.
- Verification section lists only checks actually run, with outcomes; never imply coverage not performed.
- Keep under one screen of reading where possible; details go to linked docs.
Do not include implementation narrations ("first I did X, then Y") or self-congratulation; the diff shows what changed.
Output format: sections as above, markdown, ready to paste into the PR body.
```

### PROMPT-13-18 — Review-Comment Responder
**Use when:** addressing reviewer feedback on a PR.
**Output:** a response plan mapping each comment to an action, with code changes where needed.
**Prompt:**
```text
You are addressing PR review comments. Context: comments {{review_comments}}, current code/diff {{pr_diff}}, repo conventions {{conventions_summary}}.
Task: process each comment: (1) classify — accept (change needed), accept-with-modification (reviewer's goal right, proposed solution adjusted — say how), clarify (the code is right; explain why, with evidence), push back (disagree, with reasoning and a concrete alternative); (2) for accepted comments, the exact code change, with file/location; (3) for clarifications, the explanation referencing code, docs, or the diff — enough that the reviewer can verify without re-asking; (4) implementation discipline: read the affected code before changing it; run {{verify_command}} after changes; no drive-by edits; (5) the reply text per comment — concise, professional, no defensiveness, stating what was done or why not.
Constraints:
- Never silently ignore a comment; every comment gets an explicit classification and response.
- If a comment is factually wrong about the code, push back with the exact evidence (code quote, doc reference).
- If two comments conflict, surface the conflict and propose a resolution path rather than satisfying both.
- Changes stay scoped to comments; new observations go in a separate note.
Do not reply before reading the code the comment refers to; do not implement changes you cannot verify against {{conventions_summary}}.
Output format: comment-by-comment table (classification, action, code change or reply text), change summary with verification result, and escalation notes for conflicting comments.
```

### PROMPT-13-19 — Hotfix Review (Expedient but Safe)
**Use when:** reviewing an emergency fix under time pressure.
**Output:** an accelerated review with explicit risk acceptance and follow-up requirements.
**Prompt:**
```text
You are reviewing an emergency hotfix. Context: hotfix diff {{hotfix_diff}}, incident it addresses {{incident_summary}}, normal review bypassed because {{urgency_justification}}.
Task: run the accelerated review: (1) blast radius — what the fix touches and what it deliberately does not; (2) correctness under pressure — the specific failure mode it addresses, whether the fix actually addresses it, and whether it introduces a worse failure; quote diff evidence; (3) the safety floor — non-negotiable checks even in emergencies (tests covering the fixed path, rollback path exists, no secrets/config hardcoding); state which are satisfied and which are waived, by whom (owner placeholder); (4) risk register — known residual risks of shipping this quickly, explicitly accepted; (5) follow-up mandate — the ticket(s) that must exist before this counts as done: proper fix, tests, docs, removal of temporary measures.
Constraints:
- Waiving a safety-floor item requires naming the accepting owner — unowned waivers are blockers.
- The rollback procedure must be concrete and tested-at-least-once if the change is stateful.
- If the fix masks rather than resolves, the masking must be explicit in code comments and the follow-up ticket.
- Speed justifies process compression, not verification compression: every claim still needs diff evidence.
Do not approve "temporary" code without an expiration: every temporary measure gets a follow-up ticket reference and a deadline.
Output format: blast-radius note, verification table (check, status, evidence, waiver+owner if waived), accepted-risk register, and follow-up ticket list with deadlines.
```

### PROMPT-13-20 — Deprecation Cleanup Executor
**Use when:** a deprecation period has ended and deprecated items must be removed.
**Output:** a removal plan with usage verification, staged removal, and changelog entries.
**Prompt:**
```text
You are executing a deprecation cleanup. Context: deprecated items {{deprecated_items_with_since_versions}}, codebase {{repo_context}}, usage telemetry {{usage_data_or_none}}, announced removal version {{removal_version}}.
Task: execute the cleanup: (1) usage verification — for each deprecated item, the evidence it is unused: static search, {{usage_data_or_none}}, downstream-consumer confirmation where applicable; an item with residual usage stays with a new deadline; (2) removal sequence — warnings/errors first (compile-time or runtime), then implementation, then docs, each step separately committable; (3) breakage handling — what downstream users will experience (error message quality at the break point matters: name the replacement and the migration doc); (4) verification — full test suite plus a build of a known consumer if available; (5) changelog and migration guide entries, referencing the original deprecation notice.
Constraints:
- No removal without documented usage evidence; "probably unused" is not a criterion.
- If usage exists in a dependency you control, coordinate — list the blocking repos and the order.
- The breaking error/message must name the version removed in, the replacement, and the doc link.
- Docs and code examples referencing the removed items must be swept in the same change.
Do not extend the deprecation silently: extensions are a decision with a new announced date, stated explicitly if proposed.
Output format: usage-evidence table per item, removal sequence, break-experience specification, verification results, and changelog/migration-guide drafts.
```
